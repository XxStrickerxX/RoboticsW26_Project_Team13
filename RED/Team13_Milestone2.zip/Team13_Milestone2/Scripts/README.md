# Team 13 – ABB IRB 120 – Milestone 01

Kinematics of the ABB IRB 120 (6 joints) in **MATLAB / Simulink / Simscape** and in
**ROS 2 Jazzy / Gazebo Harmonic**, with the same robot, the same numbers and the same
tests on both sides.

## Folder layout

```
irb120_m1/
  params/irb120_params.json      ONE parameter file for MATLAB and ROS (DH, limits, test poses)
  matlab/                        MATLAB, Simulink and Simscape files
  ros2_ws/src/my_irb120_robot/   ROS 2 package (Gazebo model, nodes, launch file)
  tools/step_to_stl.py           makes the Gazebo meshes from the STEP files
  results/                       CSV results written by the MATLAB tests
```

## Where each requirement is covered

| Req. | What the brief asks | Files |
|---|---|---|
| R1 | DH convention | `matlab/dh_table.m`, `matlab/derive_symbolic.m`, `params/irb120_params.json` |
| R2 | FK and IK in MATLAB/Simulink and Python-ROS (one node per script) | MATLAB: `fk_irb120.m`, `ik_irb120.m` (trigonometric), `ik_newton_raphson.m` (numerical), `ik_best.m`, `build_fk_ik_simulink.m`. ROS: `fk_node.py`, `ik_node.py` (`method:=trig` or `method:=newton`) |
| R3 | CAD in Simscape and in Gazebo, URDF loaded with Python | `matlab/build_simple_model.m` (smimport of the SolidWorks XML), `urdf/irb120.urdf`, `launch/gazebo.launch.py` |
| R4 | Move/visualise joints with constants, signal profiles and sliders | Simscape `IRB120_Simple` (one Step block per joint = the angle you give), `matlab/robot_slider_gui.m`, ROS: `joint_commander.py` (give angles) and `slider_gui.py` |
| R5 | Input q, qd, qdd; sense flange position, velocity, acceleration; IK must match the equations | MATLAB `test_kinematics.m`, Simscape `compare_simple_model.m`; ROS `ee_sensor_node.py`, `kinematics_test_node.py` |

### One motion everywhere: "give angles"
MATLAB, Simscape and Gazebo all do the same move (values in `params/irb120_params.json`,
section `move`): the robot starts at home (all 0), at t = 1 s it is given the target
angles [30 20 10 40 50 60] deg, and the step is smoothed by `1/(0.2 s + 1)^2`.
* Simscape: `Step -> Transfer Fcn 1/(0.04 s^2 + 0.4 s + 1) -> Gain -> Bias -> joint`.
* MATLAB and Python: `step_motion` gives the exact answer of that block,
  with u = (t − 1)/0.2:  `q = q0 + Δq·(1 − (1+u)e^−u)`, `qd = Δq·(u/0.2)e^−u`,
  `qdd = Δq·(1−u)/0.2²·e^−u`.
* Gazebo: `joint_commander` sends that q to the joints.

## The robot model (numbers and where they come from)

DH table, standard convention `A_i = Rz(θi)·Tz(di)·Tx(ai)·Rx(αi)`, `θi = qi + offset`:

| i | θi | di [m] | ai [m] | αi | limits [deg] (ABB data sheet) |
|---|---|---|---|---|---|
| 1 | q1 | 0.290 | 0 | −90° | −165 … 165 |
| 2 | q2 − 90° | 0 | 0.270 | 0 | −110 … 110 |
| 3 | q3 | 0 | 0.070 | −90° | −110 … 70 |
| 4 | q4 | 0.302 | 0 | +90° | −160 … 160 |
| 5 | q5 | 0 | 0 | −90° | −120 … 120 |
| 6 | q6 | 0.072 | 0 | 0 | −400 … 400 |

* DH: Truc & Lam (2020), Turk J Elec Eng & Comp Sci 28, Fig. 1b. Checked: it is identical
  (to 1e-8) to the joint chain of the team URDF, and fits the CAD joint axes.
* Joint limits and speeds (250/250/250/320/320/420 deg/s): ABB IRB 120 data sheet ROBO149EN_D Rev. J.
* Home pose (all zero): upper arm vertical, forearm horizontal, flange at (0.374, 0, 0.630) m.
* q3 positive lowers the forearm, like ABB axis 3.

### Same method as the course (Tutorials 03 and 04)
* **FK (Tutorial 03):** standard DH, the four steps of the tutorial: assign axes, fill the
  DH table, `(i-1)T(i)` matrices (same matrix as slide 13), total `0T6 = 0T1·1T2·…·5T6`.
  `derive_symbolic.m` prints every `(i-1)T(i)`, the elements a11…a33 and X, Y, Z, like
  Example 2 of the tutorial.
* **IK, trigonometric approach (Tutorial 04):** `ik_irb120.m`. The 3-D problem is split
  into plane problems, like Example 2: wrist centre `pw = p − 0.072·z6`; top view
  `q1 = tan⁻¹(y/x)`; side view `S² = r² + s²` and the cosine rule in the triangle
  (upper arm 0.270 m, forearm √(0.07² + 0.302²) = 0.310 m) give q3 and q2; the wrist
  rotation `R36 = R03ᵀ·R` gives q4, q5, q6. Up to 8 solutions; `ik_best` keeps the one
  inside the limits closest to the current pose.
* **IK, numerical approach (Tutorial 04):** `ik_newton_raphson.m`,
  `q(n+1) = q(n) − [∂F/∂q]⁻¹ F(q(n))` until |F| < 1e-10.
  Position mode (as in the tutorial): `F = p(q) − p_desired`, 3 equations, solves q1–q3.
  Pose mode: 6 equations (position + orientation error), solves all 6 joints.
  `∂F/∂q` is evaluated numerically (square 3×3 or 6×6 matrix, inverted as in the slides).

### Velocity and acceleration (Jacobian)
`v = Jv·qd`, `a = Jv·qdd + J̇v·qd`, with `Jv_i = z_{i−1} × (p6 − o_{i−1})` and an exact
formula for `J̇` (no numerical differentiation).

## Important findings (tell the TA)

1. **The old URDF placed the meshes wrongly** (e.g. the base about 0.5 m below the floor).
   The joint chain was right; only mesh/inertia placement was wrong. The new
   `urdf/irb120.urdf` computes every placement from `IRB120_Assembly.xml`. Check: the robot
   stands on z = 0, is 0.700 m tall and the base is 0.18 m wide, as in the ABB data sheet.
   Masses, centres of mass and full inertia tensors also come from the XML (gripper 0.312 kg).
2. **The CAD is not a perfect DH robot**: its joint axes are up to ~6 mm off the ideal
   positions. Simscape (which uses the CAD) and the DH equations therefore differ by a few
   millimetres (about 3–13 mm over the test poses). The equations themselves are tested to
   1e-6 or better.
3. The Simscape joints are zero in the CAD assembly pose, which is 1–3° away from the DH
   zero pose, and some turn the other way. `simscape_cad_offsets.m` holds that offset and
   the base frame; the Gain and Bias blocks of `IRB120_Simple` apply them
   (`q_cad = s·q_dh + (thcad − s·qcad)`, directions s = [−1 −1 1 −1 −1 1]).
   The Simscape sensor point is the joint-6 frame, 0.066 m after the wrist centre
   (the DH flange is at 0.072 m), so `compare_simple_model.m` uses d6 = 0.066.
4. **Robot + gripper are both simulated.** The six arm joints are driven; the gripper is
   mounted on the flange. In Simscape the gripper keeps its own revolute joint (as
   decided), driven by `gripper_target_deg` (0 = held at its CAD angle, so it does not swing).
   In Gazebo the gripper is fixed to the flange, which is the same as angle 0. The gripper
   fingers do not open/close in Milestone 01 (the CAD fingers are rigid); grasping is part
   of the pick-and-place milestone.
5. The XML gives products of inertia as `[Iyz Izx Ixy]`; they are used as the tensor
   off-diagonal values. This only matters for dynamics (Milestone 02+).

## How to run – MATLAB

```matlab
cd ~/irb120_m1/matlab
run_matlab_all            % R1 + R2: DH table, symbolic check, tests, Simulink FK/IK model
robot_slider_gui          % R4: sliders, live FK / IK
build_simple_model        % R3 + R4: IRB120_Simple.slx (Step -> Transfer Fcn -> Gain -> Bias -> joint)
                          %   press Run: the robot moves to the target angles
compare_simple_model      % R5: Simscape sensor vs DH equations (p, v, a) + plot
```
Other angles in Simscape: double-click `qN_target_deg`, type the angle in "Final value",
press Run (then `compare_simple_model` again; it reads the angles from the model).

## How to run – Gazebo (ROS 2 Jazzy)

1. Meshes (once): `tools/step_to_stl.py` needs `cadquery` in a private Python environment.
2. Build: `cd ~/irb120_m1/ros2_ws && colcon build --symlink-install && source install/setup.bash`
3. `pkill -f "gz sim"; ros2 launch my_irb120_robot gazebo.launch.py`
4. In new terminals (each one: `source ~/irb120_m1/ros2_ws/install/setup.bash`):
   * `ros2 run my_irb120_robot ee_sensor_node` – flange position / velocity / acceleration
   * `ros2 run my_irb120_robot fk_node`, `ros2 run my_irb120_robot ik_node`
   * `ros2 run my_irb120_robot joint_commander` – the same move as Simscape
     (other angles: `--ros-args -p "q_deg:=[45.0,30.0,-20.0,60.0,60.0,90.0]"`)
   * `ros2 run my_irb120_robot slider_gui`
   * `ros2 run my_irb120_robot kinematics_test_node` – automatic R5 test (7 test poses, each
     reached with the same smooth move,
     then the "give angles" move), CSV in `~/irb120_m1_results`

ROS topics: commands `/irb120/joint1..6/cmd_pos` (Float64, rad), reference
`/irb120/joint_reference` (`[q, qd, qdd]`), Gazebo feedback `/joint_states`, results
`/irb120/fk_pose`, `/irb120/ik_solution`, `/irb120/ee_pose`, `/irb120/ee_pose_tf`,
`/irb120/ee_twist`, `/irb120/ee_accel`.

## What was tested before delivery, and what was not

* Tested (Python, outside ROS): FK = URDF chain (500 random poses, error 1e-8); IK on 5000
  random poses (8 solutions each, all exact, error < 1e-11); singular wrist; Jacobian and
  J̇ vs finite differences (1e-10); velocity / acceleration along the "give angles" move; every ROS
  node run once with simulated ROS messages; URDF/SDF/package XML parse.
* All `.m` files, the Simscape model, the launch file and the Gazebo plugins were run on
  the laptop (results below). Files removed in the simple version (not needed any more):
  `quintic_traj.m`, `build_simscape_harness.m`, `run_simscape_test.m`, `harness_defaults.m`.

## Results on the laptop

Earlier version (17 Oct 2026, before the "give angles" change):
* MATLAB `test_kinematics`: all PASS (FK 1e-16, trig IK 1e-16, Newton-Raphson 1e-11..1e-16).
* Simscape: flange Simscape vs DH 3-13 mm (CAD geometry); sensed joints = inputs (4e-15).
* Simple Simscape model: sensor point 0.3402 0.2294 0.3984 m for [30 20 10 40 50 60] deg.
* Gazebo `kinematics_test_node`: all 7 poses FK vs TF ~1e-9 m, both IK methods exact,
  STATIC POSES PASS.

"Give angles" version: to be filled in after the rerun.
* Expected: flange (d6 = 0.072) from FK of [30 20 10 40 50 60] deg = (0.3355, 0.2346, 0.3936) m
  in MATLAB and Gazebo. Simscape sensor point (d6 = 0.066): DH gives (0.3356, 0.2313, 0.3986) m,
  Simscape (CAD) measured about (0.3402, 0.2294, 0.3984) m before = 4.9 mm difference (CAD).
