function J = jacobian_irb120(q, P)
%JACOBIAN_IRB120 Geometric Jacobian of the flange (6x6).
%   [v; w] = J * qdot.  Rows 1-3 (Jv) give the linear velocity of the
%   flange, rows 4-6 (Jw) its angular velocity, both in the base frame.
%   For a revolute joint i:  Jv_i = z_{i-1} x (p_6 - o_{i-1}),  Jw_i = z_{i-1}
[~, F] = fk_irb120(q, P);
pe = F(1:3,4,7);
J = zeros(6,6);
for i = 1:6
    z = F(1:3,3,i);          % axis of joint i  (z of frame i-1)
    o = F(1:3,4,i);          % origin of frame i-1
    J(1:3,i) = cross(z, pe - o);
    J(4:6,i) = z;
end
end
