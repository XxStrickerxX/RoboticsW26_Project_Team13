function J_inv = inverse_jacobian_matrix(q)
% INVERSE_JACOBIAN_MATRIX  Numeric pseudo-inverse of dF/dq at the joint angles q (RED Milestone 2).
%   q     : 6x1 numeric joint angles (rad)
%   J_inv : 6x3 numeric pseudo-inverse of dF/dq
% F = [x; y; z] is the flange position from forward_kinematics_func (Milestone 1 FK).
% dF/dq is 3x6 (3 position equations, 6 joints), so it is not square and has no normal
% inverse. We use the pseudo-inverse, as the brief asks.

    persistent dFdq_fun
    if isempty(dFdq_fun)                     % build the symbolic matrix only once
        syms q1 q2 q3 q4 q5 q6 real
        X = forward_kinematics_func();
        % differentiate x, y, z with respect to each joint angle -> 3x6 matrix
        dFdq = jacobian(X, [q1, q2, q3, q4, q5, q6]);
        dFdq_fun = matlabFunction(dFdq, 'Vars', {[q1; q2; q3; q4; q5; q6]});
    end

    dFdq_num = dFdq_fun(q(:));               % put in the numeric joint angles
    J_inv = pinv(dFdq_num);                  % pseudo-inverse (6x3)
end
