function [q, qd, qdd] = step_motion(q0, q1, t, ts, tau)
%STEP_MOTION "Give angles" move used in MATLAB, Simscape and Gazebo.
%   The joint angles are q0 until time ts, then the target q1 is given.
%   The step is smoothed by the filter 1/(tau*s + 1)^2 (the Transfer Fcn
%   block in IRB120_Simple), so the exact motion is, with u = (t - ts)/tau:
%       q   = q0 + (q1 - q0) * (1 - (1 + u) e^-u)
%       qd  =      (q1 - q0) * (u / tau)        e^-u
%       qdd =      (q1 - q0) * (1 - u) / tau^2  e^-u
%   [q, qd, qdd] = step_motion(q0, q1, t, ts, tau)   (q0, q1 in rad)
dq = q1(:) - q0(:);
if t <= ts
    q = q0(:); qd = zeros(size(dq)); qdd = zeros(size(dq));
    return;
end
u = (t - ts) / tau;
e = exp(-u);
q   = q0(:) + dq * (1 - (1 + u)*e);
qd  = dq * (u/tau) * e;
qdd = dq * (1 - u)/tau^2 * e;
end
