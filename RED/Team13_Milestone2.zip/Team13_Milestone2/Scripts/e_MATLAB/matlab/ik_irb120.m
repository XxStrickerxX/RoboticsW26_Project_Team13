function Q = ik_irb120(T, P)
%IK_IRB120 Inverse kinematics, TRIGONOMETRIC approach (Tutorial 04).
%   Q = ik_irb120(T, P) returns all solutions (up to 8 rows of 6 angles,
%   in rad, wrapped to (-pi, pi]) that put the flange at pose T (4x4).
%   An empty matrix means the pose is out of reach.
%
%   Like Example 2 of the tutorial, the 3-D problem is split into plane
%   problems (the IRB 120 has a spherical wrist: axes 4, 5, 6 meet):
%   0) Wrist centre  pw = p - d6*z6  (the point the first 3 joints place).
%   1) Top view (X-Y plane):  q1 = tan^-1(y/x)       (or q1 + 180 deg).
%   2) Side view (arm plane): S^2 = r^2 + s^2, with r = horizontal and
%      s = vertical distance from joint 2 to the wrist centre.
%      Cosine rule in the triangle (a2, L, S), L = sqrt(a3^2 + d4^2):
%         S^2 = a2^2 + L^2 + 2*a2*L*cos(q3 + beta),  beta = tan^-1(d4/a3)
%      -> q3 (elbow up / down), then q2 = tan^-1(r/s) - tan^-1(B/A).
%   3) Wrist: R36 = R03' * R gives q4, q5, q6 (wrist flip: 2 choices).
%   Joint limits are NOT applied here; use ik_best() for that.
%   The numerical approach (Newton-Raphson) is in ik_newton_raphson.m.

d1 = P.d(1); a2 = P.a(2); a3 = P.a(3); d4 = P.d(4); d6 = P.d(6);
R  = T(1:3,1:3);
p  = T(1:3,4);
pw = p - d6 * R(:,3);              % wrist centre
L    = hypot(a3, d4);              % joint 3 -> wrist centre
beta = atan2(d4, a3);              % fixed angle of that segment

if hypot(pw(1), pw(2)) > 1e-9
    q1a = atan2(pw(2), pw(1));
else
    q1a = 0;                       % wrist centre on the base axis
end

Q = zeros(0,6);
for q1 = [q1a, q1a + pi]
    r = pw(1)*cos(q1) + pw(2)*sin(q1);     % horizontal distance in arm plane
    s = pw(3) - d1;                        % height above joint 2
    c = (r^2 + s^2 - a2^2 - L^2) / (2*a2*L);
    if abs(c) > 1 + 1e-9
        continue;                          % not reachable with this q1
    end
    c = max(-1, min(1, c));
    for g = [acos(c), -acos(c)]            % g = q3 + beta
        q3 = g - beta;
        A  = a2 + L*cos(g);
        B  = L*sin(g);
        q2 = atan2(r, s) - atan2(B, A);
        [~, F] = fk_irb120([q1 q2 q3 0 0 0], P);
        R03 = F(1:3,1:3,4);
        R36 = R03.' * R;
        % R36 = [ .  .  -c4*s5 ;  .  .  -s4*s5 ;  s5*c6  -s5*s6  c5 ]
        s5 = hypot(R36(1,3), R36(2,3));
        for sg = [1, -1]
            q5 = atan2(sg*s5, R36(3,3));
            if s5 < 1e-9                   % wrist singularity (q5 = 0 or 180)
                q4 = 0;
                if R36(3,3) > 0
                    q6 = atan2(R36(2,1),  R36(1,1));
                else
                    q6 = atan2(R36(2,1), -R36(1,1));
                end
            else
                q4 = atan2(-sg*R36(2,3), -sg*R36(1,3));
                q6 = atan2(-sg*R36(3,2),  sg*R36(3,1));
            end
            Q(end+1,:) = [q1 q2 q3 q4 q5 q6]; %#ok<AGROW>
        end
    end
end
Q = wrap_angle(Q);
end
