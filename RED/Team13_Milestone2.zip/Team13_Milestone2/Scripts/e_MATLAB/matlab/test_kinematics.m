%% test_kinematics.m - MATLAB test of FK, IK, velocity and acceleration
% Requirements R2 (FK/IK in MATLAB) and R5 (inverse result must match the
% kinematic equations within a small tolerance).
%
% Test 1  Home pose: flange must be at (0.374, 0, 0.630) m.
% Test 2  For every test pose: q -> FK -> IK (all 8 solutions).
%         a) every IK solution must give back the same pose (FK of it),
%         b) one solution inside the joint limits must equal the input q.
% Test 3  "Give angles" move (the same as in Simscape and Gazebo): the
%         robot goes from the start to the target angles at t = 1 s, smoothed
%         by 1/(0.2 s + 1)^2. Flange velocity v = Jv*qd and acceleration
%         a = Jv*qdd + Jv_dot*qd must equal the numerical derivative of the
%         FK position. The flange position at the end is printed (compare
%         with the Display in IRB120_Simple and with Gazebo).
% Results are printed as PASS / FAIL and saved in ../results/.
clear; close all;
P   = irb120_params();
tol = P.tol;
here = fileparts(mfilename('fullpath'));
outdir = fullfile(here, '..', 'results');
if ~isfolder(outdir), mkdir(outdir); end
allpass = true;

%% Test 1 - home pose
T0 = fk_irb120(zeros(6,1), P);
e1 = norm(T0(1:3,4) - [0.374; 0; 0.630]);
allpass = report('Test 1  home pose position', e1, tol.position_m) && allpass;

%% Test 2 - FK -> IK round trip for every test pose
n = size(P.test_poses, 1);
rows = zeros(n, 6+3+6+3);
fprintf('\nTest 2  FK -> IK round trip\n');
fprintf(' pose | flange x y z [m]           | #sol | pose err [m] | angle err [rad]\n');
for k = 1:n
    q  = P.test_poses(k,:).';
    T  = fk_irb120(q, P);
    Q  = ik_irb120(T, P);
    poseErr = 0;
    for s = 1:size(Q,1)
        Ts = fk_irb120(Q(s,:), P);
        poseErr = max(poseErr, max(abs(Ts(:) - T(:))));
    end
    qb = ik_best(T, P, q);
    if isempty(qb)
        angErr = inf;
        qb = nan(6,1);
    else
        angErr = max(abs(wrap_angle(qb - q)));
    end
    fprintf(' %4d | %8.4f %8.4f %8.4f | %4d | %12.2e | %12.2e\n', ...
        k, T(1,4), T(2,4), T(3,4), size(Q,1), poseErr, angErr);
    rows(k,:) = [rad2deg(q.'), T(1:3,4).', rad2deg(qb(:).'), poseErr, angErr, size(Q,1)];
    allpass = (poseErr < tol.position_m) && (angErr < tol.angle_rad) && allpass;
end
Tab = array2table(rows, 'VariableNames', ...
    {'q1_deg','q2_deg','q3_deg','q4_deg','q5_deg','q6_deg','x_m','y_m','z_m', ...
     'ik_q1_deg','ik_q2_deg','ik_q3_deg','ik_q4_deg','ik_q5_deg','ik_q6_deg', ...
     'pose_err_m','angle_err_rad','n_solutions'});
writetable(Tab, fullfile(outdir, 'matlab_fk_ik_test.csv'));

%% Test 2b - Newton-Raphson IK (numerical approach of Tutorial 04)
% Pose mode: 6 equations, initial guess = home pose [0 0 0 0 30 0] deg.
% Position mode: 3 equations (x, y, z), solves q1..q3, q4..q6 kept.
fprintf('\nTest 2b Newton-Raphson IK (initial guess = home pose)\n');
fprintf(' pose | mode     | iterations | |F|       | FK error [m] | inside limits\n');
qhome = deg2rad([0 0 0 0 30 0]).';
nrRows = zeros(n, 6);
for k = 1:n
    q = P.test_poses(k,:).';
    T = fk_irb120(q, P);
    [qn, it, res] = ik_newton_raphson(T, qhome, P);
    Tn = fk_irb120(qn, P);
    e  = max(abs(Tn(:) - T(:)));
    inl = all(qn >= P.qmin) && all(qn <= P.qmax);
    fprintf(' %4d | pose     | %10d | %8.1e | %12.1e | %d\n', k, it, res, e, inl);
    qg = [qhome(1:3); q(4:6)];                 % position mode: wrist angles known
    [qp, itp, resp] = ik_newton_raphson(T(1:3,4), qg, P);
    Tp = fk_irb120(qp, P);
    ep = norm(Tp(1:3,4) - T(1:3,4));
    fprintf(' %4d | position | %10d | %8.1e | %12.1e | %d\n', k, itp, resp, ep, ...
        all(qp >= P.qmin) && all(qp <= P.qmax));
    nrRows(k,:) = [k it e itp ep inl];
    allpass = (e < tol.position_m) && (ep < tol.position_m) && allpass;
end
writetable(array2table(nrRows, 'VariableNames', ...
    {'pose','pose_mode_iterations','pose_mode_err','position_mode_iterations','position_mode_err_m','inside_limits'}), ...
    fullfile(outdir, 'matlab_newton_raphson_test.csv'));

%% Test 3 - velocity and acceleration of the "give angles" move
mv = P.move;
t  = (0:mv.dt:mv.T).';
N  = numel(t);
Q = zeros(N,6); QD = Q; QDD = Q;
p = zeros(N,3); v = p; a = p;
for k = 1:N
    [qk, qdk, qddk] = step_motion(mv.q0, mv.q1, t(k), mv.ts, mv.tau);
    [pk, vk, ak] = ee_motion(qk, qdk, qddk, P);
    Q(k,:) = qk.'; QD(k,:) = qdk.'; QDD(k,:) = qddk.';
    p(k,:) = pk.'; v(k,:) = vk.'; a(k,:) = ak.';
end
% numerical derivative of the FK position with a very small step h
h = 1e-4; ev = 0; ea = 0;
for k = 2:N-1
    if abs(t(k) - mv.ts) < 2*h, continue; end      % acceleration jumps at the step
    pm = fk_irb120(step_motion(mv.q0, mv.q1, t(k)-h, mv.ts, mv.tau), P);
    pp = fk_irb120(step_motion(mv.q0, mv.q1, t(k)+h, mv.ts, mv.tau), P);
    vnum = (pp(1:3,4) - pm(1:3,4)) / (2*h);
    anum = (pp(1:3,4) - 2*p(k,:).' + pm(1:3,4)) / h^2;
    ev = max(ev, max(abs(vnum - v(k,:).')));
    ea = max(ea, max(abs(anum - a(k,:).')));
end
fprintf('\n');
allpass = report('Test 3a velocity  Jv*qd vs d/dt FK', ev, tol.velocity_m_s) && allpass;
allpass = report('Test 3b accel. Jv*qdd+Jvdot*qd vs d2/dt2 FK', ea, tol.acceleration_m_s2) && allpass;
names = [{'t'}, compose('q%d',1:6), compose('qd%d',1:6), compose('qdd%d',1:6), ...
         {'x','y','z','vx','vy','vz','ax','ay','az'}];
writetable(array2table([t Q QD QDD p v a], 'VariableNames', names), fullfile(outdir, 'matlab_move.csv'));
Tend = fk_irb120(mv.q1, P);
fprintf('Target %s deg -> flange (FK) at the end = [%.4f %.4f %.4f] m\n', ...
    mat2str(round(rad2deg(mv.q1.'), 2)), Tend(1:3,4));

%% Plots (R4: visualise the joint motion and the flange motion)
figure('Name','Joint motion');
subplot(3,1,1); plot(t, rad2deg(Q));   ylabel('q [deg]');      grid on; legend('q1','q2','q3','q4','q5','q6');
subplot(3,1,2); plot(t, rad2deg(QD));  ylabel('qd [deg/s]');   grid on;
subplot(3,1,3); plot(t, rad2deg(QDD)); ylabel('qdd [deg/s^2]'); grid on; xlabel('t [s]');
figure('Name','Flange motion (FK and Jacobian)');
subplot(3,1,1); plot(t, p); ylabel('p [m]');     grid on; legend('x','y','z');
subplot(3,1,2); plot(t, v); ylabel('v [m/s]');   grid on;
subplot(3,1,3); plot(t, a); ylabel('a [m/s^2]'); grid on; xlabel('t [s]');

fprintf('\n');
if allpass
    disp('ALL MATLAB KINEMATICS TESTS PASSED');
else
    disp('SOME TESTS FAILED - see above');
end

function ok = report(name, err, tolv)
ok = err < tolv;
s = 'FAIL'; if ok, s = 'PASS'; end
fprintf('%-46s max error %.2e (tol %.0e)  %s\n', name, err, tolv, s);
end
