% RUN_M2_TESTS  RED Milestone 2 tests in MATLAB (IRB 120, 6 joints).
% 1) Inverse position kinematics (Newton-Raphson) validated with the forward kinematics.
% 2) Inverse velocity kinematics validated with the forward velocity kinematics.
% Test cases: params/irb120_params.json, section "m2" (the same file the Python code uses).

clear; clc;
here = fileparts(mfilename('fullpath'));
S = jsondecode(fileread(fullfile(here, '..', 'params', 'irb120_params.json')));
C = S.m2;

syms q1 q2 q3 q4 q5 q6 real
X_fk = forward_kinematics_func();
fk = @(q) double(subs(X_fk, [q1 q2 q3 q4 q5 q6], q(:).'));

q0 = deg2rad(C.q0_deg(:));                 % initial guess, the same for all cases
fprintf('Initial guess q0 (deg): %s\n', mat2str(rad2deg(q0).', 6));

for c = 1:3
    fprintf('\n================ Case %d ================\n', c);
    Xd = C.X_mm(c, :).' / 1000;
    fprintf('Desired flange position (mm):   x=%9.3f  y=%9.3f  z=%9.3f\n', Xd * 1000);

    % ---- 1) inverse position kinematics, checked with the forward kinematics ----
    q = inverse_kinematics_func(q0, Xd);
    fprintf('IK joint angles (deg):          q1=%8.3f q2=%8.3f q3=%8.3f q4=%8.3f q5=%8.3f q6=%8.3f\n', rad2deg(q));
    X_check = fk(q);
    fprintf('FK of the IK angles (mm):       x=%9.3f  y=%9.3f  z=%9.3f\n', X_check * 1000);
    fprintf('Position error (mm):            %.2e\n', norm(X_check - Xd) * 1000);

    % ---- 2) inverse velocity kinematics, checked with the forward velocity kinematics ----
    V_d = [C.v_mm_s(c, :).' / 1000; deg2rad(C.w_deg_s(c, :).')];
    q_dot = inverse_velocity_kinematics(q, V_d);
    fprintf('Desired v (mm/s):               vx=%8.3f vy=%8.3f vz=%8.3f\n', V_d(1:3) * 1000);
    fprintf('Desired w (deg/s):              wx=%8.3f wy=%8.3f wz=%8.3f\n', rad2deg(V_d(4:6)));
    fprintf('IVK joint velocities (deg/s):   %8.3f %8.3f %8.3f %8.3f %8.3f %8.3f\n', rad2deg(q_dot));
    V_F = double(forward_velocity_kinematics(q, q_dot));
    fprintf('FVK v (mm/s):                   vx=%8.3f vy=%8.3f vz=%8.3f\n', V_F(1:3) * 1000);
    fprintf('FVK w (deg/s):                  wx=%8.3f wy=%8.3f wz=%8.3f\n', rad2deg(V_F(4:6)));
    fprintf('Velocity error: v %.2e mm/s, w %.2e deg/s\n', ...
            norm(V_F(1:3) - V_d(1:3)) * 1000, rad2deg(norm(V_F(4:6) - V_d(4:6))));

    % independent check of the linear part: numerical derivative of the FK
    dt = 1e-6;
    v_num = (fk(q + q_dot * dt) - fk(q - q_dot * dt)) / (2 * dt);
    fprintf('Numerical derivative check (mm/s): %.2e\n', norm(v_num - V_F(1:3)) * 1000);
end
