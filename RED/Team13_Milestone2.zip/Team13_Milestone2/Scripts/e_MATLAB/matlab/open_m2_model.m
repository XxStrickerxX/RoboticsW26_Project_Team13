function open_m2_model()
% OPEN_M2_MODEL  Open the Simscape model IRB120_M2 on any PC.
%   The model reads its CAD data (smiData) from IRB120_Assembly_DataFile7.m, which is
%   kept next to the model in this folder. This function points the model to that file,
%   then opens it. The STEP files of the CAD folder must be on the MATLAB path:
%       addpath('<path>/CAD_Model/CAD_Model');  open_m2_model
    here = fileparts(mfilename('fullpath'));
    mdl = 'IRB120_M2';
    if bdIsLoaded(mdl), close_system(mdl, 0); end
    w = warning('off', 'all');
    load_system(fullfile(here, [mdl '.slx']));
    warning(w);
    hws = get_param(mdl, 'ModelWorkspace');
    hws.FileName = fullfile(here, 'IRB120_Assembly_DataFile7.m');
    reload(hws);
    set_param(mdl, 'Dirty', 'off');
    open_system(mdl);
    fprintf('IRB120_M2 opened (data file: %s). Run set_m2_case(1), then press Run.\n', hws.FileName);
end
