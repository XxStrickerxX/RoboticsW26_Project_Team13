function [q, Q] = ik_best(T, P, qref)
%IK_BEST Pick one IK solution: inside the ABB joint limits and closest
%   to the reference angles qref (for example the current pose).
%   [q, Q] = ik_best(T, P, qref)   q = [] if no solution is allowed.
if nargin < 3, qref = zeros(6,1); end
Q = ik_irb120(T, P);
q = [];
best = inf;
for k = 1:size(Q,1)
    qk = Q(k,:).';
    if all(qk >= P.qmin - 1e-9) && all(qk <= P.qmax + 1e-9)
        cost = sum(wrap_angle(qk - qref(:)).^2);
        if cost < best
            best = cost;
            q = qk;
        end
    end
end
end
