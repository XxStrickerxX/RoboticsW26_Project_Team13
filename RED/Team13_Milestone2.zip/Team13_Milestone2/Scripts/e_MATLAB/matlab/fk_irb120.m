function [T, F] = fk_irb120(q, P)
%FK_IRB120 Forward kinematics of the IRB 120 (requirement R2).
%   [T, F] = fk_irb120(q, P)
%   q : 6 joint angles [rad]       P : struct from irb120_params()
%   T : 4x4 pose of the flange (frame 6) in the base frame (frame 0)
%   F : 4x4x7 array with all frames, F(:,:,1) = frame 0 ... F(:,:,7) = frame 6
q = q(:);
F = zeros(4,4,7);
F(:,:,1) = eye(4);
for i = 1:6
    F(:,:,i+1) = F(:,:,i) * dh_matrix(q(i) + P.offset(i), P.d(i), P.a(i), P.alpha(i));
end
T = F(:,:,7);
end
