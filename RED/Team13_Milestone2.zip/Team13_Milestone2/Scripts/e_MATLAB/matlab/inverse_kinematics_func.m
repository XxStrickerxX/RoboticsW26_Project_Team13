function q = inverse_kinematics_func(q0, X)
% INVERSE_KINEMATICS_FUNC  Inverse position kinematics by Newton-Raphson (RED Milestone 2).
%   q0 : 6x1 initial guess of the joint angles (rad)
%   X  : 3x1 desired flange position [x; y; z] in frame 0, metres
%   q  : 6x1 joint angles that move the flange to X (rad)
% Newton-Raphson (Tutorial 04):
%   F(q) = FK(q) - X_desired,     q_new = q_old - (dF/dq)^-1 * F(q_old)
% Here (dF/dq)^-1 is the pseudo-inverse from inverse_jacobian_matrix.
% Joint 6 turns the flange about its own axis, so it does not change X:
% q6 keeps its initial value.

    persistent X_fun
    if isempty(X_fun)
        syms q1 q2 q3 q4 q5 q6 real
        X_fk = forward_kinematics_func();        % symbolic FK from Milestone 1
        X_fun = matlabFunction(X_fk, 'Vars', {[q1; q2; q3; q4; q5; q6]});
    end

    q  = q0(:);
    Xd = X(:);
    tolerance = 1e-9;                            % stop when the error is below 1e-6 mm
    max_iterations = 100;

    for k = 1:max_iterations
        F = X_fun(q) - Xd;                       % position error with the current guess
        if norm(F) < tolerance
            break
        end
        q = q - inverse_jacobian_matrix(q) * F;  % Newton-Raphson step
        q = mod(q + pi, 2*pi) - pi;              % keep every angle in [-180, 180) deg
    end
    F = X_fun(q) - Xd;

    fprintf('IK: %d iterations, final error = %.2e mm\n', k, norm(F) * 1000);
    if norm(F) >= tolerance
        fprintf('IK warning: target not reached, it may be outside the workspace.\n');
    end
end
