% RUN_M2_SIMULINK_TESTS  Simscape model IRB120_M2 vs our equations, all three test cases.
% For each case: set_m2_case (IK + IVK functions) -> simulate -> compare
%   * at t = ik_check_s (robot at rest at the IK angles):
%       Simscape flange position  vs  desired X  and  vs  FK of the IK angles
%   * at the end (joints turning at the IVK speeds):
%       Simscape v, w  vs  FVK equations on the same joint signals, and vs the desired V
% Needs IRB120_M2.slx and IRB120_Assembly_DataFile7.m in this folder and the CAD STEP files on the path.
clear;
here = fileparts(mfilename('fullpath'));
S = jsondecode(fileread(fullfile(here, '..', 'params', 'irb120_params.json')));
M2 = S.m2;
mdl = 'IRB120_M2';
if ~bdIsLoaded(mdl), open_m2_model; end
outdir = fullfile(here, '..', 'results'); if ~isfolder(outdir), mkdir(outdir); end

R = zeros(3, 8);
for c = 1:3
    fprintf('\n================ Case %d ================\n', c);
    set_m2_case(c);
    m2 = evalin('base', 'm2_case');
    out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
    t  = out.sim_p.time;
    ps = rows3(out.sim_p.signals.values);  pe = rows3(out.eq_p.signals.values);
    vs = rows3(out.sim_v.signals.values);  ve = rows3(out.eq_v.signals.values);
    ws = rows3(out.sim_w.signals.values);  we = rows3(out.eq_w.signals.values);

    [~, k1] = min(abs(t - M2.ik_check_s));            % robot at rest at the IK angles
    k2 = numel(t);                                     % end: joints at the IVK speeds
    fprintf('t = %.1f s  Simscape flange (mm): [%9.3f %9.3f %9.3f]\n', t(k1), ps(k1, :) * 1000);
    fprintf('            desired X (mm):       [%9.3f %9.3f %9.3f]\n', m2.X_d * 1000);
    fprintf('            FK of IK angles (mm): [%9.3f %9.3f %9.3f]\n', pe(k1, :) * 1000);
    fprintf('            |Simscape - desired X| = %.3f mm,  |Simscape - FK| = %.3f mm\n', ...
            norm(ps(k1, :).' - m2.X_d) * 1000, norm(ps(k1, :) - pe(k1, :)) * 1000);
    fprintf('t = %.1f s  Simscape v (mm/s):    [%9.3f %9.3f %9.3f]   FVK: [%9.3f %9.3f %9.3f]\n', ...
            t(k2), vs(k2, :) * 1000, ve(k2, :) * 1000);
    fprintf('            Simscape w (deg/s):   [%9.3f %9.3f %9.3f]   FVK: [%9.3f %9.3f %9.3f]\n', ...
            rad2deg(ws(k2, :)), rad2deg(we(k2, :)));
    fprintf('            |Simscape - FVK|: v %.3f mm/s, w %.4f deg/s\n', ...
            norm(vs(k2, :) - ve(k2, :)) * 1000, rad2deg(norm(ws(k2, :) - we(k2, :))));
    fprintf('            (desired V at the IK pose: v [%g %g %g] mm/s, w [%g %g %g] deg/s;\n', ...
            m2.V_d(1:3) * 1000, rad2deg(m2.V_d(4:6)));
    fprintf('             the joints have turned since then, so V(t) has changed a little)\n');
    fprintf('            largest |Simscape - FK| position during the whole run: %.3f mm\n', ...
            max(vecnorm(ps - pe, 2, 2)) * 1000);
    R(c, :) = [norm(ps(k1, :).' - m2.X_d), norm(ps(k1, :) - pe(k1, :)), ...
               norm(vs(k2, :) - ve(k2, :)), norm(ws(k2, :) - we(k2, :)), max(vecnorm(ps - pe, 2, 2)), ...
               norm(ve(k2, :) - (m2.V_d(1:3)).'), norm(we(k2, :) - (m2.V_d(4:6)).'), t(k2)];
    writetable(array2table([t ps pe vs ve ws we], 'VariableNames', ...
        {'t','x','y','z','x_eq','y_eq','z_eq','vx','vy','vz','vx_eq','vy_eq','vz_eq', ...
         'wx','wy','wz','wx_eq','wy_eq','wz_eq'}), fullfile(outdir, sprintf('simscape_case%d.csv', c)));
end
fprintf('\nSummary (mm, mm/s, deg/s):\n case  |sim-Xd|  |sim-FK|  |v sim-FVK|  |w sim-FVK|  max|p sim-FK|\n');
for c = 1:3
    fprintf('  %d   %8.3f  %8.3f   %9.4f   %9.5f   %9.3f\n', c, R(c, 1:2) * 1000, R(c, 3) * 1000, ...
            rad2deg(R(c, 4)), R(c, 5) * 1000);
end

function X = rows3(x)
% logged signal -> N x 3 (the logger may save it as N x 3 or 3 x 1 x N)
x = squeeze(x);
if size(x, 2) ~= 3, x = x.'; end
X = x;
end
