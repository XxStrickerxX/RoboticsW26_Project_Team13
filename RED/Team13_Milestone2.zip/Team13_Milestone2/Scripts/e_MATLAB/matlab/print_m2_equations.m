% PRINT_M2_EQUATIONS  Prints the symbolic matrices of RED Milestone 2 (for the report and video).
% 1) dF/dq (3x6): derivative of the flange position, used by Newton-Raphson.
% 2) The 6x6 Jacobian J(q), column by column.
% 3) V_F = J(q) * q_dot.

clear; clc;
syms q1 q2 q3 q4 q5 q6 qd1 qd2 qd3 qd4 qd5 qd6 real
q  = [q1; q2; q3; q4; q5; q6];
qd = [qd1; qd2; qd3; qd4; qd5; qd6];

X = forward_kinematics_func();
fprintf('Flange position X(q) = [x; y; z]:\n');
for k = 1:3
    fprintf('  %s = %s\n', char('x' + k - 1), char(simplify(X(k))));
end

J = simplify(jacobian_matrix(q));
fprintf('\ndF/dq = rows 1-3 of J, Newton-Raphson uses pinv(dF/dq).\n');
fprintf('Note: column 6 of dF/dq is zero (joint 6 turns the flange about its own axis).\n');
fprintf('\nJacobian J(q), 6x6, [v; w] = J * q_dot:\n');
for c = 1:6
    fprintf('\n-- column %d (joint %d) --\n', c, c);
    for r = 1:6
        fprintf('  J(%d,%d) = %s\n', r, c, char(J(r, c)));
    end
end

V_F = forward_velocity_kinematics(q, qd);
fprintf('\nForward velocity kinematics V_F = J(q) * q_dot:\n');
names = {'vx','vy','vz','wx','wy','wz'};
for r = 1:6
    fprintf('  %s = %s\n', names{r}, char(simplify(V_F(r))));
end
