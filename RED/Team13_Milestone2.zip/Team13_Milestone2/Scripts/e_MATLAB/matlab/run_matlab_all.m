%% run_matlab_all.m - run all MATLAB parts of Milestone 01 in order
%   R1  dh_table           DH table, home pose, stick figure with frames
%   R1  derive_symbolic    symbolic A1..A6, T06, Jacobian (checks numeric code)
%   R2  test_kinematics    FK / IK / velocity / acceleration tests + plots
%   R2  build_fk_ik_simulink  Simulink model with FK and IK blocks
% Simscape (R3-R5) is separate: build_simple_model, press Run, then compare_simple_model.
% Sliders (R4, MATLAB window): robot_slider_gui
here = fileparts(mfilename('fullpath'));
cd(here);
dh_table;
derive_symbolic;
test_kinematics;
build_fk_ik_simulink;
