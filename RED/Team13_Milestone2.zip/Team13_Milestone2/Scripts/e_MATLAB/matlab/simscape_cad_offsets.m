function C = simscape_cad_offsets()
%SIMSCAPE_CAD_OFFSETS Link between the imported CAD (Simscape) model and
%   the DH model.
%
%   The Simscape model was imported from IRB120_Assembly.xml. Its World
%   frame is the SolidWorks assembly origin (y up, robot about 1.4 m away).
%   Each Simscape joint measures its angle from its own reference, so in
%   the CAD assembly pose the Simscape joints are NOT at 0.
%
%     C.W      : 4x4 pose of DH frame 0 in the Simscape World frame
%                (p_world = W * [p_dh; 1])   - fitted to the CAD joint axes
%     C.qcad   : DH joint angles of the CAD assembly pose [rad]
%                (q1 = q6 = 0 by choice; their zero is not set by the axes)
%     C.thcad  : Simscape joint angles q1..q6 in the CAD assembly pose [rad]
%                (Rz.Pos values written by smimport in the data file)
%     C.thcad_gripper : same for the gripper joint [rad]
%     C.sensor_d6 : distance wrist centre -> Simscape joint-6 frame (0.066 m)
%
%   Conversion (s = rotation direction of each joint, found by
%   run_simscape_test):   q_simscape = thcad + s .* (q_dh - qcad)
C.W = [ ...
    0.998881828613 -0.0472767538912 3.17615767366e-05 -1.38354723196 ;
    2.07691329412e-11 0.000671822570302 0.999999774327 0.480767101981 ;
    -0.0472767645603 -0.998881603192 0.000671071358508 -0.0167742737171 ;
    0 0 0 1 ];
C.qcad = [0 0.045218961956 0.0313343222616 0.0226005776809 0.0207912154836 0]';
C.thcad = deg2rad([177.26608008771987; -2.5898893926805675; -178.202363818192; ...
                   -1.3347057752895015; -1.1894102821108761; -133.24658312175282]);
C.thcad_gripper = deg2rad(-40.925789034501079);
C.sensor_d6 = 0.066;
end
