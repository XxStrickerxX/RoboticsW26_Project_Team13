%% dh_table.m - IRB 120 DH convention (Milestone 01, requirement R1)
% Prints the DH table, the 6 link transforms and checks the home pose.
% Convention: standard DH, A_i = Rz(theta_i)*Tz(d_i)*Tx(a_i)*Rx(alpha_i),
%             theta_i = q_i + offset_i.
% Frame 0 = robot base on the floor (z up, x forward).
% Frame 6 = tool flange (where the gripper is bolted).
clear; clc;
P = irb120_params();

names = {'q1','q2 - 90 deg','q3','q4','q5','q6'};
fprintf('IRB 120 DH table (standard convention)\n');
fprintf(' i | theta_i      | d_i [m] | a_i [m] | alpha_i [deg] | limits [deg]\n');
for i = 1:6
    fprintf(' %d | %-12s | %7.3f | %7.3f | %13.1f | %5.0f .. %4.0f\n', i, names{i}, ...
        P.d(i), P.a(i), rad2deg(P.alpha(i)), rad2deg(P.qmin(i)), rad2deg(P.qmax(i)));
end

% Home pose check: all joints at zero
T = fk_irb120(zeros(6,1), P);
fprintf('\nFlange pose at q = 0 (expected position 0.374 0 0.630 m):\n');
disp(round(T, 4));

% Draw the robot as a stick figure with its DH frames at the home pose
plot_robot(zeros(6,1), P);
title('IRB 120 at q = 0 with DH frames');
