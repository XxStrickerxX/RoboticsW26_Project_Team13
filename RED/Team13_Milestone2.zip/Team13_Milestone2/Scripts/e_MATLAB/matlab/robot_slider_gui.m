function robot_slider_gui()
%ROBOT_SLIDER_GUI Move the 6 joints with sliders and watch FK / IK live.
%   One slider per joint (limits from the ABB data sheet). For every
%   slider move the window shows the stick figure, the flange position
%   from FK, and the IK round-trip error (IK of that pose vs the sliders).
P = irb120_params();
fig = uifigure('Name', 'IRB 120 joint sliders (FK / IK)', 'Position', [100 100 1000 560]);
ax  = uiaxes(fig, 'Position', [380 60 600 480]);
lbl = uilabel(fig, 'Position', [20 20 950 30], 'FontSize', 13, 'Text', '');
sl  = gobjects(6,1);
for i = 1:6
    y = 500 - (i-1)*75;
    uilabel(fig, 'Position', [20 y 60 22], 'Text', sprintf('q%d [deg]', i));
    sl(i) = uislider(fig, 'Position', [90 y+10 260 3], ...
        'Limits', rad2deg([P.qmin(i) P.qmax(i)]), 'Value', 0, ...
        'ValueChangingFcn', @(src, evt) update(i, evt.Value));
end
q = zeros(6,1);
update(1, 0);

    function update(i, val)
        q(i) = deg2rad(val);
        plot_robot(q, P, ax);
        T  = fk_irb120(q, P);
        qb = ik_best(T, P, q);
        if isempty(qb)
            ikTxt = 'IK: no solution inside limits';
        else
            ikTxt = sprintf('IK round-trip error = %.1e rad', max(abs(wrap_angle(qb - q))));
        end
        lbl.Text = sprintf('Flange (FK): x = %.4f  y = %.4f  z = %.4f m      %s', ...
            T(1,4), T(2,4), T(3,4), ikTxt);
    end
end
