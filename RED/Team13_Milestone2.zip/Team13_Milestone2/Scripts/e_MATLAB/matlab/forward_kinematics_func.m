function [X, T] = forward_kinematics_func()
% FORWARD_KINEMATICS_FUNC  Symbolic forward kinematics of the IRB 120 (from Milestone 1).
%   X : 3x1 symbolic flange position [x; y; z] in frame 0 (robot base on the floor), metres
%   T : 1x6 cell, T{i} = symbolic pose of frame i in frame 0 (T{6} = flange)
% Same DH table and DH matrix as Milestone 1 (fk_irb120.m, dh_matrix.m, irb120_params.json);
% here the joint angles are symbols q1..q6 and the lengths are numbers.

    syms q1 q2 q3 q4 q5 q6 real
    q = [q1; q2; q3; q4; q5; q6];
    P = irb120_params();                         % DH table of Milestone 1

    T = cell(1, 6);
    A = sym(eye(4));
    for i = 1:6
        alpha = sym(round(P.alpha(i) * 2 / pi)) * sym(pi) / 2;     % exact -90, 0, +90 deg
        offset = sym(round(P.offset(i) * 2 / pi)) * sym(pi) / 2;
        A = A * dh_matrix(q(i) + offset, sym(P.d(i)), sym(P.a(i)), alpha);
        T{i} = A;
    end
    X = T{6}(1:3, 4);
end
