%% build_fk_ik_simulink.m - Simulink model for FK and IK (requirement R2)
% Creates IRB120_FK_IK.slx:
%   [6 joint angles, deg] -> FK block -> flange position (Display)
%                         -> IK block -> joint angles back (Display)
%                         -> round-trip error (Display)
% The two MATLAB Function blocks call fk_irb120 / ik_best (extrinsic),
% so Simulink uses exactly the same equations as the MATLAB scripts.
% Change the Constant "q_deg" (or the slider) and press Run.
clear;
mdl = 'IRB120_FK_IK';
here = fileparts(mfilename('fullpath'));
if bdIsLoaded(mdl), close_system(mdl, 0); end
if isfile(fullfile(here, [mdl '.slx'])), delete(fullfile(here, [mdl '.slx'])); end
new_system(mdl); open_system(mdl);
set_param(mdl, 'StopTime', '1', 'Solver', 'FixedStepDiscrete', 'FixedStep', '0.1');

% Joint angle input (degrees)
add_block('simulink/Sources/Constant', [mdl '/q_deg'], ...
    'Value', '[30 20 10 40 50 60]''', 'Position', [40 100 160 130]);
add_block('simulink/Math Operations/Gain', [mdl '/deg2rad'], ...
    'Gain', 'pi/180', 'Position', [200 100 250 130]);

% FK block
add_block('simulink/User-Defined Functions/MATLAB Function', [mdl '/FK']);
set_param([mdl '/FK'], 'Position', [300 60 420 120]);
setScript([mdl '/FK'], sprintf([ ...
    'function p = FK(q)\n' ...
    'coder.extrinsic(''irb120_params'', ''fk_irb120'');\n' ...
    'p = zeros(3,1);\n' ...
    'P = irb120_params();\n' ...
    'T = zeros(4,4);\n' ...
    'T = fk_irb120(q, P);\n' ...
    'p = T(1:3,4);\n']));

% IK block (uses the pose from FK of the same angles)
add_block('simulink/User-Defined Functions/MATLAB Function', [mdl '/IK']);
set_param([mdl '/IK'], 'Position', [300 160 420 220]);
setScript([mdl '/IK'], sprintf([ ...
    'function [q_ik, err] = IK(q)\n' ...
    'coder.extrinsic(''irb120_params'', ''fk_irb120'', ''ik_best'', ''wrap_angle'');\n' ...
    'q_ik = zeros(6,1); err = 0;\n' ...
    'P = irb120_params();\n' ...
    'T = zeros(4,4);\n' ...
    'T = fk_irb120(q, P);\n' ...
    'q_ik = ik_best(T, P, q);\n' ...
    'd = zeros(6,1);\n' ...
    'd = wrap_angle(q_ik - q);\n' ...
    'err = max(abs(d));\n']));

add_block('simulink/Sinks/Display', [mdl '/flange_xyz_m'],  'Position', [480 70 600 110]);
add_block('simulink/Math Operations/Gain', [mdl '/rad2deg'], 'Gain', '180/pi', 'Position', [460 160 500 190]);
add_block('simulink/Sinks/Display', [mdl '/ik_q_deg'],      'Position', [540 150 660 200]);
add_block('simulink/Sinks/Display', [mdl '/ik_error_rad'],  'Position', [480 220 600 250]);

add_line(mdl, 'q_deg/1', 'deg2rad/1');
add_line(mdl, 'deg2rad/1', 'FK/1', 'autorouting', 'on');
add_line(mdl, 'deg2rad/1', 'IK/1', 'autorouting', 'on');
add_line(mdl, 'FK/1', 'flange_xyz_m/1');
add_line(mdl, 'IK/1', 'rad2deg/1');
add_line(mdl, 'rad2deg/1', 'ik_q_deg/1');
add_line(mdl, 'IK/2', 'ik_error_rad/1', 'autorouting', 'on');

save_system(mdl, fullfile(here, [mdl '.slx']));
sim(mdl);
fprintf('Built and ran %s.slx - look at the Display blocks.\n', mdl);

function setScript(blk, code)
rt = sfroot;
ch = rt.find('-isa', 'Stateflow.EMChart', 'Path', blk);
ch.Script = code;
end
