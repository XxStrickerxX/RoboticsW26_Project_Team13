function q_dot = inverse_velocity_kinematics(q, V_F)
% INVERSE_VELOCITY_KINEMATICS  Joint velocities for a desired flange velocity (RED Milestone 2).
%   q     : 6x1 numeric joint angles (rad)
%   V_F   : 6x1 desired [vx; vy; vz; wx; wy; wz] (m/s, rad/s, frame 0 axes)
%   q_dot : 6x1 joint velocities (rad/s)
% Inverse velocity kinematics:  q_dot = J_inv(q) * V_F
% J_inv is the pseudo-inverse of the 6x6 Jacobian (equal to the normal inverse
% when the robot is not at a singular pose).

    J = double(jacobian_matrix(q));
    J_inv = pinv(J);
    q_dot = J_inv * V_F(:);
end
