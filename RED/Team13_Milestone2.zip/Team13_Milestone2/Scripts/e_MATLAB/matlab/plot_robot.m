function h = plot_robot(q, P, ax)
%PLOT_ROBOT Stick figure of the IRB 120 with its DH frames (x red,
%   y green, z blue). h = plot_robot(q, P, ax)
if nargin < 3 || isempty(ax)
    figure('Name','IRB 120'); ax = gca;
end
[~, F] = fk_irb120(q, P);
o = squeeze(F(1:3,4,:));
cla(ax); hold(ax, 'on'); grid(ax, 'on'); axis(ax, 'equal');
h = plot3(ax, o(1,:), o(2,:), o(3,:), '-o', 'LineWidth', 3, ...
          'Color', [0.3 0.3 0.3], 'MarkerFaceColor', 'k');
L = 0.05;                                   % frame axis length [m]
c = 'rgb';
for i = 1:7
    for k = 1:3
        e = o(:,i) + L*F(1:3,k,i);
        plot3(ax, [o(1,i) e(1)], [o(2,i) e(2)], [o(3,i) e(3)], c(k), 'LineWidth', 1.5);
    end
end
xlabel(ax,'x [m]'); ylabel(ax,'y [m]'); zlabel(ax,'z [m]');
xlim(ax,[-0.6 0.6]); ylim(ax,[-0.6 0.6]); zlim(ax,[0 0.9]);
view(ax, 35, 20);
hold(ax, 'off');
end
