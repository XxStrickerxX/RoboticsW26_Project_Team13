function J = jacobian_matrix(q)
% JACOBIAN_MATRIX  Symbolic 6x6 Jacobian of the IRB 120 (RED Milestone 2).
%   q : 6x1 joint angles, symbolic ([q1;...;q6]) or numeric (rad)
%   J : 6x6 Jacobian,  [v; w] = J * q_dot   (Tutorial 05)
% Rows 1-3 (Jv): differentiate the flange position x, y, z with respect to each joint
%                angle (differentiation approach).
% Rows 4-6 (Jw): all joints are revolute, so column i is the z axis of frame i-1.

    syms q1 q2 q3 q4 q5 q6 real
    [X, T] = forward_kinematics_func();

    % ----- linear velocity part: dX/dq -----
    Jv = jacobian(X, [q1, q2, q3, q4, q5, q6]);

    % ----- angular velocity part: z axes of frames 0 ... 5 -----
    Jw = [[0; 0; 1], T{1}(1:3,3), T{2}(1:3,3), T{3}(1:3,3), T{4}(1:3,3), T{5}(1:3,3)];

    J = [Jv; Jw];

    % put in the joint angles that were passed in (symbols or numbers)
    J = subs(J, [q1, q2, q3, q4, q5, q6], q(:).');
end
