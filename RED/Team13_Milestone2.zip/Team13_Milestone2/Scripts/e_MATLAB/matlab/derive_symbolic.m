%% derive_symbolic.m - Symbolic derivation with the Symbolic Math Toolbox
% Covers R1 (DH transforms) and R2 (FK equations, Jacobian).
% 1) Builds A1..A6 and T06 = A1*A2*...*A6 symbolically.
% 2) Prints the flange position p(q) = T06(1:3,4) as equations.
% 3) Derives the linear Jacobian Jv = dp/dq and its time derivative
%    Jv_dot = sum_k dJv/dq_k * qd_k.
% 4) Checks the symbolic results against the numeric functions
%    (fk_irb120, jacobian_irb120, jacobian_dot_irb120) at random angles.
clear;
P = irb120_params();

syms q1 q2 q3 q4 q5 q6 qd1 qd2 qd3 qd4 qd5 qd6 real
q  = [q1 q2 q3 q4 q5 q6].';
qd = [qd1 qd2 qd3 qd4 qd5 qd6].';
syms d1 a2 a3 d4 d6 real                 % link lengths kept as symbols

% DH table (theta, d, a, alpha) - same numbers as irb120_params.json
DH = [ q1          d1  0   -sym(pi)/2
       q2-sym(pi)/2 0  a2   0
       q3          0   a3  -sym(pi)/2
       q4          d4  0    sym(pi)/2
       q5          0   0   -sym(pi)/2
       q6          d6  0    0        ];

T = sym(eye(4));
A = cell(1,6);
for i = 1:6
    A{i} = dh_matrix(DH(i,1), DH(i,2), DH(i,3), DH(i,4));
    T = T * A{i};
end
T = simplify(T);

% Course steps (Tutorial 03): 1) axes  2) DH table  3) DH matrices  4) total matrix
disp('Step 3 - DH transformation matrices  (i-1)T(i):');
for i = 1:6
    fprintf('\n%dT%d =\n', i-1, i); disp(simplify(A{i}));
end
disp('Step 4 - total transformation 0T6 = 0T1*1T2*2T3*3T4*4T5*5T6:');
names = {'a11','a12','a13';'a21','a22','a23';'a31','a32','a33'};
for r = 1:3
    for c = 1:3
        fprintf('  %s = %s\n', names{r,c}, char(T(r,c)));
    end
end
disp('Flange position (X, Y, Z) = 0T6(1:3,4):');
p = T(1:3,4);
for k = 1:3
    fprintf('  %s = %s\n', char('X'+k-1), char(p(k)));
end

% Linear Jacobian and its derivative
Jv    = jacobian(p, q);
Jvdot = sym(zeros(3,6));
for k = 1:6
    Jvdot = Jvdot + diff(Jv, q(k)) * qd(k);
end

% Numeric check against the hand-written functions
vals = [P.d(1) P.a(2) P.a(3) P.d(4) P.d(6)];
pN  = matlabFunction(subs(p,     [d1 a2 a3 d4 d6], vals), 'Vars', {q});
JN  = matlabFunction(subs(Jv,    [d1 a2 a3 d4 d6], vals), 'Vars', {q});
JdN = matlabFunction(subs(Jvdot, [d1 a2 a3 d4 d6], vals), 'Vars', {q, qd});

rng(1);
err = zeros(1,3);
for k = 1:20
    qq  = (rand(6,1)-0.5)*2;
    qqd = (rand(6,1)-0.5)*2;
    Tn  = fk_irb120(qq, P);
    Jn  = jacobian_irb120(qq, P);
    Jdn = jacobian_dot_irb120(qq, qqd, P);
    err(1) = max(err(1), max(abs(pN(qq) - Tn(1:3,4))));
    err(2) = max(err(2), max(abs(JN(qq) - Jn(1:3,:)), [], 'all'));
    err(3) = max(err(3), max(abs(JdN(qq,qqd) - Jdn(1:3,:)), [], 'all'));
end
fprintf('\nSymbolic vs numeric (20 random poses):\n');
fprintf('  position     max difference = %.2e m\n', err(1));
fprintf('  Jacobian Jv  max difference = %.2e\n', err(2));
fprintf('  Jv_dot       max difference = %.2e\n', err(3));
if all(err < 1e-9)
    disp('  PASS: symbolic and numeric kinematics agree.');
else
    disp('  FAIL: check the DH table.');
end
save(fullfile(fileparts(mfilename('fullpath')), 'symbolic_results.mat'), 'T', 'p', 'Jv', 'Jvdot');
