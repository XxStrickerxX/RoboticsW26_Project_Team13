function set_m2_case(c)
% SET_M2_CASE  Put test case c (1, 2 or 3) into the Simscape model IRB120_M2.
%   Runs our functions for the case:
%     q     = inverse_kinematics_func(q0, X_desired)       -> the Step blocks qN_ik_deg
%     q_dot = inverse_velocity_kinematics(q, V_desired)    -> the Ramp blocks qN_ivk_deg_s
%   Then press Run (or use run_m2_simulink_tests for all cases).
    mdl = 'IRB120_M2';
    if ~bdIsLoaded(mdl), open_m2_model; end
    here = fileparts(mfilename('fullpath'));
    S = jsondecode(fileread(fullfile(here, '..', 'params', 'irb120_params.json')));
    M2 = S.m2;

    q0  = deg2rad(M2.q0_deg(:));
    Xd  = M2.X_mm(c, :).' / 1000;
    V_d = [M2.v_mm_s(c, :).' / 1000; deg2rad(M2.w_deg_s(c, :).')];
    fprintf('Case %d: X = [%g %g %g] mm, v = [%g %g %g] mm/s, w = [%g %g %g] deg/s\n', ...
            c, M2.X_mm(c, :), M2.v_mm_s(c, :), M2.w_deg_s(c, :));
    q     = inverse_kinematics_func(q0, Xd);
    q_dot = inverse_velocity_kinematics(q, V_d);

    for i = 1:6
        set_param(sprintf('%s/q%d_ik_deg', mdl, i), 'After', sprintf('%.10g', rad2deg(q(i))));
        set_param(sprintf('%s/q%d_ivk_deg_s', mdl, i), 'slope', sprintf('%.10g', rad2deg(q_dot(i))));
    end
    fprintf('IK angles  (deg)  : %s\n', mat2str(round(rad2deg(q.'), 3)));
    fprintf('IVK speeds (deg/s): %s\n', mat2str(round(rad2deg(q_dot.'), 3)));
    assignin('base', 'm2_case', struct('c', c, 'X_d', Xd, 'V_d', V_d, 'q', q, 'q_dot', q_dot));
    notes = find_system(mdl, 'FindAll', 'on', 'Type', 'annotation');      % the case note at the top
    if isempty(notes), return; end
    notes = notes(startsWith(string(get_param(notes, 'Text')), 'Case'));
    if isempty(notes), return; end
    set_param(notes(1), 'Text', sprintf(['Case %d:  X desired = [%g %g %g] mm,  v = [%g %g %g] mm/s,  w = [%g %g %g] deg/s\n' ...
        'IK angles (deg) = %s   (Step blocks, t = %g s)\nIVK speeds (deg/s) = %s   (Ramp blocks, from t = %g s)'], ...
        c, M2.X_mm(c, :), M2.v_mm_s(c, :), M2.w_deg_s(c, :), mat2str(round(rad2deg(q.'), 3)), M2.step_time_s, ...
        mat2str(round(rad2deg(q_dot.'), 3)), M2.ramp_start_s));
end
