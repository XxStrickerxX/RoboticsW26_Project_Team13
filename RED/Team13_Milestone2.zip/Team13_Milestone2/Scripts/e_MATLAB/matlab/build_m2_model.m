%% build_m2_model.m - RED Milestone 2 Simscape model of the IRB 120 (same format as Milestone 1)
% Builds IRB120_M2.slx from the SolidWorks XML (smimport), exactly like
% build_simple_model.m of Milestone 1, with one input row per joint:
%
%   [Step: IK angle, deg] --+
%                           Sum -> [Transfer Fcn 1/(0.2s+1)^2] -> [Gain: deg->rad, direction]
%   [Ramp: IVK speed, deg/s]+      -> [Bias: CAD zero] -> [Simulink-PS Converter] -> joint
%
%   * Step  (qN_ik_deg): home (0) until t = 1 s, then the angle found by
%     inverse_kinematics_func -> the flange goes to the desired X.
%   * Ramp  (qN_ivk_deg_s): from t = 4 s the joint also turns at the speed found by
%     inverse_velocity_kinematics -> the flange moves with the desired V.
%   * Transfer Fcn, Gain, Bias, Simulink-PS Converter: the same as Milestone 1.
%
% One Transform Sensor measures the flange: position, linear velocity and
% angular velocity, converted to the robot base frame.
% Two MATLAB Function blocks evaluate our equations on the same joint signals:
%   "FK equations"  -> p = forward kinematics (fk_equations.m, made from forward_kinematics_func)
%   "FVK equations" -> [v; w] = J(q) * q_dot (jacobian_equations.m, made from jacobian_matrix)
% Displays show Simscape, the equations and their difference.
%
% Use: set the CAD folder (environment variable RED_CAD_DIR, default ~/CAD_Model/CAD_Model),
% run this script once, then  set_m2_case(1)  (or 2, 3)  and press Run,
% or run  run_m2_simulink_tests  for all three cases.
clear;
here   = fileparts(mfilename('fullpath'));
cadDir = getenv('RED_CAD_DIR');
if isempty(cadDir), cadDir = fullfile(getenv('HOME'), 'CAD_Model', 'CAD_Model'); end
mdl    = 'IRB120_M2';
addpath(here); addpath(cadDir);
C = simscape_cad_offsets();
s = [-1 -1 1 -1 -1 -1].';                 % joint directions: Milestone 1 default, but joint 6 is -1
                                           % (found in M2 from the angular velocity; the position
                                           %  cannot show it, joint 6 does not move the flange point)
P = irb120_params();
tau = P.move.tau;                          % smoothing time constant [s]
S = jsondecode(fileread(fullfile(here, '..', 'params', 'irb120_params.json')));
M2 = S.m2;

%% numeric copies of our symbolic functions, used inside the MATLAB Function blocks
syms q1 q2 q3 q4 q5 q6 real
qs = [q1; q2; q3; q4; q5; q6];
X = forward_kinematics_func();
matlabFunction(X, 'Vars', {qs}, 'File', fullfile(here, 'fk_equations.m'));
matlabFunction(jacobian_matrix(qs), 'Vars', {qs}, 'File', fullfile(here, 'jacobian_equations.m'));
rehash;

%% import the CAD model (same XML as Milestone 1)
if bdIsLoaded(mdl), close_system(mdl, 0); end
old = pwd; cd(cadDir);
smimport('IRB120_Assembly.xml', 'ModelName', mdl);
cd(old);

%% find the joints (q1..q6 and gripper) by the parts they connect
J = find_system(mdl, 'SearchDepth', 1, 'LookUnderMasks', 'all', 'FollowLinks', 'on', ...
                'RegExp', 'on', 'ReferenceBlock', 'Revolute Joint');
pairs = {'BASE','J1'; 'J1','Link2'; 'Link2','Link3'; 'Link3','Wrist1'; ...
         'Wrist1','Wrist2'; 'Wrist2','Wrist3'; 'Wrist3','Gripper'};
names = {'q1','q2','q3','q4','q5','q6','gripper'};
jb = cell(7,1);
for k = 1:numel(J)
    nb = connectedNames(J{k});
    for i = 1:7
        hit = any(contains(nb, pairs{i,1})) && any(contains(nb, pairs{i,2}));
        if i < 7, hit = hit && ~any(contains(nb, 'Gripper')); end
        if hit, jb{i} = J{k}; end
    end
end

%% one input row per joint
for i = 1:7
    b = jb{i};
    try                                                 % torque computed by Simscape
        set_param(b, 'TorqueActuationMode', 'ComputedTorque');
    catch
        setEnum(b, 'Torque.*Actuat', 'Comput|Automatic');
    end
    h0 = allPorts(b);
    try                                                 % motion provided by input
        set_param(b, 'MotionActuationMode', 'InputMotion');
    catch
        setEnum(b, 'Motion.*Actuat', 'Input|Provided');
    end
    qin = setdiff(allPorts(b), h0);                     % the new input port "q"
    if i <= 6
        gain = s(i)*pi/180;
        bias = C.thcad(i) - s(i)*C.qcad(i);   % q_cad = s*q_dh + (thcad - s*qcad)
    else                                       % gripper: held at its CAD angle
        gain = pi/180;
        bias = C.thcad_gripper;
    end
    y = 80 + (i-1)*90; n = names{i};
    if i <= 6
        add_block('simulink/Sources/Step', [mdl '/' n '_ik_deg'], 'Time', num2str(M2.step_time_s), ...
            'Before', '0', 'After', '0', 'Position', [-960 y-15 -920 y+15]);
        add_block('simulink/Sources/Ramp', [mdl '/' n '_ivk_deg_s'], 'slope', '0', ...
            'start', num2str(M2.ramp_start_s), 'InitialOutput', '0', 'Position', [-960 y+25 -920 y+55]);
        add_block('simulink/Math Operations/Sum', [mdl '/' n '_input_deg'], 'Inputs', '++', ...
            'Position', [-860 y -830 y+30]);
        add_line(mdl, [n '_ik_deg/1'], [n '_input_deg/1']);
        add_line(mdl, [n '_ivk_deg_s/1'], [n '_input_deg/2']);
        src = [n '_input_deg/1'];
    else
        add_block('simulink/Sources/Step', [mdl '/' n '_target_deg'], 'Time', num2str(M2.step_time_s), ...
            'Before', '0', 'After', '0', 'Position', [-860 y -820 y+30]);
        src = [n '_target_deg/1'];
    end
    add_block('simulink/Continuous/Transfer Fcn', [mdl '/' n '_smooth'], ...
        'Numerator', '1', 'Denominator', sprintf('[%g %g 1]', tau^2, 2*tau), ...
        'Position', [-770 y -710 y+30]);
    add_block('simulink/Math Operations/Gain', [mdl '/' n '_deg2rad_dir'], ...
        'Gain', sprintf('%.15g', gain), 'Position', [-680 y -630 y+30]);
    add_block('simulink/Math Operations/Bias', [mdl '/' n '_cad_zero'], ...
        'Bias', sprintf('%.15g', bias), 'Position', [-590 y -540 y+30]);
    add_block('nesl_utility/Simulink-PS Converter', [mdl '/' n '_to_joint'], 'Unit', 'rad', ...
        'FilteringAndDerivatives', 'filter', 'SimscapeFilterOrder', '2', ...
        'InputFilterTimeConstant', '0.001', 'Position', [-500 y -460 y+30]);
    add_line(mdl, src, [n '_smooth/1']);
    add_line(mdl, [n '_smooth/1'], [n '_deg2rad_dir/1']);
    add_line(mdl, [n '_deg2rad_dir/1'], [n '_cad_zero/1']);
    add_line(mdl, [n '_cad_zero/1'], [n '_to_joint/1']);
    pc = get_param([mdl '/' n '_to_joint'], 'PortHandles');
    add_line(mdl, pc.RConn(1), qin);
    if i <= 6                                  % the joint angle (deg) also goes to the equations
        add_block('simulink/Signal Routing/Goto', [mdl '/goto_' n], 'GotoTag', [n '_deg'], ...
            'Position', [-740 y+40 -700 y+60]);
        add_line(mdl, [n '_smooth/1'], ['goto_' n '/1']);
    end
end

%% flange sensor: World -> flange, shown in the robot base frame
% The joint-6 frame of the CAD is 0.066 m after the wrist centre; the DH flange is at
% 0.072 m, so a Rigid Transform moves the measured point 6 mm along the joint-6 axis.
W  = find_system(mdl, 'SearchDepth', 1, 'LookUnderMasks', 'all', 'FollowLinks', 'on', ...
                 'RegExp', 'on', 'ReferenceBlock', 'World Frame$');
rt = [mdl '/to_flange_6mm'];
add_block('sm_lib/Frames and Transforms/Rigid Transform', rt, 'Position', [-860 760 -820 800]);
set_param(rt, 'TranslationMethod', 'Cartesian', 'TranslationCartesianOffset', '[0 0 0.006]', ...
    'TranslationCartesianOffsetUnits', 'm');
sb = [mdl '/flange_sensor'];
add_block('sm_lib/Frames and Transforms/Transform Sensor', sb, 'Position', [-760 800 -680 900]);
pT = get_param(sb, 'PortHandles'); pW = get_param(W{1}, 'PortHandles'); pR = get_param(rt, 'PortHandles');
add_line(mdl, pW.RConn(1), pT.LConn(1));
add_line(mdl, framePortTo(jb{6}, 'Wrist3'), pR.LConn(1));
add_line(mdl, pR.RConn(1), pT.RConn(1));
Rt = C.W(1:3,1:3).';  t0 = C.W(1:3,4);
outs  = {'SenseXYZ', 'SenseXYZDot', angularVelocityParam(sb)};
label = {'p','v','w'}; units = {'m','m/s','rad/s'};
add_block('simulink/Sinks/Scope', [mdl '/flange_p_v_w'], 'NumInputPorts', '3', ...
    'Position', [-300 800 -260 900]);
for m = [3 1 2]      % rotational output first: the sensor lists it before the translational ones
    h0 = allPorts(sb);
    set_param(sb, outs{m}, 'on');
    hp = setdiff(allPorts(sb), h0);
    y = 780 + m*45;
    add_block('nesl_utility/PS-Simulink Converter', [mdl '/flange_' label{m}], 'Unit', units{m}, ...
        'Position', [-640 y -600 y+25]);
    add_block('simulink/Math Operations/Gain', [mdl '/to_base_' label{m}], 'Gain', mat2str(Rt, 15), ...
        'Multiplication', 'Matrix(K*u)', 'Position', [-560 y -510 y+25]);
    pc = get_param([mdl '/flange_' label{m}], 'PortHandles');
    add_line(mdl, hp, pc.LConn(1));
    add_line(mdl, ['flange_' label{m} '/1'], ['to_base_' label{m} '/1']);
    add_block('simulink/Sinks/To Workspace', [mdl '/sim_' label{m}], 'VariableName', ['sim_' label{m}], ...
        'SaveFormat', 'Structure With Time', 'Position', [-300 900+m*40 -230 920+m*40]);
    if m == 1                                       % position also needs the offset
        add_block('simulink/Math Operations/Bias', [mdl '/base_offset_p'], ...
            'Bias', mat2str(-Rt*t0, 15), 'Position', [-470 y -420 y+25]);
        add_line(mdl, 'to_base_p/1', 'base_offset_p/1');
        sim_out{m} = 'base_offset_p/1'; %#ok<SAGROW>
    else
        sim_out{m} = ['to_base_' label{m} '/1']; %#ok<SAGROW>
    end
    add_line(mdl, sim_out{m}, sprintf('flange_p_v_w/%d', m), 'autorouting', 'on');
    add_line(mdl, sim_out{m}, ['sim_' label{m} '/1'], 'autorouting', 'on');
end

%% our equations on the same joint signals (MATLAB Function blocks)
rtSF = sfroot;
fkb  = [mdl '/FK equations'];   fvkb = [mdl '/FVK equations'];
add_block('simulink/User-Defined Functions/MATLAB Function', fkb,  'Position', [-120 1100 0 1280]);
add_block('simulink/User-Defined Functions/MATLAB Function', fvkb, 'Position', [-120 1340 0 1640]);
ch = rtSF.find('-isa', 'Stateflow.EMChart', 'Path', fkb);
ch.Script = sprintf(['function p = fk_block(q1, q2, q3, q4, q5, q6)\n' ...
    '%% Forward kinematics of Milestone 1 (fk_equations.m is made from forward_kinematics_func)\n' ...
    '%% inputs: joint angles in deg, output: flange position in m (base frame)\n' ...
    'p = fk_equations(pi/180*[q1; q2; q3; q4; q5; q6]);\n']);
ch = rtSF.find('-isa', 'Stateflow.EMChart', 'Path', fvkb);
ch.Script = sprintf(['function [v, w] = fvk_block(q1, q2, q3, q4, q5, q6, qd1, qd2, qd3, qd4, qd5, qd6)\n' ...
    '%% Forward velocity kinematics V_F = J(q) * q_dot (jacobian_equations.m is made from jacobian_matrix)\n' ...
    '%% inputs: joint angles in deg and joint speeds in deg/s, outputs: v in m/s, w in rad/s\n' ...
    'V = jacobian_equations(pi/180*[q1; q2; q3; q4; q5; q6]) * (pi/180*[qd1; qd2; qd3; qd4; qd5; qd6]);\n' ...
    'v = V(1:3);\n' ...
    'w = V(4:6);\n']);
for i = 1:6
    y = 1080 + 30*i;
    add_block('simulink/Signal Routing/From', sprintf('%s/from_q%d_fk', mdl, i), 'GotoTag', sprintf('q%d_deg', i), ...
        'Position', [-260 y -220 y+20]);
    add_line(mdl, sprintf('from_q%d_fk/1', i), sprintf('FK equations/%d', i));
    y = 1320 + 24*i;
    add_block('simulink/Signal Routing/From', sprintf('%s/from_q%d_fvk', mdl, i), 'GotoTag', sprintf('q%d_deg', i), ...
        'Position', [-360 y -320 y+18]);
    add_line(mdl, sprintf('from_q%d_fvk/1', i), sprintf('FVK equations/%d', i));
    y = 1480 + 24*i;
    add_block('simulink/Signal Routing/From', sprintf('%s/from_q%d_rate', mdl, i), 'GotoTag', sprintf('q%d_deg', i), ...
        'Position', [-360 y -320 y+18]);
    add_block('simulink/Continuous/Derivative', sprintf('%s/qd%d_deg_s', mdl, i), 'Position', [-280 y -240 y+18]);
    add_line(mdl, sprintf('from_q%d_rate/1', i), sprintf('qd%d_deg_s/1', i));
    add_line(mdl, sprintf('qd%d_deg_s/1', i), sprintf('FVK equations/%d', i+6));
end

%% displays: Simscape, equations, difference
eq_out = {'FK equations/1', 'FVK equations/1', 'FVK equations/2'};
dname  = {'position p', 'linear velocity v', 'angular velocity w'};
dunit  = {'(mm)', '(mm per s)', '(deg per s)'};      % no "/" in block names
dgain  = {'1000', '1000', '180/pi'};
for m = 1:3
    y = 1100 + (m-1)*200;
    add_block('simulink/Sinks/Display', sprintf('%s/Simscape %s %s', mdl, dname{m}, dunit{m}), ...
        'Position', [300 y 460 y+50]);
    add_block('simulink/Sinks/Display', sprintf('%s/Equations %s %s', mdl, dname{m}, dunit{m}), ...
        'Position', [300 y+60 460 y+110]);
    add_block('simulink/Sinks/Display', sprintf('%s/Simscape - equations %s %s', mdl, dname{m}, dunit{m}), ...
        'Position', [300 y+120 460 y+170]);
    add_block('simulink/Math Operations/Gain', sprintf('%s/unit_sim_%s', mdl, label{m}), 'Gain', dgain{m}, ...
        'Position', [180 y 220 y+30]);
    add_block('simulink/Math Operations/Gain', sprintf('%s/unit_eq_%s', mdl, label{m}), 'Gain', dgain{m}, ...
        'Position', [180 y+60 220 y+90]);
    add_block('simulink/Math Operations/Sum', sprintf('%s/diff_%s', mdl, label{m}), 'Inputs', '+-', ...
        'Position', [240 y+120 270 y+150]);
    add_line(mdl, sim_out{m}, sprintf('unit_sim_%s/1', label{m}), 'autorouting', 'on');
    add_line(mdl, eq_out{m}, sprintf('unit_eq_%s/1', label{m}), 'autorouting', 'on');
    add_line(mdl, sprintf('unit_sim_%s/1', label{m}), sprintf('Simscape %s %s/1', dname{m}, dunit{m}), 'autorouting', 'on');
    add_line(mdl, sprintf('unit_eq_%s/1', label{m}), sprintf('Equations %s %s/1', dname{m}, dunit{m}), 'autorouting', 'on');
    add_line(mdl, sprintf('unit_sim_%s/1', label{m}), sprintf('diff_%s/1', label{m}), 'autorouting', 'on');
    add_line(mdl, sprintf('unit_eq_%s/1', label{m}), sprintf('diff_%s/2', label{m}), 'autorouting', 'on');
    add_line(mdl, sprintf('diff_%s/1', label{m}), sprintf('Simscape - equations %s %s/1', dname{m}, dunit{m}), 'autorouting', 'on');
    add_block('simulink/Sinks/To Workspace', sprintf('%s/eq_%s', mdl, label{m}), 'VariableName', ['eq_' label{m}], ...
        'SaveFormat', 'Structure With Time', 'Position', [300 y+175 370 y+195]);
    add_line(mdl, eq_out{m}, sprintf('eq_%s/1', label{m}), 'autorouting', 'on');
end
add_block('built-in/Note', [mdl '/case_note'], 'Position', [-960 -120], 'Text', 'Case: run set_m2_case(1), (2) or (3)');

%% model settings, flange offset sign, save
set_param(mdl, 'StopTime', num2str(M2.stop_time_s));
save_system(mdl, fullfile(cadDir, [mdl '.slx']));
set_m2_case(1);
fprintf('Saved %s.slx in %s. Run set_m2_case(1..3), then press Run.\n', mdl, cadDir);

%% ---------------------------------------------------------------- helpers
function name = angularVelocityParam(blk)
% name of the Transform Sensor checkbox for the angular velocity vector
dp = fieldnames(get_param(blk, 'DialogParameters'));
c = dp(~cellfun(@isempty, regexpi(dp, '^Sense.*(omega|angularvel)', 'once')));
v = c(cellfun(@isempty, regexp(c, '[XYZ]$', 'once')));      % the vector option, not one component
if isempty(v), error('Transform Sensor: no angular velocity option found (%s)', strjoin(dp, ', ')); end
name = v{1};
end

function nb = connectedNames(blk)
pc = get_param(blk, 'PortConnectivity'); nb = {};
for k = 1:numel(pc)
    h = [pc(k).SrcBlock(:); pc(k).DstBlock(:)]; h = h(h > 0);
    for j = 1:numel(h), nb{end+1} = get_param(h(j), 'Name'); end %#ok<AGROW>
end
end

function setEnum(blk, namePattern, valuePattern)
% choose the block setting whose name matches namePattern and the allowed value that
% matches valuePattern (works with the option names of R2024b and of newer releases)
dp = get_param(blk, 'DialogParameters');
f = fieldnames(dp);
names = f(~cellfun(@isempty, regexpi(f, namePattern)));
for n = 1:numel(names)
    if ~isfield(dp.(names{n}), 'Enum'), continue; end
    opts = dp.(names{n}).Enum;
    k = find(~cellfun(@isempty, regexpi(opts, valuePattern)), 1);
    if ~isempty(k)
        set_param(blk, names{n}, opts{k});
        return;
    end
end
txt = '';
for n = 1:numel(names)
    if isfield(dp.(names{n}), 'Enum'), txt = [txt sprintf('%s: %s; ', names{n}, strjoin(dp.(names{n}).Enum, ', '))]; end %#ok<AGROW>
end
error('setEnum: no value matching "%s" for "%s" in %s. Options: %s', valuePattern, namePattern, blk, txt);
end

function h = allPorts(blk)
ph = get_param(blk, 'PortHandles'); h = [ph.LConn(:); ph.RConn(:)];
end

function h = framePortTo(blk, partName)
pc = get_param(blk, 'PortConnectivity'); ph = get_param(blk, 'PortHandles');
for k = 1:numel(pc)
    hb = [pc(k).SrcBlock(:); pc(k).DstBlock(:)]; hb = hb(hb > 0);
    if any(contains(arrayfun(@(x) get_param(x, 'Name'), hb, 'UniformOutput', false), partName))
        idx = str2double(regexp(pc(k).Type, '\d+', 'match', 'once'));
        if startsWith(pc(k).Type, 'LConn'), h = ph.LConn(idx); else, h = ph.RConn(idx); end
        return;
    end
end
error('No port of %s is connected to %s.', blk, partName);
end
