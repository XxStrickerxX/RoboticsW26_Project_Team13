% Simscape(TM) Multibody(TM) version: 24.2

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(27).translation = [0.0 0.0 0.0];
smiData.RigidTransform(27).angle = 0.0;
smiData.RigidTransform(27).axis = [0.0 0.0 0.0];
smiData.RigidTransform(27).ID = "";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [2.2204460492503131e-13 0 31.000000000000014];  % mm
smiData.RigidTransform(1).angle = 0;  % rad
smiData.RigidTransform(1).axis = [0 0 0];
smiData.RigidTransform(1).ID = "B[IRB120_Wrist1-1:-:IRB120_Wrist2-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [302.00000000000568 630.00000000000205 31.000000000000071];  % mm
smiData.RigidTransform(2).angle = 9.402333513529274e-17;  % rad
smiData.RigidTransform(2).axis = [0.59593214260114891 0.80303479464765648 2.2497633114644459e-17];
smiData.RigidTransform(2).ID = "F[IRB120_Wrist1-1:-:IRB120_Wrist2-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [77.647155018306663 136.15390234143965 6.0992877415344537e-11];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(3).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(3).ID = "B[IRB120_Link3-1:-:IRB120_Wrist1-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-152.39999999999978 -4.2987835513486061e-13 -9.4342311740547302e-12];  % mm
smiData.RigidTransform(4).angle = 2.0943951023931975;  % rad
smiData.RigidTransform(4).axis = [-0.57735026918962662 -0.57735026918962651 0.57735026918962429];
smiData.RigidTransform(4).ID = "F[IRB120_Link3-1:-:IRB120_Wrist1-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [368.00000000000409 630.00000000000034 0];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = "B[IRB120_Wrist2-1:-:IRB120_Wrist3-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [-1.7848956588152027e-12 1.7736429516429311e-12 -1.0575321267178686e-13];  % mm
smiData.RigidTransform(6).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(6).axis = [-1 -1.1858416979961035e-32 1.1875677877653104e-16];
smiData.RigidTransform(6).ID = "F[IRB120_Wrist2-1:-:IRB120_Wrist3-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [1.1102230246251565e-13 0 13.000000000000345];  % mm
smiData.RigidTransform(7).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(7).axis = [1 0 0];
smiData.RigidTransform(7).ID = "B[IRB120_Wrist3-1:-:Gripper-8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [-4.8749448922080774e-11 6.2420000000028733 1.3100631690576847e-13];  % mm
smiData.RigidTransform(8).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(8).axis = [0.57735026918962562 -0.57735026918962562 0.57735026918962595];
smiData.RigidTransform(8).ID = "F[IRB120_Wrist3-1:-:Gripper-8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [-6.106226635438361e-11 289.99999999999994 56.999999999975046];  % mm
smiData.RigidTransform(9).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(9).axis = [1 0 1.6341095143701519e-15];
smiData.RigidTransform(9).ID = "B[IRB120_J1-3:-:IRB120_Link2-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [-6.3060667798708891e-13 -269.99999999999949 -0.99999999999553868];  % mm
smiData.RigidTransform(10).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(10).axis = [-1 3.3067648038387981e-31 -2.0303561927988943e-15];
smiData.RigidTransform(10).ID = "F[IRB120_J1-3:-:IRB120_Link2-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [-2.2204460492503131e-13 1.1102230246251565e-13 -8.0000000000000071];  % mm
smiData.RigidTransform(11).angle = 0;  % rad
smiData.RigidTransform(11).axis = [0 0 0];
smiData.RigidTransform(11).ID = "B[IRB120_Link2-2:-:IRB120_Link3-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-71.952844981693389 66.15390234143841 -59.499999999995467];  % mm
smiData.RigidTransform(12).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(12).axis = [-1 -2.021834465108947e-31 2.0210360906701442e-15];
smiData.RigidTransform(12).ID = "F[IRB120_Link2-2:-:IRB120_Link3-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [0 166.00000000000003 0];  % mm
smiData.RigidTransform(13).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(13).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(13).ID = "B[IRB120_BASE-2:-:IRB120_J1-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-6.1175626786805162e-11 166.00000000000006 -2.50407702391423e-11];  % mm
smiData.RigidTransform(14).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(14).axis = [0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(14).ID = "F[IRB120_BASE-2:-:IRB120_J1-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [-10.72093690748363 7.6054311736859503 -1.2181367026187218e-09];  % mm
smiData.RigidTransform(15).angle = 2.758229529036704e-06;  % rad
smiData.RigidTransform(15).axis = [-4.2955672322523794e-10 0 -1];
smiData.RigidTransform(15).ID = "AssemblyGround[Gripper-8:2F-85 pad^Gripper-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [10.720936905772055 7.6054311728248614 1.2179146580137967e-09];  % mm
smiData.RigidTransform(16).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(16).axis = [-1.379108568135966e-06 0.99999999999904898 3.9829251008465372e-15];
smiData.RigidTransform(16).ID = "AssemblyGround[Gripper-8:2F-85 pad^Gripper-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [0 0 0];  % mm
smiData.RigidTransform(17).angle = 0;  % rad
smiData.RigidTransform(17).axis = [0 0 0];
smiData.RigidTransform(17).ID = "AssemblyGround[Gripper-8:Assem1^Gripper-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [-39.362112435008243 -24.264371289937301 0];  % mm
smiData.RigidTransform(18).angle = 4.2005476523576879e-05;  % rad
smiData.RigidTransform(18).axis = [-2.9238668930785806e-11 -1.7708391578419425e-10 1];
smiData.RigidTransform(18).ID = "AssemblyGround[Gripper-8:2F distal^Gripper-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [-13.353243326924238 -5.5392249860175546 0];  % mm
smiData.RigidTransform(19).angle = 3.1415926535897918;  % rad
smiData.RigidTransform(19).axis = [0.11499659131463311 0.99336588626045297 -1.1471579289873064e-16];
smiData.RigidTransform(19).ID = "AssemblyGround[Gripper-8:2F-85 barre^Gripper-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [13.35324332643429 -5.5392249860175546 -8.8817841970012523e-13];  % mm
smiData.RigidTransform(20).angle = 0.23050313643379913;  % rad
smiData.RigidTransform(20).axis = [1.1323001954874397e-14 -8.3473299327289822e-15 1];
smiData.RigidTransform(20).ID = "AssemblyGround[Gripper-8:2F-85 barre^Gripper-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [39.362112432901704 -24.264371291152997 0];  % mm
smiData.RigidTransform(21).angle = 3.1415926535897789;  % rad
smiData.RigidTransform(21).axis = [2.10027444566367e-05 0.99999999977944232 3.9798893356375852e-15];
smiData.RigidTransform(21).ID = "AssemblyGround[Gripper-8:2F distal^Gripper-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [0 0 0];  % mm
smiData.RigidTransform(22).angle = 0;  % rad
smiData.RigidTransform(22).axis = [0 0 0];
smiData.RigidTransform(22).ID = "AssemblyGround[Gripper-8:2F casing^Gripper-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [-13.353243394288876 -5.5392249859698151 0];  % mm
smiData.RigidTransform(23).angle = 0.23050313693481717;  % rad
smiData.RigidTransform(23).axis = [4.6848017185008192e-15 7.0461847565133874e-15 -1];
smiData.RigidTransform(23).ID = "AssemblyGround[Gripper-8:2F membrure^Gripper-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [13.353243393798925 -5.5392249859698151 0];  % mm
smiData.RigidTransform(24).angle = 3.1415926535897922;  % rad
smiData.RigidTransform(24).axis = [0.11499659156348016 -0.99336588623164535 -4.1212378237121174e-16];
smiData.RigidTransform(24).ID = "AssemblyGround[Gripper-8:2F membrure^Gripper-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [-14.368577974559955 -1.2770672961848195 0];  % mm
smiData.RigidTransform(25).angle = 3.1415926535897847;  % rad
smiData.RigidTransform(25).axis = [0.11499830486378049 0.99336568789064639 3.1863150372060584e-15];
smiData.RigidTransform(25).ID = "AssemblyGround[Gripper-8:2F-85 proximal^Gripper-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [14.368577975070677 -1.2770672961732732 0];  % mm
smiData.RigidTransform(26).angle = 0.23050658642804031;  % rad
smiData.RigidTransform(26).axis = [-7.5453051489852184e-15 -3.1889591573069603e-14 1];
smiData.RigidTransform(26).ID = "AssemblyGround[Gripper-8:2F-85 proximal^Gripper-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [-1383.8281302628418 480.75702531752853 -22.675245377899561];  % mm
smiData.RigidTransform(27).angle = 0;  % rad
smiData.RigidTransform(27).axis = [0 0 0];
smiData.RigidTransform(27).ID = "RootGround[IRB120_BASE-2]";


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(13).mass = 0.0;
smiData.Solid(13).CoM = [0.0 0.0 0.0];
smiData.Solid(13).MoI = [0.0 0.0 0.0];
smiData.Solid(13).PoI = [0.0 0.0 0.0];
smiData.Solid(13).color = [0.0 0.0 0.0];
smiData.Solid(13).opacity = 0.0;
smiData.Solid(13).ID = "";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.0078658721318111084;  % kg
smiData.Solid(1).CoM = [49.073501468558099 126.78858636399923 -1.2213111829036824e-05];  % mm
smiData.Solid(1).MoI = [1.2841284481170667 0.43527300426669974 1.1375461010671588];  % kg*mm^2
smiData.Solid(1).PoI = [-3.1990913641279092e-07 -5.9547986334601301e-08 0.150123451385727];  % kg*mm^2
smiData.Solid(1).color = [0.89411764705882346 0.89411764705882346 0.89411764705882346];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = "2F-85 pad^Gripper*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.0072195898667769542;  % kg
smiData.Solid(2).CoM = [88.022828700553703 133.97187619577343 1.5472643007244757e-08];  % mm
smiData.Solid(2).MoI = [0.42142032120172962 0.64782569153828906 0.65440489864519658];  % kg*mm^2
smiData.Solid(2).PoI = [-9.6625623367641508e-10 -6.6222194943654266e-07 0.15404075983466209];  % kg*mm^2
smiData.Solid(2).color = [0.89411764705882346 0.89411764705882346 0.89411764705882346];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = "2F distal^Gripper*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.014510676943773055;  % kg
smiData.Solid(3).CoM = [65.95051488657009 68.95311135342105 0.0055274050430382101];  % mm
smiData.Solid(3).MoI = [4.6808105220418579 1.8055107271470487 4.0299167599562251];  % kg*mm^2
smiData.Solid(3).PoI = [0.0014918655922202212 0.00031601676678107745 -0.81613198462736081];  % kg*mm^2
smiData.Solid(3).color = [0.89411764705882346 0.89411764705882346 0.89411764705882346];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = "2F-85 barre^Gripper*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.22588388010717134;  % kg
smiData.Solid(4).CoM = [-0.00053759410160018721 32.322741971176114 0.022804020963641342];  % mm
smiData.Solid(4).MoI = [175.80801889477453 134.40954913309662 200.2762874293571];  % kg*mm^2
smiData.Solid(4).PoI = [-0.11250180827128521 -0.0089099035169851754 0.0004636692747271869];  % kg*mm^2
smiData.Solid(4).color = [0.89411764705882346 0.89411764705882346 0.89411764705882346];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = "2F casing^Gripper*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.0034698386140619066;  % kg
smiData.Solid(5).CoM = [-53.093864191237785 53.121782202796872 0.11174449547314538];  % mm
smiData.Solid(5).MoI = [0.086402301351980904 0.25376327297057288 0.28630967957280562];  % kg*mm^2
smiData.Solid(5).PoI = [0.0010660766037614651 0.0034633040042317729 -0.028862044424951855];  % kg*mm^2
smiData.Solid(5).color = [0.89411764705882346 0.89411764705882346 0.89411764705882346];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = "2F membrure^Gripper*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.010113467487741451;  % kg
smiData.Solid(6).CoM = [32.220785082217745 83.420484826157264 -3.0513689389489716e-06];  % mm
smiData.Solid(6).MoI = [3.1932277662011104 2.8534516002196826 2.9646521859910511];  % kg*mm^2
smiData.Solid(6).PoI = [-1.147335621138986e-06 1.3527583154077541e-06 -1.3505796118956739];  % kg*mm^2
smiData.Solid(6).color = [0.89411764705882346 0.89411764705882346 0.89411764705882346];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = "2F-85 proximal^Gripper*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 2.9437181131947705;  % kg
smiData.Solid(7).CoM = [-49.145012633028372 124.06469267048946 -1.0644291639968109];  % mm
smiData.Solid(7).MoI = [8356.021016420631 12698.362055196571 16712.854113261441];  % kg*mm^2
smiData.Solid(7).PoI = [-182.19807553320908 -80.147996986202017 -1428.8277113432835];  % kg*mm^2
smiData.Solid(7).color = [0.89411764705882346 0.89411764705882346 0.89411764705882346];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = "IRB120_Link3*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 0.54662589247699822;  % kg
smiData.Solid(8).CoM = [300.90514863239207 630.06221822722318 -0.036865073635537433];  % mm
smiData.Solid(8).MoI = [404.88982567946766 815.46703861964636 892.82305193743571];  % kg*mm^2
smiData.Solid(8).PoI = [-0.015334821438079694 1.6189382071685281 -0.84660223704902882];  % kg*mm^2
smiData.Solid(8).color = [0.89411764705882346 0.89411764705882346 0.89411764705882346];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = "IRB120_Wrist2*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 3.9086416694674746;  % kg
smiData.Solid(9).CoM = [0.77829844654042424 -168.75744364703661 -55.882956125443236];  % mm
smiData.Solid(9).MoI = [60310.885094207901 25954.617803753168 41568.913343999564];  % kg*mm^2
smiData.Solid(9).PoI = [-504.97569874513289 9.8580508926646253 -57.243684392844678];  % kg*mm^2
smiData.Solid(9).color = [0.89411764705882346 0.89411764705882346 0.89411764705882346];
smiData.Solid(9).opacity = 1;
smiData.Solid(9).ID = "IRB120_Link2*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(10).mass = 1.4475646646909786;  % kg
smiData.Solid(10).CoM = [-75.824427180655775 0.37203226887402985 4.5682548012091688];  % mm
smiData.Solid(10).MoI = [3257.7056469304866 5934.8810927159229 4390.914419152451];  % kg*mm^2
smiData.Solid(10).PoI = [15.67777671297581 -134.66846727401781 17.231500279078965];  % kg*mm^2
smiData.Solid(10).color = [0.89411764705882346 0.89411764705882346 0.89411764705882346];
smiData.Solid(10).opacity = 1;
smiData.Solid(10).ID = "IRB120_Wrist1*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(11).mass = 3.0670062439344417;  % kg
smiData.Solid(11).CoM = [0.097653079622014513 238.41162530358247 0.11924489213583007];  % mm
smiData.Solid(11).MoI = [14217.430275997691 10453.385101375721 14404.126687881906];  % kg*mm^2
smiData.Solid(11).PoI = [19.339889153317117 -12.863073555307951 23.120532132089615];  % kg*mm^2
smiData.Solid(11).color = [0.89411764705882346 0.89411764705882346 0.89411764705882346];
smiData.Solid(11).opacity = 1;
smiData.Solid(11).ID = "IRB120_J1*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(12).mass = 0.013678420390692446;  % kg
smiData.Solid(12).CoM = [-0.0013236691246472224 0.1695810144052135 5.9379127428619141];  % mm
smiData.Solid(12).MoI = [1.6576999795087597 1.694267263097903 2.9768141661034013];  % kg*mm^2
smiData.Solid(12).PoI = [-0.0076625029709117727 8.9149943533104779e-05 -3.0637252189814869e-06];  % kg*mm^2
smiData.Solid(12).color = [0.89411764705882346 0.89411764705882346 0.89411764705882346];
smiData.Solid(12).opacity = 1;
smiData.Solid(12).ID = "IRB120_Wrist3*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(13).mass = 6.2150564828973867;  % kg
smiData.Solid(13).CoM = [-42.039757292550789 79.637672219753057 -0.080258880234750238];  % mm
smiData.Solid(13).MoI = [24727.299656803862 47238.081421559604 49128.949757563874];  % kg*mm^2
smiData.Solid(13).PoI = [-8.0049990583592887 -80.880143462831072 -1308.8790801487833];  % kg*mm^2
smiData.Solid(13).color = [0.89411764705882346 0.89411764705882346 0.89411764705882346];
smiData.Solid(13).opacity = 1;
smiData.Solid(13).ID = "IRB120_BASE*:*Default";


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(7).Rz.Pos = 0.0;
smiData.RevoluteJoint(7).ID = "";

smiData.RevoluteJoint(1).Rz.Pos = -1.1894102821108761;  % deg
smiData.RevoluteJoint(1).ID = "[IRB120_Wrist1-1:-:IRB120_Wrist2-1]";

smiData.RevoluteJoint(2).Rz.Pos = -1.3347057752895015;  % deg
smiData.RevoluteJoint(2).ID = "[IRB120_Link3-1:-:IRB120_Wrist1-1]";

smiData.RevoluteJoint(3).Rz.Pos = -133.24658312175282;  % deg
smiData.RevoluteJoint(3).ID = "[IRB120_Wrist2-1:-:IRB120_Wrist3-1]";

smiData.RevoluteJoint(4).Rz.Pos = -40.925789034501079;  % deg
smiData.RevoluteJoint(4).ID = "[IRB120_Wrist3-1:-:Gripper-8]";

smiData.RevoluteJoint(5).Rz.Pos = -2.5898893926805675;  % deg
smiData.RevoluteJoint(5).ID = "[IRB120_J1-3:-:IRB120_Link2-2]";

smiData.RevoluteJoint(6).Rz.Pos = -178.202363818192;  % deg
smiData.RevoluteJoint(6).ID = "[IRB120_Link2-2:-:IRB120_Link3-1]";

smiData.RevoluteJoint(7).Rz.Pos = 177.26608008771987;  % deg
smiData.RevoluteJoint(7).ID = "[IRB120_BASE-2:-:IRB120_J1-3]";

