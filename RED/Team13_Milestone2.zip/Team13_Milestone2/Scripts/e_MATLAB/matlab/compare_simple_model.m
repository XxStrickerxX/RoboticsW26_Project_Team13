%% compare_simple_model.m - Simscape model vs the DH equations (R3, R5)
% Runs IRB120_Simple (made by build_simple_model.m) and compares what the
% Transform Sensor measures with what the DH equations give for the SAME
% motion:
%   angles      : step_motion.m (same formula as the Transfer Fcn blocks)
%   position    : p = FK(q)
%   velocity    : v = Jv * qd
%   acceleration: a = Jv * qdd + Jv_dot * qd
% The target angles and step time are read from the Step blocks of the
% model, so if you type other angles there, this script follows them.
%
% Expected result: a difference of a few mm (about 3-13 mm). This is NOT a
% kinematics error: the SolidWorks CAD is a little different from the DH
% table (measured in simscape_cad_offsets.m). The kinematics itself is
% tested exactly (1e-6) in test_kinematics.m.
clear; close all;
here   = fileparts(mfilename('fullpath'));
cadDir = fullfile(getenv('HOME'), 'CAD_Model', 'CAD_Model');
addpath(here); addpath(cadDir);
mdl = 'IRB120_Simple';
P = irb120_params();
C = simscape_cad_offsets();
P66 = P; P66.d(6) = C.sensor_d6;     % the sensor point is 0.066 m after the wrist centre

%% run the Simscape model
old = pwd; cd(cadDir);
load_system(mdl);
q1 = zeros(6,1);
for i = 1:6                                             % angles typed in the model
    q1(i) = deg2rad(str2double(get_param(sprintf('%s/q%d_target_deg', mdl, i), 'After')));
end
ts  = str2double(get_param([mdl '/q1_target_deg'], 'Time'));
den = str2num(get_param([mdl '/q1_smooth'], 'Denominator')); %#ok<ST2NM>
tau = den(2)/2;                                          % denominator = [tau^2 2*tau 1]
out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');
cd(old);
t  = out.sim_p.time;                                    % logged by the To Workspace blocks
ps = rows3(out.sim_p.signals.values);
vs = rows3(out.sim_v.signals.values);
as = rows3(out.sim_a.signals.values);

%% the same move from the equations
N = numel(t); pe = zeros(N,3); ve = pe; ae = pe;
for k = 1:N
    [q, qd, qdd] = step_motion(zeros(6,1), q1, t(k), ts, tau);
    [p, v, a] = ee_motion(q, qd, qdd, P66);
    pe(k,:) = p.'; ve(k,:) = v.'; ae(k,:) = a.';
end

%% print the comparison
dp = vecnorm(ps - pe, 2, 2);
fprintf('\nTarget angles %s deg, step at t = %g s, tau = %g s\n', mat2str(round(rad2deg(q1.'), 2)), ts, tau);
fprintf('                         Simscape            DH equations\n');
fprintf('position at the end [m]  [%.4f %.4f %.4f]  [%.4f %.4f %.4f]\n', ps(end,:), pe(end,:));
fprintf('peak speed [m/s]         %8.4f            %8.4f\n', max(vecnorm(vs,2,2)), max(vecnorm(ve,2,2)));
fprintf('peak acceleration [m/s^2]%8.4f            %8.4f\n', max(vecnorm(as,2,2)), max(vecnorm(ae,2,2)));
fprintf('largest position difference during the move: %.2f mm (CAD vs DH, expected 3-13 mm)\n', 1000*max(dp));
Tf = fk_irb120(q1, P);
fprintf('Flange (d6 = 0.072, same as MATLAB and Gazebo) from FK: [%.4f %.4f %.4f] m\n', Tf(1:3,4));
if max(dp) < 0.015
    disp('SIMSCAPE CHECK: PASS (Simscape follows the DH equations; difference = CAD geometry)');
else
    disp('SIMSCAPE CHECK: FAIL (difference larger than the CAD geometry explains)');
end
outdir = fullfile(here, '..', 'results'); if ~isfolder(outdir), mkdir(outdir); end
names = {'t','x','y','z','vx','vy','vz','ax','ay','az', ...
         'x_eq','y_eq','z_eq','vx_eq','vy_eq','vz_eq','ax_eq','ay_eq','az_eq'};
writetable(array2table([t ps vs as pe ve ae], 'VariableNames', names), fullfile(outdir, 'simscape_move.csv'));

%% plots: Simscape (solid) and equations (dashed)
figure('Name', 'Simscape (solid) vs DH equations (dashed)');
lab = {'p [m]', 'v [m/s]', 'a [m/s^2]'}; S = {ps, vs, as}; E = {pe, ve, ae};
for m = 1:3
    subplot(3,1,m); plot(t, S{m}, '-', 'LineWidth', 1.2); hold on;
    set(gca, 'ColorOrderIndex', 1); plot(t, E{m}, '--'); grid on; ylabel(lab{m});
end
xlabel('t [s]'); subplot(3,1,1); legend('x','y','z','x eq','y eq','z eq');

function X = rows3(x)
% logged signal -> N x 3 (the logger may save it as N x 3 or 3 x 1 x N)
x = squeeze(x);
if size(x,2) ~= 3, x = x.'; end
X = x;
end
