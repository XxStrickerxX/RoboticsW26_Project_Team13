function e = rot_error(Re)
%ROT_ERROR Angle * axis of a rotation matrix (zero vector when Re = I).
%   Used as the orientation part of F(q) in the Newton-Raphson IK.
c  = max(-1, min(1, (trace(Re) - 1)/2));
th = acos(c);
v  = [Re(3,2) - Re(2,3); Re(1,3) - Re(3,1); Re(2,1) - Re(1,2)];
if th < 1e-6
    e = 0.5 * v;
elseif th > pi - 1e-4                 % about 180 deg: axis from the diagonal
    [~, k] = max(diag(Re));
    ax = Re(:,k) + double((1:3).' == k);
    e  = th * ax / norm(ax);
else
    e = th / (2*sin(th)) * v;
end
end
