function q = wrap_angle(q)
%WRAP_ANGLE Wrap angles to the interval (-pi, pi].
q = -mod(-q + pi, 2*pi) + pi;
end
