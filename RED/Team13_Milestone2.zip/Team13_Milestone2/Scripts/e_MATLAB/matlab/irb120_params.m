function P = irb120_params()
%IRB120_PARAMS Load the shared IRB 120 parameters (DH table, limits, tests).
%   P = irb120_params() reads ../params/irb120_params.json, the same file
%   the ROS 2 nodes use, and returns everything in SI units (m, rad).
%
%   Fields: offset, d, a, alpha (6x1 DH columns), qmin, qmax (6x1 rad),
%           vmax (6x1 rad/s), test_poses (n x 6 rad), move (struct), tol.
%   P.move: q0, q1 (6x1 rad: start and target angles), ts (step time [s]),
%           tau (filter time constant [s]), T (stop time [s]), dt (sample [s])

here = fileparts(mfilename('fullpath'));
file = fullfile(here, '..', 'params', 'irb120_params.json');
if ~isfile(file)
    error('Parameter file not found: %s', file);
end
S = jsondecode(fileread(file));

dh = S.dh.rows;                       % 6x4: offset[deg] d[m] a[m] alpha[deg]
P.offset = deg2rad(dh(:,1));
P.d      = dh(:,2);
P.a      = dh(:,3);
P.alpha  = deg2rad(dh(:,4));

P.qmin = deg2rad(S.joint_limits_deg.lower(:));
P.qmax = deg2rad(S.joint_limits_deg.upper(:));
P.vmax = deg2rad(S.max_speed_deg_s(:));

P.test_poses = deg2rad(S.test_poses_deg);          % one pose per row
P.move.q0  = deg2rad(S.move.start_deg(:));
P.move.q1  = deg2rad(S.move.target_deg(:));
P.move.ts  = S.move.step_time_s;
P.move.tau = S.move.filter_tau_s;
P.move.T   = S.move.stop_time_s;
P.move.dt  = S.move.sample_time_s;
P.tol = S.tolerance;
end
