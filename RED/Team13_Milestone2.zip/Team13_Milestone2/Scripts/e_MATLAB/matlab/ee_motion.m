function [p, v, a] = ee_motion(q, qd, qdd, P)
%EE_MOTION Flange position, linear velocity and linear acceleration.
%   [p, v, a] = ee_motion(q, qd, qdd, P)
%   q, qd, qdd : joint angles [rad], velocities [rad/s], accelerations [rad/s^2]
%   p = FK position,   v = Jv*qd,   a = Jv*qdd + Jv_dot*qd
J  = jacobian_irb120(q, P);
Jd = jacobian_dot_irb120(q, qd, P);
T  = fk_irb120(q, P);
p  = T(1:3,4);
v  = J(1:3,:) * qd(:);
a  = J(1:3,:) * qdd(:) + Jd(1:3,:) * qd(:);
end
