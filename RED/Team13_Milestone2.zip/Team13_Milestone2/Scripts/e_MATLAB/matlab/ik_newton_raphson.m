function [q, iter, resid] = ik_newton_raphson(target, q0, P)
%IK_NEWTON_RAPHSON Numerical IK, Newton-Raphson method (Tutorial 04).
%   q_{n+1} = q_n - [dF/dq]^-1 * F(q_n)     repeated until |F| < 1e-10
%
%   target = [x; y; z]  -> inverse POSITION kinematics: 3 equations,
%                          solves q1, q2, q3 (q4..q6 stay at their q0 values)
%   target = 4x4 pose   -> position + orientation: 6 equations, all 6 joints
%   q0     = initial guess (6 angles, rad), e.g. the current robot pose
%
%   F(q) = p(q) - p_desired                                (position mode)
%   F(q) = [p(q) - p_desired ; rotation error angle*axis]   (pose mode)
%   dF/dq is evaluated numerically (central differences), as a 3x3 or 6x6
%   square matrix, exactly like the 2-link example in the tutorial.
tol = 1e-10; maxIter = 100; h = 1e-7;
q = q0(:);
if isequal(size(target), [4 4])
    active = 1:6;
else
    active = 1:3;
    target = target(:);
end
F = nrFunction(q, target, P);
for iter = 1:maxIter
    J = zeros(numel(F), numel(active));
    for c = 1:numel(active)
        e = zeros(6,1); e(active(c)) = h;
        J(:,c) = (nrFunction(q + e, target, P) - nrFunction(q - e, target, P)) / (2*h);
    end
    if abs(det(J)) > 1e-12
        dq = J \ F;                    % same as inv(J)*F
    else
        dq = pinv(J) * F;              % near a singular pose
    end
    if max(abs(dq)) > 0.5              % limit the step to 0.5 rad
        dq = dq * 0.5 / max(abs(dq));
    end
    q(active) = q(active) - dq;
    q = wrap_angle(q);
    F = nrFunction(q, target, P);
    if norm(F) < tol
        break;
    end
end
resid = norm(F);
end

function F = nrFunction(q, target, P)
T = fk_irb120(q, P);
if isequal(size(target), [4 4])
    F = [T(1:3,4) - target(1:3,4); rot_error(T(1:3,1:3) * target(1:3,1:3).')];
else
    F = T(1:3,4) - target;
end
end
