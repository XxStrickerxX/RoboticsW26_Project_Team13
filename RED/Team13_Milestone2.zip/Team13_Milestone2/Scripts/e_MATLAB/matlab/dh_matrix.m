function A = dh_matrix(theta, d, a, alpha)
%DH_MATRIX Standard DH transform from frame i-1 to frame i.
%   A = Rz(theta) * Tz(d) * Tx(a) * Rx(alpha)
%   Works with numbers and with symbolic variables.
A = [cos(theta) -sin(theta)*cos(alpha)  sin(theta)*sin(alpha) a*cos(theta);
     sin(theta)  cos(theta)*cos(alpha) -cos(theta)*sin(alpha) a*sin(theta);
     0           sin(alpha)             cos(alpha)            d;
     0           0                      0                     1];
end
