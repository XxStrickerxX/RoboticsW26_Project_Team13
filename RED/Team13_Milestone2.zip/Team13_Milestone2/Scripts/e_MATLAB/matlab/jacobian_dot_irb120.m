function Jd = jacobian_dot_irb120(q, qd, P)
%JACOBIAN_DOT_IRB120 Time derivative of the geometric Jacobian (6x6).
%   Needed for the acceleration:  a = Jv*qdd + Jv_dot*qd.
%   Exact formula (no numerical differentiation):
%     z_dot_i  = w_i x z_i
%     Jv_dot_i = z_dot_i x (p_6 - o_i) + z_i x (v_6 - v_i)
%     Jw_dot_i = z_dot_i
%   where w_i, v_i are the angular velocity and the origin velocity of
%   frame i (frame index 0..6 is stored at 1..7).
qd = qd(:);
[~, F] = fk_irb120(q, P);
z = squeeze(F(1:3,3,:));     % 3x7
o = squeeze(F(1:3,4,:));     % 3x7
w = zeros(3,7);
v = zeros(3,7);
for i = 1:6
    w(:,i+1) = w(:,i) + z(:,i)*qd(i);
end
for k = 2:7
    for j = 1:k-1
        v(:,k) = v(:,k) + cross(z(:,j), o(:,k) - o(:,j)) * qd(j);
    end
end
Jd = zeros(6,6);
for i = 1:6
    zd = cross(w(:,i), z(:,i));
    Jd(1:3,i) = cross(zd, o(:,7) - o(:,i)) + cross(z(:,i), v(:,7) - v(:,i));
    Jd(4:6,i) = zd;
end
end
