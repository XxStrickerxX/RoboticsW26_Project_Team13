%% build_simple_model.m - SIMPLE Simscape model of the IRB 120 + gripper
% Builds IRB120_Simple.slx from the SolidWorks XML (smimport) and adds,
% for every joint, one short chain of standard blocks:
%
%   [Step: target angle, deg] -> [Transfer Fcn: smooth 1/(0.2s+1)^2]
%        -> [Gain: deg->rad and direction] -> [Bias: CAD zero offset]
%        -> [Simulink-PS Converter] -> joint
%
%   * Step block: the joint starts at 0 deg (home) and at t = 1 s gets the
%     angle you type in "Final value" -> the robot moves to that pose.
%   * Transfer Fcn: makes the move smooth. MATLAB (step_motion.m) and the
%     Gazebo node use exactly the same formula, so all three move the same.
%   * Gain / Bias: the CAD joints are measured from another zero and some
%     turn the other way; these two numbers turn your DH angle into the
%     CAD joint angle (values from simscape_cad_offsets.m).
%   * Simulink-PS Converter: passes the angle (and its derivatives) to the
%     joint (its own filter is only 1 ms).
%
% One Transform Sensor measures the flange (joint-6 frame):
%   position, velocity, acceleration -> converted to the robot base frame
%   (Gain = rotation, Bias = offset) -> Display + Scope + To Workspace
%   (sim_p, sim_v, sim_a, used by compare_simple_model.m).
%
% Use: run this script once, then open IRB120_Simple, double-click a
% "qN_target_deg" block, type the angle in "Final value", press Run.
clear;
here   = fileparts(mfilename('fullpath'));
cadDir = fullfile(getenv('HOME'), 'CAD_Model', 'CAD_Model');
mdl    = 'IRB120_Simple';
addpath(here); addpath(cadDir);
C = simscape_cad_offsets();
f = fullfile(here, 'simscape_joint_signs.mat');
if isfile(f), S = load(f); s = S.jsign(:); else, s = [-1 -1 1 -1 -1 1].'; end
P = irb120_params();
target = rad2deg(P.move.q1).';             % target angles [deg] from irb120_params.json
tau = P.move.tau; ts = P.move.ts;          % smoothing time constant, step time [s]
if any(P.move.q0), error('build_simple_model: start_deg must be all zeros (home).'); end

%% import the CAD model (same XML as the handout)
if bdIsLoaded(mdl), close_system(mdl, 0); end
old = pwd; cd(cadDir);
smimport('IRB120_Assembly.xml', 'ModelName', mdl);
cd(old);

%% find the joints (q1..q6 and gripper) by the parts they connect
J = find_system(mdl, 'SearchDepth', 1, 'LookUnderMasks', 'all', 'FollowLinks', 'on', ...
                'RegExp', 'on', 'ReferenceBlock', 'Revolute Joint');
pairs = {'BASE','J1'; 'J1','Link2'; 'Link2','Link3'; 'Link3','Wrist1'; ...
         'Wrist1','Wrist2'; 'Wrist2','Wrist3'; 'Wrist3','Gripper'};
names = {'q1','q2','q3','q4','q5','q6','gripper'};
jb = cell(7,1);
for k = 1:numel(J)
    nb = connectedNames(J{k});
    for i = 1:7
        hit = any(contains(nb, pairs{i,1})) && any(contains(nb, pairs{i,2}));
        if i < 7, hit = hit && ~any(contains(nb, 'Gripper')); end
        if hit, jb{i} = J{k}; end
    end
end

%% one input chain per joint
for i = 1:7
    b = jb{i};
    setEnum(b, 'Torque.*Actuat', 'Comput|Automatic');   % torque computed by Simscape
    h0 = allPorts(b);
    setEnum(b, 'Motion.*Actuat', 'Input');              % motion provided by input
    qin = setdiff(allPorts(b), h0);                          % the new input port "q"
    if i <= 6
        gain = s(i)*pi/180;
        bias = C.thcad(i) - s(i)*C.qcad(i);   % q_cad = s*q_dh + (thcad - s*qcad)
        fin  = target(i);
    else                                       % gripper: held at its CAD angle
        gain = pi/180;
        bias = C.thcad_gripper;
        fin  = 0;
    end
    y = 80 + (i-1)*90; n = names{i};
    add_block('simulink/Sources/Step', [mdl '/' n '_target_deg'], 'Time', num2str(ts), ...
        'Before', '0', 'After', num2str(fin), 'Position', [-840 y -800 y+30]);
    add_block('simulink/Continuous/Transfer Fcn', [mdl '/' n '_smooth'], ...
        'Numerator', '1', 'Denominator', sprintf('[%g %g 1]', tau^2, 2*tau), ...
        'Position', [-770 y -710 y+30]);
    add_block('simulink/Math Operations/Gain', [mdl '/' n '_deg2rad_dir'], ...
        'Gain', sprintf('%.15g', gain), 'Position', [-680 y -630 y+30]);
    add_block('simulink/Math Operations/Bias', [mdl '/' n '_cad_zero'], ...
        'Bias', sprintf('%.15g', bias), 'Position', [-590 y -540 y+30]);
    add_block('nesl_utility/Simulink-PS Converter', [mdl '/' n '_to_joint'], 'Unit', 'rad', ...
        'FilteringAndDerivatives', 'filter', 'SimscapeFilterOrder', '2', ...
        'InputFilterTimeConstant', '0.001', 'Position', [-500 y -460 y+30]);
    add_line(mdl, [n '_target_deg/1'], [n '_smooth/1']);
    add_line(mdl, [n '_smooth/1'], [n '_deg2rad_dir/1']);
    add_line(mdl, [n '_deg2rad_dir/1'], [n '_cad_zero/1']);
    add_line(mdl, [n '_cad_zero/1'], [n '_to_joint/1']);
    pc = get_param([mdl '/' n '_to_joint'], 'PortHandles');
    add_line(mdl, pc.RConn(1), qin);
end

%% flange sensor: World -> joint-6 frame, shown in the robot base frame
W  = find_system(mdl, 'SearchDepth', 1, 'LookUnderMasks', 'all', 'FollowLinks', 'on', ...
                 'RegExp', 'on', 'ReferenceBlock', 'World Frame$');
sb = [mdl '/flange_sensor'];
add_block('sm_lib/Frames and Transforms/Transform Sensor', sb, 'Position', [-760 800 -680 900]);
pT = get_param(sb, 'PortHandles'); pW = get_param(W{1}, 'PortHandles');
add_line(mdl, pW.RConn(1), pT.LConn(1));
add_line(mdl, framePortTo(jb{6}, 'Wrist3'), pT.RConn(1));
Rt = C.W(1:3,1:3).';  t0 = C.W(1:3,4);
outs  = {'SenseXYZ','SenseXYZDot','SenseXYZDDot'};
label = {'p','v','a'}; units = {'m','m/s','m/s^2'};
add_block('simulink/Sinks/Scope', [mdl '/flange_p_v_a'], 'NumInputPorts', '3', ...
    'Position', [-300 800 -260 900]);
for m = 1:3
    h0 = allPorts(sb);
    set_param(sb, outs{m}, 'on');
    hp = setdiff(allPorts(sb), h0);
    y = 780 + m*45;
    add_block('nesl_utility/PS-Simulink Converter', [mdl '/flange_' label{m}], 'Unit', units{m}, ...
        'Position', [-640 y -600 y+25]);
    add_block('simulink/Math Operations/Gain', [mdl '/to_base_' label{m}], 'Gain', mat2str(Rt, 15), ...
        'Multiplication', 'Matrix(K*u)', 'Position', [-560 y -510 y+25]);
    pc = get_param([mdl '/flange_' label{m}], 'PortHandles');
    add_line(mdl, hp, pc.LConn(1));
    add_line(mdl, ['flange_' label{m} '/1'], ['to_base_' label{m} '/1']);
    add_block('simulink/Sinks/To Workspace', [mdl '/sim_' label{m}], 'VariableName', ['sim_' label{m}], ...
        'SaveFormat', 'Structure With Time', 'Position', [-300 900+m*40 -230 920+m*40]);
    if m == 1                                       % position also needs the offset
        add_block('simulink/Math Operations/Bias', [mdl '/base_offset_p'], ...
            'Bias', mat2str(-Rt*t0, 15), 'Position', [-470 y -420 y+25]);
        add_block('simulink/Sinks/Display', [mdl '/flange_xyz_m'], 'Position', [-300 720 -200 780]);
        add_line(mdl, 'to_base_p/1', 'base_offset_p/1');
        add_line(mdl, 'base_offset_p/1', 'flange_xyz_m/1', 'autorouting', 'on');
        add_line(mdl, 'base_offset_p/1', 'flange_p_v_a/1', 'autorouting', 'on');
        add_line(mdl, 'base_offset_p/1', 'sim_p/1', 'autorouting', 'on');
    else
        add_line(mdl, ['to_base_' label{m} '/1'], sprintf('flange_p_v_a/%d', m), 'autorouting', 'on');
        add_line(mdl, ['to_base_' label{m} '/1'], ['sim_' label{m} '/1'], 'autorouting', 'on');
    end
end

set_param(mdl, 'StopTime', num2str(P.move.T));
save_system(mdl, fullfile(cadDir, [mdl '.slx']));
open_system(mdl);
fprintf('Saved %s.slx. Press Run: the robot moves from home to [%s] deg.\n', mdl, num2str(target));
P66 = P; P66.d(6) = C.sensor_d6;                   % point measured by the sensor
T = fk_irb120(deg2rad(target), P66);
fprintf('DH equations give [%.4f %.4f %.4f] m for that point (Simscape differs a few mm: CAD).\n', T(1:3,4));

%% ---------------------------------------------------------------- helpers
function nb = connectedNames(blk)
pc = get_param(blk, 'PortConnectivity'); nb = {};
for k = 1:numel(pc)
    h = [pc(k).SrcBlock(:); pc(k).DstBlock(:)]; h = h(h > 0);
    for j = 1:numel(h), nb{end+1} = get_param(h(j), 'Name'); end %#ok<AGROW>
end
end

function setEnum(blk, namePattern, valuePattern)
% find the block setting whose name matches namePattern and choose the
% allowed value that matches valuePattern
dp = get_param(blk, 'DialogParameters');
f = fieldnames(dp);
name = f{find(~cellfun(@isempty, regexpi(f, namePattern)), 1)};
opts = dp.(name).Enum;
k = find(~cellfun(@isempty, regexpi(opts, valuePattern)), 1);
set_param(blk, name, opts{k});
end

function h = allPorts(blk)
ph = get_param(blk, 'PortHandles'); h = [ph.LConn(:); ph.RConn(:)];
end

function h = framePortTo(blk, partName)
pc = get_param(blk, 'PortConnectivity'); ph = get_param(blk, 'PortHandles');
for k = 1:numel(pc)
    hb = [pc(k).SrcBlock(:); pc(k).DstBlock(:)]; hb = hb(hb > 0);
    if any(contains(arrayfun(@(x) get_param(x, 'Name'), hb, 'UniformOutput', false), partName))
        idx = str2double(regexp(pc(k).Type, '\d+', 'match', 'once'));
        if startsWith(pc(k).Type, 'LConn'), h = ph.LConn(idx); else, h = ph.RConn(idx); end
        return;
    end
end
error('No port of %s is connected to %s.', blk, partName);
end
