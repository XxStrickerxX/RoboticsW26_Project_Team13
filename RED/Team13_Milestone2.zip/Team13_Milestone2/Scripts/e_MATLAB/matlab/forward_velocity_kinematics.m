function V_F = forward_velocity_kinematics(q, q_dot)
% FORWARD_VELOCITY_KINEMATICS  Flange velocity from joint velocities (RED Milestone 2).
%   q     : 6x1 joint angles (symbolic or numeric, rad)
%   q_dot : 6x1 joint velocities (symbolic or numeric, rad/s)
%   V_F   : 6x1 [vx; vy; vz; wx; wy; wz]  (m/s and rad/s, frame 0 axes)
% Forward velocity kinematics:  V_F = J(q) * q_dot   (Tutorial 05)

    J = jacobian_matrix(q);
    V_F = J * q_dot(:);
end
