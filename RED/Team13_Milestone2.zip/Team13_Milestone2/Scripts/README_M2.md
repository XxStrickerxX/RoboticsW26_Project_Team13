# Team 13 – ABB IRB 120 – RED Milestone 02

Inverse position kinematics (Newton–Raphson with the pseudo-inverse) and forward/inverse velocity kinematics of the ABB IRB 120 (6 joints), in **MATLAB / Simulink / Simscape** and **Python / ROS 2 Jazzy / Gazebo**. Same robot, same numbers and same tests on all four platforms.
This builds on our Milestone 01 files (see `README.md`), which are kept in the same folders.

## Functions asked for in the brief (MATLAB and Python, same names)
| Brief | MATLAB (`e_MATLAB/matlab/`) | Python (`f_Python/my_irb120_robot/my_irb120_robot/m2_kinematics.py`) |
|---|---|---|
| FK of the previous milestone | `forward_kinematics_func.m` (symbolic, from the M1 DH table) | `forward_kinematics_func()` |
| 1a `J_inv = inverse_jacobian_matrix(q)` | `inverse_jacobian_matrix.m`: pinv of the 3×6 dF/dq | `inverse_jacobian_matrix(q)` |
| 1a `q = inverse_kinematics_func(q0, X)` | `inverse_kinematics_func.m`: Newton–Raphson | `inverse_kinematics_func(q0, X)` |
| 2a `J = jacobian_matrix(q)` | `jacobian_matrix.m`: symbolic 6×6 | `jacobian_matrix(q)` |
| 2a `V_F = forward_velocity_kinematics(q, q_dot)` | `forward_velocity_kinematics.m` | `forward_velocity_kinematics(q, q_dot)` |
| 3a `q_dot = inverse_velocity_kinematics(q, V_F)` | `inverse_velocity_kinematics.m`: pinv of the 6×6 J | `inverse_velocity_kinematics(q, V_F)` |

Notes:
- Joint 6 turns the flange about its own axis, so it does not change the flange position. The position IK keeps q6 at its initial value.
- V_F = [vx vy vz wx wy wz], so the IVK moves all 6 joints.

## Test cases
All platforms read the test cases from one file: `e_MATLAB/params/irb120_params.json`, section `m2` (the ROS package has a copy in `config/`).

| Case | X (mm) | v (mm/s) | w (deg/s) |
|---|---|---|---|
| 1 | 250, 300, 250 | 20, −10, 15 | 5, −5, 10 |
| 2 | 250, −150, 400 | −15, 20, 10 | −10, 5, 5 |
| 3 | −300, −300, 250 | 10, 15, −20 | 5, 10, −5 |

The IK starts from q0 = [20, 10, −20, 30, 45, 60] deg.

## How to run – MATLAB
```matlab
cd e_MATLAB/matlab
run_m2_tests            % 1c: IK -> FK, IVK -> FVK for the 3 cases   (output: run_m2_tests_output.txt)
print_m2_equations      % symbolic X(q), J(q), V_F                     (output: print_m2_equations_output.txt)
```

## How to run – Simulink / Simscape (requirement 4)
`IRB120_M2.slx` uses the same format as our M1 `IRB120_Simple`:
- one row per joint: Step (IK angle) + Ramp (IVK speed) → Transfer Fcn → Gain → Bias → joint;
- one Transform Sensor (flange p, v, w);
- the MATLAB Function blocks "FK equations" and "FVK equations", with Displays.

It needs the IRB 120 CAD folder (STEP files) on the MATLAB path:
```matlab
addpath('<path>/CAD_Model/CAD_Model')   % the folder with the STEP files
set_m2_case(1)                          % runs IK + IVK and writes them into the Step / Ramp blocks; then press Run
run_m2_simulink_tests                   % all 3 cases       (output: run_m2_simulink_tests_output.txt)
```
To rebuild the model from the CAD XML, use `build_m2_model.m` (set the environment variable `RED_CAD_DIR` to the CAD folder).

## How to run – Python and Gazebo (requirement 5)
```bash
python3 f_Python/run_m2_tests.py                       # same tests as MATLAB, no ROS (output: run_m2_tests_py_output.txt)
ros2 launch my_irb120_robot gazebo.launch.py           # terminal 1 (M1 launch file)
ros2 run my_irb120_robot m2_fk_node                    # terminal 2
ros2 run my_irb120_robot m2_ik_node 1                  # terminal 3, cases 1, 2, 3
ros2 run my_irb120_robot m2_velocity_node 1            # terminal 3, cases 1, 2, 3
```
Topics:
- `/irb120/m2/joint_angles` (IK → FK node, `sensor_msgs/JointState`);
- `/irb120/m2/fk_position`;
- `/irb120/jointN/cmd_pos` (to Gazebo).

The Gazebo flange pose is read from TF `world → EE_frame`.
