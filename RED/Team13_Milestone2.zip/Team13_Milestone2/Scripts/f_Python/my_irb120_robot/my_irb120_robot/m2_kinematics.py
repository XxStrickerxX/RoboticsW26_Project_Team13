"""RED Milestone 2: inverse position kinematics (Newton-Raphson) and velocity
kinematics of the ABB IRB 120 (6 joints). Python twin of the MATLAB functions.

No ROS needed:  python3 m2_kinematics.py   runs a short self-check.

Functions asked for in the brief (same names as MATLAB):
    X     = forward_kinematics_func()          symbolic flange position (from M1 FK)
    J_inv = inverse_jacobian_matrix(q)         pinv of dF/dq (3x6), numeric
    q     = inverse_kinematics_func(q0, X)     Newton-Raphson
    J     = jacobian_matrix(q)                 symbolic 6x6 Jacobian
    V_F   = forward_velocity_kinematics(q, q_dot)
    q_dot = inverse_velocity_kinematics(q, V_F)

Conventions (same as M1): standard DH, A_i = Rz(theta) Tz(d) Tx(a) Rx(alpha),
lengths in metres, angles in radians, frame 0 = robot base on the floor (z up).
"""
import sympy as sp
import numpy as np

# DH table of M1 (irb120_params.json): theta offset [rad], d [m], a [m], alpha [rad]
DH = [(0,          0.290, 0.000, -sp.pi / 2),
      (-sp.pi / 2, 0.000, 0.270, 0),
      (0,          0.000, 0.070, -sp.pi / 2),
      (0,          0.302, 0.000, sp.pi / 2),
      (0,          0.000, 0.000, -sp.pi / 2),
      (0,          0.072, 0.000, 0)]

q1, q2, q3, q4, q5, q6 = sp.symbols('q1 q2 q3 q4 q5 q6', real=True)
Q = [q1, q2, q3, q4, q5, q6]


def dh_matrix(theta, d, a, alpha):
    """Standard DH transform from frame i-1 to frame i (same as M1 dh_matrix.m)."""
    return sp.Matrix([
        [sp.cos(theta), -sp.sin(theta) * sp.cos(alpha),  sp.sin(theta) * sp.sin(alpha), a * sp.cos(theta)],
        [sp.sin(theta),  sp.cos(theta) * sp.cos(alpha), -sp.cos(theta) * sp.sin(alpha), a * sp.sin(theta)],
        [0,              sp.sin(alpha),                  sp.cos(alpha),                 d],
        [0,              0,                              0,                             1]])


def forward_kinematics_func():
    """Symbolic FK of M1: returns X = [x, y, z] of the flange and the frames
    T01..T06 (list), all in terms of q1..q6."""
    T = sp.eye(4)
    frames = []
    for i in range(6):
        off, d, a, alpha = DH[i]
        T = T * dh_matrix(Q[i] + off, d, a, alpha)
        frames.append(T)
    X = T[0:3, 3]
    return X, frames


# The symbolic expressions are built once and turned into fast numeric functions.
_X, _FRAMES = forward_kinematics_func()
_DFDQ = _X.jacobian(Q)                               # 3x6, dF/dq
_X_num = sp.lambdify([Q], _X, 'numpy')
_DFDQ_num = sp.lambdify([Q], _DFDQ, 'numpy')


def fk_position(q):
    """Numeric flange position [x, y, z] (m) for joint angles q (rad)."""
    return np.array(_X_num(list(q)), dtype=float).reshape(3)


def inverse_jacobian_matrix(q):
    """Pseudo-inverse (6x3) of dF/dq (3x6) at the numeric joint angles q.
    dF/dq is not square (3 position equations, 6 joints), so pinv is used."""
    dFdq = np.array(_DFDQ_num(list(q)), dtype=float)
    return np.linalg.pinv(dFdq)


def inverse_kinematics_func(q0, X, tol=1e-9, max_iter=100, verbose=True):
    """Newton-Raphson (Tutorial 04): F(q) = FK(q) - X,  q <- q - pinv(dF/dq) F.
    q0: initial guess (6 angles, rad).  X: desired flange position (3, m)."""
    q = np.array(q0, dtype=float).reshape(6)
    Xd = np.array(X, dtype=float).reshape(3)
    for k in range(1, max_iter + 1):
        F = fk_position(q) - Xd
        if np.linalg.norm(F) < tol:
            break
        q = q - inverse_jacobian_matrix(q) @ F
        q = (q + np.pi) % (2 * np.pi) - np.pi     # keep every angle in [-180, 180) deg
    F = fk_position(q) - Xd
    if verbose:
        print('IK: %d iterations, final error = %.2e mm' % (k, np.linalg.norm(F) * 1000))
        if np.linalg.norm(F) >= tol:
            print('IK warning: target not reached, it may be outside the workspace.')
    return q


def jacobian_matrix(q=None):
    """Symbolic 6x6 Jacobian, [v; w] = J q_dot.
    Rows 1-3: dX/dq (differentiation of the flange position).
    Rows 4-6: z axis of frame i-1 for each revolute joint i.
    q: list of 6 symbols or numbers (default: the symbols q1..q6)."""
    Jv = _X.jacobian(Q)
    z_axes = [sp.Matrix([0, 0, 1])] + [T[0:3, 2] for T in _FRAMES[:5]]
    Jw = sp.Matrix.hstack(*z_axes)
    J = sp.Matrix.vstack(Jv, Jw)
    if q is not None:
        J = J.subs(dict(zip(Q, q)))
    return J


_J_num = sp.lambdify([Q], jacobian_matrix(), 'numpy')


def jacobian_numeric(q):
    return np.array(_J_num(list(q)), dtype=float)


def forward_velocity_kinematics(q, q_dot):
    """V_F = J(q) q_dot = [vx, vy, vz, wx, wy, wz].
    Symbolic if q / q_dot are symbols, numeric (numpy array) if numbers."""
    if all(isinstance(v, (int, float, np.floating, np.integer)) for v in list(q) + list(q_dot)):
        return jacobian_numeric(q) @ np.array(q_dot, dtype=float)
    return jacobian_matrix(q) * sp.Matrix(q_dot)


def inverse_velocity_kinematics(q, V_F):
    """q_dot = J_inv(q) V_F, with J_inv = pinv of the 6x6 Jacobian.
    V_F = [vx, vy, vz, wx, wy, wz] (m/s, rad/s, base frame)."""
    J_inv = np.linalg.pinv(jacobian_numeric(q))
    return J_inv @ np.array(V_F, dtype=float).reshape(6)


if __name__ == '__main__':
    q0 = np.radians([10, -10, 20, 30, 40, 50])
    X = [0.35, 0.15, 0.45]
    q = inverse_kinematics_func(q0, X)
    print('q [deg] =', np.round(np.degrees(q), 3))
    print('FK(q) - X [mm] =', (fk_position(q) - X) * 1000)
