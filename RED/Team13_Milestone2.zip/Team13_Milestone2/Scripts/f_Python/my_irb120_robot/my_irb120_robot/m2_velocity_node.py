"""RED Milestone 2 - velocity node (brief 2, 3, 5): IVK -> joint speeds -> Gazebo vs FVK.

For test case N of irb120_params.json (the same timing as Simscape):
  1. q     = inverse_kinematics_func(q0, X)          (Newton-Raphson)
     q_dot = inverse_velocity_kinematics(q, V_F)     (pinv of the 6x6 Jacobian)
  2. t = 0..4 s : the robot moves smoothly to q (step at 1 s, filter 1/(0.2 s + 1)^2)
  3. t = 4..6 s : every joint turns at its IVK speed:  q(t) = q + q_dot * (t - 4)
  4. Gazebo flange velocity = time derivative of the flange pose that Gazebo reports
     (TF world -> EE_frame), compared with forward_velocity_kinematics(q(t), q_dot).
Prints the comparison every 0.5 s and a summary, saves ~/red_m2_results/velocity_caseN.csv,
then stops by itself.

    ros2 run my_irb120_robot m2_velocity_node 1        (case 1, 2 or 3)
"""
import sys

import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64
from tf2_ros import Buffer, TransformListener

from .common import CMD_TOPICS, joint_vector, load_robot
from .irb120_kin import step_motion
from .m2_common import case_from_argv, gazebo_flange, m2_case, rot_log, save_csv
from .m2_kinematics import (forward_velocity_kinematics, inverse_kinematics_func,
                            inverse_velocity_kinematics)

WINDOW = 0.10          # s, time between the two poses used for the derivative


class M2VelocityNode(Node):
    def __init__(self, case):
        super().__init__('m2_velocity_node', parameter_overrides=[
            Parameter('use_sim_time', Parameter.Type.BOOL, True)])
        robot = load_robot()
        self.case = case
        q0, X, self.V, m2 = m2_case(robot.params, case)
        self.ts = float(m2['step_time_s'])
        self.tr = float(m2['ramp_start_s'])
        self.tstop = float(m2['stop_time_s'])
        self.tau = float(robot.params['move']['filter_tau_s'])
        log = self.get_logger()
        log.info('Case %d: X = %s mm, v = %s mm/s, w = %s deg/s' % (
            case, np.round(X * 1000, 3).tolist(), np.round(self.V[:3] * 1000, 3).tolist(),
            np.round(np.degrees(self.V[3:]), 3).tolist()))
        self.q = inverse_kinematics_func(q0, X)
        self.qd = inverse_velocity_kinematics(self.q, self.V)
        log.info('IK joint angles   q     = %s deg' % np.round(np.degrees(self.q), 3).tolist())
        log.info('IVK joint speeds  q_dot = %s deg/s' % np.round(np.degrees(self.qd), 3).tolist())
        V0 = forward_velocity_kinematics(self.q, self.qd)
        log.info('FVK at the IK pose: v = %s mm/s, w = %s deg/s (= desired)' % (
            np.round(V0[:3] * 1000, 3).tolist(), np.round(np.degrees(V0[3:]), 3).tolist()))
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.cmd = [self.create_publisher(Float64, t, 10) for t in CMD_TOPICS]
        self.create_subscription(JointState, '/joint_states', self.on_joints, 10)
        self.q_start = None
        self.q_meas = None
        self.t0 = None
        self.poses = []                # (t, p, R) from Gazebo during the velocity part
        self.rows = []
        self.next_print = self.tr + 0.5
        self.finished = False
        self.create_timer(0.01, self.tick)

    def on_joints(self, msg):
        q = joint_vector(msg)
        if q is None:
            return
        self.q_meas = q
        if self.q_start is None:
            self.q_start = q

    def command(self, t):
        if t < self.tr:
            q, _, _ = step_motion(self.q_start, self.q, t, self.ts, self.tau)
        else:
            q = self.q + self.qd * (t - self.tr)
        return q

    def tick(self):
        now = self.get_clock().now().nanoseconds * 1e-9
        if self.q_start is None or now <= 0.0:
            return
        if self.t0 is None:
            self.t0 = now
            self.get_logger().info('Moving to the IK pose, joint speeds start at t = %.1f s ...' % self.tr)
        t = now - self.t0
        q_cmd = self.command(min(t, self.tstop))
        for pub, v in zip(self.cmd, q_cmd):
            pub.publish(Float64(data=float(v)))
        if t < self.tr or t > self.tstop or self.finished:
            if t > self.tstop and not self.finished:
                self.finish()
            return
        g = gazebo_flange(self.tf_buffer)
        if g is None or (self.poses and g[0] <= self.poses[-1][0]):
            return                                  # no new Gazebo pose yet
        self.poses.append(g)
        old = [P for P in self.poses if P[0] <= g[0] - WINDOW]
        if not old:
            return
        t1, p1, R1 = old[-1]
        t2, p2, R2 = g
        dt = t2 - t1
        v_gz = (p2 - p1) / dt
        w_gz = rot_log(R2 @ R1.T) / dt
        tm = 0.5 * (t1 + t2) - self.t0             # middle of the window (node time)
        q_mid = self.q + self.qd * (tm - self.tr)
        V_eq = forward_velocity_kinematics(q_mid, self.qd)
        if self.q_meas is not None:
            V_meas = forward_velocity_kinematics(self.q_meas, self.qd)
        else:
            V_meas = V_eq
        self.rows.append([tm] + list(v_gz * 1000) + list(V_eq[:3] * 1000) + list(np.degrees(w_gz))
                         + list(np.degrees(V_eq[3:])) + list(V_meas[:3] * 1000))
        if t >= self.next_print:
            self.next_print += 0.5
            self.get_logger().info(
                't=%.1f s  Gazebo v %s mm/s | FVK v %s mm/s | Gazebo w %s deg/s | FVK w %s deg/s'
                % (tm, np.round(v_gz * 1000, 2).tolist(), np.round(V_eq[:3] * 1000, 2).tolist(),
                   np.round(np.degrees(w_gz), 2).tolist(), np.round(np.degrees(V_eq[3:]), 2).tolist()))

    def finish(self):
        self.finished = True
        if not self.rows:
            self.get_logger().error('No flange poses from Gazebo (TF world -> EE_frame). '
                                    'Is robot_state_publisher running (launch file)?')
            return
        A = np.array(self.rows)
        keep = A[:, 0] > self.tr + 0.3               # skip the first 0.3 s (joints speeding up)
        if not np.any(keep):
            keep = np.ones(len(A), dtype=bool)
        dv = np.linalg.norm(A[keep, 1:4] - A[keep, 4:7], axis=1)
        dw = np.linalg.norm(A[keep, 7:10] - A[keep, 10:13], axis=1)
        self.get_logger().info('SUMMARY case %d (t = %.1f..%.1f s): |Gazebo - FVK| v mean %.3f mm/s, '
                               'max %.3f mm/s | w mean %.4f deg/s, max %.4f deg/s'
                               % (self.case, self.tr + 0.3, self.tstop, dv.mean(), dv.max(),
                                  dw.mean(), dw.max()))
        path = save_csv('velocity_case%d.csv' % self.case,
                        ['t', 'vx_gz', 'vy_gz', 'vz_gz', 'vx_fvk', 'vy_fvk', 'vz_fvk', 'wx_gz', 'wy_gz',
                         'wz_gz', 'wx_fvk', 'wy_fvk', 'wz_fvk', 'vx_fvk_meas', 'vy_fvk_meas',
                         'vz_fvk_meas'], self.rows)
        self.get_logger().info('saved %s. Velocity node done.' % path)


def main():
    case = case_from_argv(sys.argv)
    rclpy.init()
    node = M2VelocityNode(case)
    try:
        while rclpy.ok() and not node.finished:
            rclpy.spin_once(node, timeout_sec=0.1)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.try_shutdown()


if __name__ == '__main__':
    main()
