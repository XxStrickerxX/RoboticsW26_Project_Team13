"""Automatic Gazebo test (requirement R5). Run it while Gazebo is running.

Part A - test poses: moves to each test pose with the same smooth
"give angles" motion as Simscape (step smoothed by 1/(0.2 s + 1)^2, starting
from where the robot is), waits until Gazebo has reached it, then compares
   * flange position from our FK of the SENSED joint angles
     with the flange position from TF (URDF chain in robot_state_publisher)
   * IK(FK(q_sensed)) with q_sensed (inverse result vs kinematic equations),
     with the trigonometric IK and with Newton-Raphson (guess = home pose)
Part B - "give angles" move (the same as the Simscape model IRB120_Simple):
start angles, then at t = 1 s the target angles, smoothed by 1/(0.2 s + 1)^2.
The sensed joint angles are recorded; joint rates are estimated from them
(filtered), because the velocity Gazebo reports jumps with every new command.
   * v = Jv * qd   vs  numerical derivative of the sensed flange position
   * sensed flange motion vs the motion given by the equations (step_motion),
     both passed through the same filtering
   * flange position at the end vs FK of the target angles
The node runs on Gazebo's clock (/clock), so commands follow simulation time.
Results: printed table + CSV files in ~/irb120_m1_results/

    ros2 run my_irb120_robot kinematics_test_node
"""
import csv
import os

import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.time import Time
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64, Float64MultiArray
from tf2_ros import Buffer, TransformListener

from .common import BASE_FRAME, CMD_TOPICS, EE_FRAME, joint_vector, load_robot
from .irb120_kin import step_motion, wrap

POS_TOL = 1e-6      # m   FK vs TF (same robot, two implementations)
ANG_TOL = 1e-6      # rad IK round trip
REACHED = 2e-3      # rad Gazebo has reached the command
TIMEOUT = 15.0      # s   per pose
SETTLE = 1.0        # s   hold still before measuring (TF must catch up)


class KinTest(Node):
    def __init__(self):
        super().__init__('irb120_kinematics_test', parameter_overrides=[
            Parameter('use_sim_time', Parameter.Type.BOOL, True)])
        self.robot = load_robot()
        p = self.robot.params
        self.poses = np.radians(p['test_poses_deg'])
        mv = p['move']
        self.q0 = np.radians(mv['start_deg'])
        self.q1 = np.radians(mv['target_deg'])
        self.ts = float(mv['step_time_s'])
        self.tau = float(mv['filter_tau_s'])
        self.T = float(mv['stop_time_s'])
        self.cmd = [self.create_publisher(Float64, t, 10) for t in CMD_TOPICS]
        self.ref = self.create_publisher(Float64MultiArray, '/irb120/joint_reference', 10)
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.create_subscription(JointState, '/joint_states', self.on_joints, 50)
        self.q = None
        self.qd = np.zeros(6)
        self.t_js = None
        self.state = 'pose'
        self.k = 0
        self.t_phase = None            # set when the Gazebo clock is running
        self.t_ok = None
        self.q_from = None             # where the current smooth move started
        self.static_rows = []
        self.move = []
        self.outdir = os.path.expanduser('~/irb120_m1_results')
        os.makedirs(self.outdir, exist_ok=True)
        self.create_timer(0.01, self.tick)
        self.get_logger().info('Kinematics test started (make sure Gazebo is playing).')

    def now(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def on_joints(self, msg):
        q = joint_vector(msg)
        if q is None:
            return
        qd = joint_vector(msg, 'velocity')
        self.q = q
        self.qd = qd if qd is not None else np.zeros(6)
        self.t_js = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        if self.state == 'move':
            self.move.append((self.t_js, self.q.copy()))

    def tf_pos(self):
        try:
            tr = self.tf_buffer.lookup_transform(BASE_FRAME, EE_FRAME, Time())
            t = tr.transform.translation
            return np.array([t.x, t.y, t.z])
        except Exception:
            return None

    def send(self, q, qd=None, qdd=None):
        z = np.zeros(6)
        for pub, v in zip(self.cmd, q):
            pub.publish(Float64(data=float(v)))
        m = Float64MultiArray()
        m.data = [float(v) for v in np.concatenate([q, z if qd is None else qd, z if qdd is None else qdd])]
        self.ref.publish(m)

    def tick(self):
        if self.t_phase is None:                    # wait for /clock and /joint_states
            if self.q is None or self.now() <= 0.0:
                return
            self.t_phase = self.now()
        if self.q_from is None:
            self.q_from = self.q.copy()                 # start of the next smooth move
        t = self.now() - self.t_phase
        if self.state == 'pose':
            target = self.poses[self.k]
            self.send(*step_motion(self.q_from, target, t, 0.0, self.tau))
            done = np.abs(wrap(self.q - target)).max() < REACHED and np.abs(self.qd).max() < 1e-3
            if done and self.t_ok is None:
                self.t_ok = self.now()                      # reached: start holding
            if not done:
                self.t_ok = None
            settled = self.t_ok is not None and self.now() - self.t_ok > SETTLE
            if settled or t > TIMEOUT:
                self.record_pose(target, reached=settled)
                self.k += 1
                self.t_phase, self.t_ok, self.q_from = self.now(), None, None
                if self.k >= len(self.poses):
                    self.state = 'to_start'
        elif self.state == 'to_start':                  # smooth move back to the start
            self.send(*step_motion(self.q_from, self.q0, t, 0.0, self.tau))
            if np.abs(wrap(self.q - self.q0)).max() < REACHED and np.abs(self.qd).max() < 1e-3:
                self.state, self.t_phase = 'move', self.now()
                self.move = []
        elif self.state == 'move':
            q, qd, qdd = step_motion(self.q0, self.q1, t, self.ts, self.tau)
            self.send(q, qd, qdd)
            if t > self.T:
                self.state = 'done'
                self.finish()

    def record_pose(self, target, reached):
        q = self.q.copy()
        T = self.robot.fk(q)
        p_tf = self.tf_pos()
        d_tf = np.nan if p_tf is None else float(np.linalg.norm(p_tf - T[:3, 3]))
        q_ik = self.robot.ik(T, q)
        ik_err = np.inf if q_ik is None else float(np.abs(wrap(q_ik - q)).max())
        q_nr, it, _ = self.robot.ik_newton(T, np.radians([0, 0, 0, 0, 30, 0]))
        nr_err = float(np.abs(self.robot.fk(q_nr) - T).max())
        track = float(np.abs(wrap(q - target)).max())
        self.static_rows.append([self.k + 1, *np.round(np.degrees(q), 3), *np.round(T[:3, 3], 6),
                                 d_tf, ik_err, nr_err, it, track, reached])
        self.get_logger().info('pose %d: flange %s m | FK vs TF %.1e m | trig IK round trip %.1e rad | '
                               'Newton-Raphson pose error %.1e (%d it.) | tracking %.1e rad%s'
                               % (self.k + 1, np.round(T[:3, 3], 4).tolist(), d_tf, ik_err,
                                  nr_err, it, track, '' if reached else '  (TIMEOUT)'))

    def flange(self, Q, QD, QDD):
        """Flange p = FK(q), v = Jv qd, a = Jv qdd + Jv_dot qd for every sample."""
        E = [self.robot.ee_motion(q, qd, qdd) for q, qd, qdd in zip(Q, QD, QDD)]
        return (np.array([e[0] for e in E]), np.array([e[1] for e in E]),
                np.array([e[2] for e in E]))

    def finish(self):
        with open(os.path.join(self.outdir, 'ros_static_poses.csv'), 'w', newline='') as f:
            w = csv.writer(f)
            w.writerow(['pose', 'q1_deg', 'q2_deg', 'q3_deg', 'q4_deg', 'q5_deg', 'q6_deg',
                        'x_m', 'y_m', 'z_m', 'fk_vs_tf_m', 'ik_trig_roundtrip_rad',
                        'ik_newton_pose_err', 'ik_newton_iterations', 'tracking_rad', 'reached'])
            w.writerows(self.static_rows)
        ok_static = all(r[10] < POS_TOL and r[11] < ANG_TOL and r[12] < POS_TOL
                        for r in self.static_rows)

        # "give angles" move analysis
        msg = 'not enough samples of the move'
        if len(self.move) > 30:
            t = np.array([s_[0] for s_ in self.move])
            Q = np.array([s_[1] for s_ in self.move])
            keep = np.concatenate([[True], np.diff(t) > 1e-6])
            t, Q = t[keep] - self.t_phase, Q[keep]                  # time since the move began
            # sensed: filtered angles, rates and accelerations -> flange p, v, a
            Q, QD, QDD = rates(Q, t)
            P, V, A = self.flange(Q, QD, QDD)
            Vn = smooth(np.gradient(P, t, axis=0))
            m = slice(10, -10)                                       # skip filter edges
            ev = np.linalg.norm(V - Vn, axis=1)[m]
            # the same move from the equations (what MATLAB and Simscape use),
            # sampled at the same times and passed through the SAME filtering,
            # so the comparison only shows what the Gazebo controller adds
            Qe = np.array([step_motion(self.q0, self.q1, tt, self.ts, self.tau)[0] for tt in t])
            Pe, Ve, Ae = self.flange(*rates(Qe, t))
            Ax = np.array([self.robot.ee_motion(*step_motion(self.q0, self.q1, tt, self.ts,
                                                             self.tau))[2] for tt in t])
            p_end = P[-1]
            p_target = self.robot.fk(self.q1)[:3, 3]
            msg = ('move to %s deg: flange at the end %s m, FK of target %s m (diff %.1e m) | '
                   'peak speed sensed %.3f / equations %.3f m/s | peak accel sensed %.3f / '
                   'equations %.3f m/s^2 (same filtering; exact peak %.3f, it jumps at the '
                   'step) | |Jv qd - dp/dt| RMS %.1e m/s | '
                   'position lag behind the equations max %.1f mm (Gazebo controller)'
                   % (np.round(np.degrees(self.q1), 1).tolist(), np.round(p_end, 4).tolist(),
                      np.round(p_target, 4).tolist(), np.linalg.norm(p_end - p_target),
                      np.linalg.norm(V, axis=1)[m].max(), np.linalg.norm(Ve, axis=1)[m].max(),
                      np.linalg.norm(A, axis=1)[m].max(), np.linalg.norm(Ae, axis=1)[m].max(),
                      np.linalg.norm(Ax, axis=1).max(), np.sqrt(np.mean(ev ** 2)), 1000 * np.linalg.norm(P - Pe, axis=1).max()))
            with open(os.path.join(self.outdir, 'ros_move.csv'), 'w', newline='') as f:
                w = csv.writer(f)
                w.writerow(['t'] + [f'q{i}' for i in range(1, 7)]
                           + ['x', 'y', 'z', 'vx', 'vy', 'vz', 'ax', 'ay', 'az',
                              'x_eq', 'y_eq', 'z_eq', 'vx_eq', 'vy_eq', 'vz_eq',
                              'ax_eq', 'ay_eq', 'az_eq'])
                for i in range(len(t)):
                    w.writerow([t[i], *Q[i], *P[i], *V[i], *A[i], *Pe[i], *Ve[i], *Ae[i]])
        self.get_logger().info(msg)
        self.get_logger().info('STATIC POSES: %s  (FK vs TF < %.0e m, IK round trip < %.0e rad, '
                               'Newton-Raphson converged)'
                               % ('PASS' if ok_static else 'FAIL', POS_TOL, ANG_TOL))
        self.get_logger().info(f'CSV files written to {self.outdir}. Press Ctrl+C to exit.')


def rates(Q, t):
    """Filtered angles, joint rates and joint accelerations from sampled angles."""
    Q = smooth(Q)
    QD = smooth(np.gradient(Q, t, axis=0))
    QDD = smooth(np.gradient(QD, t, axis=0))
    return Q, QD, QDD


def smooth(X, n=9):
    """Moving average over n samples (reduces the noise of numerical derivatives).
    The ends are padded with the first / last value so they are not pulled to 0."""
    k = np.ones(n) / n
    pad = n // 2
    Xp = np.vstack([np.repeat(X[:1], pad, axis=0), X, np.repeat(X[-1:], pad, axis=0)])
    return np.column_stack([np.convolve(Xp[:, j], k, mode='valid') for j in range(X.shape[1])])


def main():
    rclpy.init()
    node = KinTest()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.try_shutdown()


if __name__ == '__main__':
    main()
