"""Joint commander (requirements R4 and R5): GIVE ANGLES -> the robot moves.

Same behaviour as the Simscape model IRB120_Simple:
  * the robot holds its start angles, and 1 s after this node starts it
    gets the target angles q_deg,
  * the step is smoothed by the same filter 1/(0.2 s + 1)^2,
  * the angle, angular velocity and angular acceleration are published.

Publishes : /irb120/jointN/cmd_pos   (std_msgs/Float64, rad) -> Gazebo
            /irb120/joint_reference  (std_msgs/Float64MultiArray)
                                     = [q1..q6, qd1..qd6, qdd1..qdd6]
Runs on the Gazebo clock (/clock).

Default target = "move.target_deg" in irb120_params.json ([30 20 10 40 50 60]).
Other angles (type them with a decimal point):
  ros2 run my_irb120_robot joint_commander --ros-args -p "q_deg:=[45.0,30.0,-20.0,60.0,60.0,90.0]"
(For sliders use: ros2 run my_irb120_robot slider_gui)
"""
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64, Float64MultiArray

from .common import CMD_TOPICS, joint_vector, load_robot
from .irb120_kin import step_motion


class JointCommander(Node):
    def __init__(self):
        super().__init__('irb120_joint_commander', parameter_overrides=[
            Parameter('use_sim_time', Parameter.Type.BOOL, True)])
        self.robot = load_robot()
        mv = self.robot.params['move']
        self.declare_parameter('q_deg', [float(v) for v in mv['target_deg']])
        self.ts = float(mv['step_time_s'])
        self.tau = float(mv['filter_tau_s'])
        self.q1 = np.clip(np.radians(np.array(self.get_parameter('q_deg').value, dtype=float)),
                          self.robot.q_min, self.robot.q_max)
        self.q0 = None                       # start = where the robot is now
        self.t0 = None
        self.done = False
        self.cmd = [self.create_publisher(Float64, t, 10) for t in CMD_TOPICS]
        self.ref = self.create_publisher(Float64MultiArray, '/irb120/joint_reference', 10)
        self.create_subscription(JointState, '/joint_states', self.on_joints, 10)
        self.create_timer(0.01, self.tick)   # 100 Hz
        self.get_logger().info('Target angles [deg]: %s  (move starts 1 s after Gazebo time is '
                               'received)' % np.round(np.degrees(self.q1), 2).tolist())

    def on_joints(self, msg):
        if self.q0 is None:
            q = joint_vector(msg)
            if q is not None:
                self.q0 = q

    def tick(self):
        now = self.get_clock().now().nanoseconds * 1e-9
        if self.q0 is None or now <= 0.0:
            return                           # wait for /joint_states and /clock
        if self.t0 is None:
            self.t0 = now
        t = now - self.t0
        q, qd, qdd = step_motion(self.q0, self.q1, t, self.ts, self.tau)
        for pub, v in zip(self.cmd, q):
            pub.publish(Float64(data=float(v)))
        msg = Float64MultiArray()
        msg.data = [float(v) for v in np.concatenate([q, qd, qdd])]
        self.ref.publish(msg)
        if not self.done and t > self.ts + 10 * self.tau:
            self.done = True
            p = self.robot.fk(self.q1)[:3, 3]
            self.get_logger().info('Move finished. Flange from FK of the target: '
                                   '[%.4f %.4f %.4f] m  (node keeps holding the pose; Ctrl+C to stop)'
                                   % tuple(p))


def main():
    rclpy.init()
    node = JointCommander()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.try_shutdown()


if __name__ == '__main__':
    main()
