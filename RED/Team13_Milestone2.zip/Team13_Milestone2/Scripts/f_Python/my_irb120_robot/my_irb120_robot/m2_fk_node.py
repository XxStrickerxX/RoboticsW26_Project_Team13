"""RED Milestone 2 - FK node (brief 1b): subscribes to the joint angles of the IK node.

Subscribes : /irb120/m2/joint_angles (sensor_msgs/JointState, from m2_ik_node)
             /joint_states            (Gazebo, to know when the robot has arrived)
             TF world -> EE_frame     (flange pose reported by Gazebo)
Publishes  : /irb120/m2/fk_position  (geometry_msgs/PointStamped)

For every new set of joint angles it computes the flange position with
forward_kinematics_func (the Milestone 1 FK), waits until the robot in Gazebo has
arrived and stands still, then prints Gazebo vs FK. Results: ~/red_m2_results/ik_fk_gazebo.csv

    ros2 run my_irb120_robot m2_fk_node        (keep it running for all three cases)
"""
import numpy as np
import rclpy
from geometry_msgs.msg import PointStamped
from rclpy.node import Node
from rclpy.parameter import Parameter
from sensor_msgs.msg import JointState
from tf2_ros import Buffer, TransformListener

from .common import BASE_FRAME, joint_vector
from .m2_common import ANGLES_TOPIC, FK_TOPIC, gazebo_flange, save_csv
from .m2_kinematics import fk_position


class M2FKNode(Node):
    def __init__(self):
        super().__init__('m2_fk_node', parameter_overrides=[
            Parameter('use_sim_time', Parameter.Type.BOOL, True)])
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.pub = self.create_publisher(PointStamped, FK_TOPIC, 10)
        self.create_subscription(JointState, ANGLES_TOPIC, self.on_angles, 10)
        self.create_subscription(JointState, '/joint_states', self.on_joints, 10)
        self.q = None
        self.X_fk = None
        self.waiting = False
        self.still_since = None
        self.q_prev = None
        self.rows = []
        self.get_logger().info('FK node ready: waiting for joint angles on %s' % ANGLES_TOPIC)

    def on_angles(self, msg):
        q = np.array(msg.position, dtype=float)
        if self.q is not None and np.allclose(q, self.q, atol=1e-9):
            return                                     # same angles again
        self.q = q
        self.X_fk = fk_position(q)
        self.waiting = True
        self.still_since = None
        out = PointStamped()
        out.header.stamp, out.header.frame_id = msg.header.stamp, BASE_FRAME
        out.point.x, out.point.y, out.point.z = (float(v) for v in self.X_fk)
        self.pub.publish(out)
        self.get_logger().info('Joint angles received %s deg -> FK flange position %s mm. '
                               'Waiting for the robot to arrive ...'
                               % (np.round(np.degrees(q), 3).tolist(), np.round(self.X_fk * 1000, 3).tolist()))

    def on_joints(self, msg):
        if not self.waiting:
            return
        qm = joint_vector(msg)
        if qm is None:
            return
        t = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        moving = self.q_prev is None or np.abs(qm - self.q_prev).max() > 1e-5
        self.q_prev = qm
        if np.abs(qm - self.q).max() > 2e-3 or moving:  # not there yet (0.1 deg) or still moving
            self.still_since = None
            return
        if self.still_since is None:
            self.still_since = t
            return
        if t - self.still_since < 1.0:                 # standing still for 1 s
            return
        g = gazebo_flange(self.tf_buffer)
        if g is None:
            return
        self.waiting = False
        _, p, _ = g
        e = np.linalg.norm(p - self.X_fk)
        self.get_logger().info('RESULT  Gazebo flange %s mm | FK %s mm | |Gazebo - FK| = %.3f mm | '
                               'joint error %.4f deg'
                               % (np.round(p * 1000, 3).tolist(), np.round(self.X_fk * 1000, 3).tolist(),
                                  e * 1000, np.degrees(np.abs(qm - self.q).max())))
        self.rows.append(list(np.degrees(self.q)) + list(self.X_fk * 1000) + list(p * 1000) + [e * 1000])
        path = save_csv('ik_fk_gazebo.csv',
                        ['q1_deg', 'q2_deg', 'q3_deg', 'q4_deg', 'q5_deg', 'q6_deg', 'x_fk_mm', 'y_fk_mm',
                         'z_fk_mm', 'x_gz_mm', 'y_gz_mm', 'z_gz_mm', 'err_mm'], self.rows)
        self.get_logger().info('saved %s' % path)


def main():
    rclpy.init()
    node = M2FKNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.try_shutdown()


if __name__ == '__main__':
    main()
