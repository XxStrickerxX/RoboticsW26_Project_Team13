"""IRB 120 kinematics (Python twin of the MATLAB functions).

Plain numpy, no ROS needed, so it can be tested on its own:
    python3 irb120_kin.py

Conventions (same as MATLAB):
  * Standard DH: A_i = Rz(theta_i) Tz(d_i) Tx(a_i) Rx(alpha_i),
    theta_i = q_i + offset_i.
  * Lengths in metres, angles in radians.
  * Base frame 0 = the 'world' frame of the URDF (on the floor, z up).
  * Frame 6 = robot flange (URDF link 'EE_frame').
"""
import json
import math
import os

import numpy as np

# Default values = params/irb120_params.json (used if the file is not found)
_DEFAULT_DH_DEG = [
    [0.0, 0.290, 0.000, -90.0],
    [-90.0, 0.000, 0.270, 0.0],
    [0.0, 0.000, 0.070, -90.0],
    [0.0, 0.302, 0.000, 90.0],
    [0.0, 0.000, 0.000, -90.0],
    [0.0, 0.072, 0.000, 0.0],
]
_DEFAULT_LOWER = [-165, -110, -110, -160, -120, -400]
_DEFAULT_UPPER = [165, 110, 70, 160, 120, 400]


class IRB120:
    """Holds the DH table and joint limits and offers FK / IK / Jacobian."""

    def __init__(self, params_file=None):
        p = None
        if params_file and os.path.isfile(params_file):
            with open(params_file) as f:
                p = json.load(f)
        rows = p['dh']['rows'] if p else _DEFAULT_DH_DEG
        lower = p['joint_limits_deg']['lower'] if p else _DEFAULT_LOWER
        upper = p['joint_limits_deg']['upper'] if p else _DEFAULT_UPPER
        rows = np.array(rows, dtype=float)
        self.offset = np.radians(rows[:, 0])
        self.d = rows[:, 1]
        self.a = rows[:, 2]
        self.alpha = np.radians(rows[:, 3])
        self.q_min = np.radians(lower)
        self.q_max = np.radians(upper)
        self.params = p

    # ------------------------------------------------------------------ FK
    @staticmethod
    def dh_matrix(theta, d, a, alpha):
        ct, st = math.cos(theta), math.sin(theta)
        ca, sa = math.cos(alpha), math.sin(alpha)
        return np.array([[ct, -st * ca, st * sa, a * ct],
                         [st, ct * ca, -ct * sa, a * st],
                         [0.0, sa, ca, d],
                         [0.0, 0.0, 0.0, 1.0]])

    def frames(self, q):
        """List [T_00, T_01, ..., T_06] of 4x4 frames in the base frame."""
        T = np.eye(4)
        out = [T.copy()]
        for i in range(6):
            T = T @ self.dh_matrix(q[i] + self.offset[i], self.d[i],
                                   self.a[i], self.alpha[i])
            out.append(T.copy())
        return out

    def fk(self, q):
        """Flange pose T_06 (4x4)."""
        return self.frames(q)[-1]

    # ------------------------------------------------------------------ IK
    def ik_all(self, T):
        """All analytic IK solutions (up to 8) for flange pose T.

        Returns an (n x 6) array, angles wrapped to (-pi, pi].
        Branches: shoulder (front/back) x elbow (up/down) x wrist (flip).
        """
        d1, a2, a3, d4, d6 = self.d[0], self.a[1], self.a[2], self.d[3], self.d[5]
        R = T[:3, :3]
        p = T[:3, 3]
        pw = p - d6 * R[:, 2]                  # wrist centre
        L = math.hypot(a3, d4)                 # elbow -> wrist centre
        beta = math.atan2(d4, a3)
        sols = []
        q1a = math.atan2(pw[1], pw[0]) if math.hypot(pw[0], pw[1]) > 1e-9 else 0.0
        for q1 in (q1a, q1a + math.pi):
            r = pw[0] * math.cos(q1) + pw[1] * math.sin(q1)
            s = pw[2] - d1
            c = (r * r + s * s - a2 * a2 - L * L) / (2 * a2 * L)
            if abs(c) > 1 + 1e-9:
                continue                       # out of reach for this branch
            c = max(-1.0, min(1.0, c))
            for g in (math.acos(c), -math.acos(c)):    # g = q3 + beta
                q3 = g - beta
                A = a2 + L * math.cos(g)
                B = L * math.sin(g)
                q2 = math.atan2(r, s) - math.atan2(B, A)
                q_arm = [q1, q2, q3, 0.0, 0.0, 0.0]
                R03 = self.frames(q_arm)[3][:3, :3]
                R36 = R03.T @ R
                s5 = math.hypot(R36[0, 2], R36[1, 2])
                for sign in (1.0, -1.0):
                    q5 = math.atan2(sign * s5, R36[2, 2])
                    if s5 < 1e-9:              # wrist singularity: q4 + q6 coupled
                        q4 = 0.0
                        if R36[2, 2] > 0:      # q5 = 0
                            q6 = math.atan2(R36[1, 0], R36[0, 0])
                        else:                  # q5 = +-180 deg
                            q6 = math.atan2(R36[1, 0], -R36[0, 0])
                    else:
                        # R36 = [.. .. -c4s5; .. .. -s4s5; s5c6 -s5s6 c5]
                        q4 = math.atan2(-sign * R36[1, 2], -sign * R36[0, 2])
                        q6 = math.atan2(-sign * R36[2, 1], sign * R36[2, 0])
                    sols.append([q1, q2, q3, q4, q5, q6])
        if not sols:
            return np.zeros((0, 6))
        return wrap(np.array(sols))

    def within_limits(self, q):
        return bool(np.all(q >= self.q_min - 1e-9) and np.all(q <= self.q_max + 1e-9))

    def ik(self, T, q_ref=None):
        """Best IK solution: inside the joint limits and closest to q_ref."""
        q_ref = np.zeros(6) if q_ref is None else np.asarray(q_ref, float)
        best, best_cost = None, None
        for q in self.ik_all(T):
            if not self.within_limits(q):
                continue
            cost = float(np.sum(wrap(q - q_ref) ** 2))
            if best is None or cost < best_cost:
                best, best_cost = q, cost
        return best        # None if no solution inside the limits

    # ------------------------------------------ IK, numerical (Newton-Raphson)
    def nr_function(self, q, target, active):
        """F(q): the equations whose root is the IK solution.
        position mode: F = p(q) - p_d                         (3 equations)
        pose mode    : F = [p(q) - p_d ;  rotation error]     (6 equations)
        The rotation error is angle*axis of R * R_d^T: zero only when the
        flange orientation equals the desired one."""
        T = self.fk(q)
        if target.shape == (3,):
            return T[:3, 3] - target
        eo = rot_error(T[:3, :3] @ target[:3, :3].T)
        return np.concatenate([T[:3, 3] - target[:3, 3], eo])

    def ik_newton(self, target, q0, tol=1e-10, max_iter=100, h=1e-7):
        """Newton-Raphson IK as in the course (Tutorial 04):
            q_{n+1} = q_n - [dF/dq]^-1 F(q_n)
        target = 3-vector (position only: solves q1..q3, q4..q6 stay at q0)
               or 4x4 pose (solves all 6 joints).
        dF/dq is computed numerically (central differences).
        Returns (q, iterations, |F|)."""
        target = np.asarray(target, float)
        q = np.array(q0, dtype=float)
        active = [0, 1, 2] if target.shape == (3,) else list(range(6))
        F = self.nr_function(q, target, active)
        for it in range(1, max_iter + 1):
            J = np.zeros((len(F), len(active)))
            for c, j in enumerate(active):
                e = np.zeros(6)
                e[j] = h
                J[:, c] = (self.nr_function(q + e, target, active)
                           - self.nr_function(q - e, target, active)) / (2 * h)
            if abs(np.linalg.det(J)) > 1e-12:
                dq = np.linalg.solve(J, F)
            else:                                   # near a singularity
                dq = np.linalg.pinv(J) @ F
            if np.abs(dq).max() > 0.5:              # limit the step to 0.5 rad
                dq = dq * 0.5 / np.abs(dq).max()
            q[active] = q[active] - dq
            q = wrap(q)
            F = self.nr_function(q, target, active)
            if np.linalg.norm(F) < tol:
                return q, it, float(np.linalg.norm(F))
        return q, max_iter, float(np.linalg.norm(F))

    # ------------------------------------------------------- Jacobian etc.
    def jacobian(self, q):
        """Geometric Jacobian J (6x6): [v; w] = J q_dot. Rows 0-2 = Jv."""
        F = self.frames(q)
        pe = F[6][:3, 3]
        J = np.zeros((6, 6))
        for i in range(6):
            z = F[i][:3, 2]
            o = F[i][:3, 3]
            J[:3, i] = np.cross(z, pe - o)
            J[3:, i] = z
        return J

    def jacobian_dot(self, q, qd):
        """Exact time derivative of the geometric Jacobian (6x6)."""
        F = self.frames(q)
        z = [F[i][:3, 2] for i in range(7)]
        o = [F[i][:3, 3] for i in range(7)]
        # angular velocity and origin velocity of every frame
        w = [np.zeros(3)]
        v = [np.zeros(3)]
        for i in range(6):
            w.append(w[i] + z[i] * qd[i])
        for k in range(1, 7):
            vk = np.zeros(3)
            for j in range(k):
                vk += np.cross(z[j], o[k] - o[j]) * qd[j]
            v.append(vk)
        Jd = np.zeros((6, 6))
        for i in range(6):
            zd = np.cross(w[i], z[i])
            Jd[:3, i] = np.cross(zd, o[6] - o[i]) + np.cross(z[i], v[6] - v[i])
            Jd[3:, i] = zd
        return Jd

    def ee_motion(self, q, qd, qdd):
        """Flange position p, linear velocity v and linear acceleration a.

        v = Jv qd ,  a = Jv qdd + Jv_dot qd
        """
        J = self.jacobian(q)
        Jd = self.jacobian_dot(q, qd)
        p = self.fk(q)[:3, 3]
        v = J[:3] @ qd
        a = J[:3] @ qdd + Jd[:3] @ qd
        return p, v, a


def rot_error(Re):
    """angle * axis of the rotation matrix Re (zero vector if Re = I)."""
    c = max(-1.0, min(1.0, (np.trace(Re) - 1.0) / 2.0))
    th = math.acos(c)
    v = np.array([Re[2, 1] - Re[1, 2], Re[0, 2] - Re[2, 0], Re[1, 0] - Re[0, 1]])
    if th < 1e-6:
        return 0.5 * v
    if th > math.pi - 1e-4:                 # about 180 deg: axis from the diagonal
        k = int(np.argmax(np.diag(Re)))
        ax = Re[:, k] + np.eye(3)[:, k]
        ax = ax / np.linalg.norm(ax)
        return th * ax
    return th / (2.0 * math.sin(th)) * v


def wrap(q):
    """Wrap angles to (-pi, pi]."""
    return -((-np.asarray(q, float) + np.pi) % (2 * np.pi) - np.pi)


def step_motion(q0, q1, t, ts, tau):
    """"Give angles" move (same as MATLAB step_motion.m and the Transfer Fcn
    block 1/(tau*s+1)^2 in IRB120_Simple): q0 until ts, then target q1.
    Returns q, qd, qdd at time t."""
    q0 = np.asarray(q0, float)
    dq = np.asarray(q1, float) - q0
    if t <= ts:
        z = np.zeros_like(dq)
        return q0.copy(), z, z.copy()
    u = (t - ts) / tau
    e = math.exp(-u)
    return (q0 + dq * (1 - (1 + u) * e),
            dq * (u / tau) * e,
            dq * (1 - u) / tau ** 2 * e)


if __name__ == '__main__':
    # Small self-test (no ROS needed)
    rob = IRB120()
    np.set_printoptions(precision=4, suppress=True)
    print('Flange at home q=0:', rob.fk(np.zeros(6))[:3, 3], '(expected 0.374 0 0.63)')
    q = np.radians([30, 20, 10, 40, 50, 60])
    sols = rob.ik_all(rob.fk(q))
    err = min(np.abs(wrap(s - q)).max() for s in sols)
    print('IK solutions:', len(sols), ' round-trip error [rad]:', err)
