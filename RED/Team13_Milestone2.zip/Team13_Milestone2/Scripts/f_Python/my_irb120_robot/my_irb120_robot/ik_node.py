"""IK node (requirement R2): flange pose -> joint angles.

Subscribes : /irb120/target_pose   (geometry_msgs/PoseStamped, frame 'world')
             /joint_states         (to choose the solution closest to now)
Publishes  : /irb120/ik_solution   (sensor_msgs/JointState, radians)
             /irb120/jointN/cmd_pos (only if parameter move_robot is true)

Parameter method: 'trig' (trigonometric / closed form, default) or
'newton' (Newton-Raphson, starting from the current joint angles).

Example (move the flange to x=0.35, y=0.10, z=0.45, tool pointing down):
    ros2 run my_irb120_robot ik_node --ros-args -p move_robot:=true
    ros2 topic pub --once /irb120/target_pose geometry_msgs/msg/PoseStamped \
      "{header: {frame_id: world}, pose: {position: {x: 0.35, y: 0.10, z: 0.45},
        orientation: {x: 0.0, y: 1.0, z: 0.0, w: 0.0}}}"
"""
import numpy as np
import rclpy
from geometry_msgs.msg import PoseStamped
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64

from .common import CMD_TOPICS, JOINT_NAMES, joint_vector, load_robot, pose_to_matrix


class IKNode(Node):
    def __init__(self):
        super().__init__('irb120_ik_node')
        self.declare_parameter('move_robot', False)
        self.declare_parameter('method', 'trig')
        self.robot = load_robot()
        self.q_now = np.zeros(6)
        self.pub = self.create_publisher(JointState, '/irb120/ik_solution', 10)
        self.cmd = [self.create_publisher(Float64, t, 10) for t in CMD_TOPICS]
        self.create_subscription(JointState, '/joint_states', self.on_joints, 10)
        self.create_subscription(PoseStamped, '/irb120/target_pose', self.on_target, 10)
        self.get_logger().info('IK node ready: /irb120/target_pose -> /irb120/ik_solution')

    def on_joints(self, msg):
        q = joint_vector(msg)
        if q is not None:
            self.q_now = q

    def on_target(self, msg):
        T = pose_to_matrix(msg.pose)
        method = self.get_parameter('method').value
        if method == 'newton':
            q, it, res = self.robot.ik_newton(T, self.q_now)
            if res > 1e-8 or not self.robot.within_limits(q):
                self.get_logger().warn('Newton-Raphson did not reach a valid solution '
                                       '(|F| = %.1e after %d iterations).' % (res, it))
                return
        else:
            q = self.robot.ik(T, self.q_now)
            if q is None:
                self.get_logger().warn('No IK solution inside the joint limits for this pose.')
                return
        err = np.abs(self.robot.fk(q) - T).max()
        out = JointState()
        out.header.stamp = self.get_clock().now().to_msg()
        out.name = JOINT_NAMES
        out.position = [float(v) for v in q]
        self.pub.publish(out)
        self.get_logger().info('IK (%s) q [deg] = %s   (FK check error %.1e)'
                               % (method, np.round(np.degrees(q), 2).tolist(), err))
        if self.get_parameter('move_robot').value:
            for pub, v in zip(self.cmd, q):
                pub.publish(Float64(data=float(v)))


def main():
    rclpy.init()
    node = IKNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.try_shutdown()


if __name__ == '__main__':
    main()
