"""Small helpers for the RED Milestone 2 nodes (test cases, flange pose from Gazebo, logging)."""
import os

import numpy as np

from .common import BASE_FRAME, EE_FRAME, quat_to_rot

RESULTS_DIR = os.path.expanduser('~/red_m2_results')
ANGLES_TOPIC = '/irb120/m2/joint_angles'      # IK node -> FK node (sensor_msgs/JointState)
FK_TOPIC = '/irb120/m2/fk_position'           # FK node output (geometry_msgs/PointStamped)


def m2_case(params, c):
    """Test case c (1, 2 or 3) from irb120_params.json, section "m2" (SI units)."""
    m2 = params['m2']
    q0 = np.radians(m2['q0_deg'])
    X = np.array(m2['X_mm'][c - 1], dtype=float) / 1000
    V = np.concatenate([np.array(m2['v_mm_s'][c - 1], dtype=float) / 1000,
                        np.radians(m2['w_deg_s'][c - 1])])
    return q0, X, V, m2


def case_from_argv(argv):
    """First command-line argument = case number (1, 2 or 3)."""
    args = [a for a in argv[1:] if not a.startswith('--') and a not in ('-r',)]
    try:
        c = int(args[0])
    except (IndexError, ValueError):
        c = 1
    if c not in (1, 2, 3):
        raise SystemExit('Case must be 1, 2 or 3')
    return c


def gazebo_flange(tf_buffer):
    """Flange pose that Gazebo reports (TF world -> EE_frame, made from the Gazebo joint
    states and the URDF). Returns (t [s], p [3], R [3x3]) or None."""
    from rclpy.time import Time
    try:
        tr = tf_buffer.lookup_transform(BASE_FRAME, EE_FRAME, Time())
    except Exception:
        return None
    t = tr.header.stamp.sec + tr.header.stamp.nanosec * 1e-9
    p = np.array([tr.transform.translation.x, tr.transform.translation.y, tr.transform.translation.z])
    r = tr.transform.rotation
    return t, p, quat_to_rot(r.x, r.y, r.z, r.w)


def rot_log(R):
    """Rotation matrix -> rotation vector (axis * angle), used for the angular velocity."""
    c = np.clip((np.trace(R) - 1) / 2, -1.0, 1.0)
    th = np.arccos(c)
    vee = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])
    if th < 1e-9:
        return 0.5 * vee
    return th / (2 * np.sin(th)) * vee


def save_csv(name, header, rows):
    os.makedirs(RESULTS_DIR, exist_ok=True)
    path = os.path.join(RESULTS_DIR, name)
    np.savetxt(path, np.array(rows), delimiter=',', header=','.join(header), comments='')
    return path
