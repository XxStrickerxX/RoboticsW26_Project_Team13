"""RED Milestone 2 - IK node (brief 1b): desired flange position -> joint angles.

Runs inverse_kinematics_func (Newton-Raphson with the pseudo-inverse of dF/dq, the same
function as MATLAB) for test case N of irb120_params.json, then
  * publishes the joint angles on /irb120/m2/joint_angles (sensor_msgs/JointState),
    which the FK node (m2_fk_node) subscribes to, and
  * sends them to Gazebo (/irb120/jointN/cmd_pos) with the same smooth move as Simscape
    (step 1 s after start, filter 1/(0.2 s + 1)^2).
The node stops by itself when the move is finished.

    ros2 run my_irb120_robot m2_ik_node 1        (case 1, 2 or 3)
"""
import sys

import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64

from .common import CMD_TOPICS, JOINT_NAMES, joint_vector, load_robot
from .irb120_kin import step_motion
from .m2_common import ANGLES_TOPIC, case_from_argv, m2_case
from .m2_kinematics import fk_position, inverse_kinematics_func


class M2IKNode(Node):
    def __init__(self, case):
        super().__init__('m2_ik_node', parameter_overrides=[
            Parameter('use_sim_time', Parameter.Type.BOOL, True)])
        robot = load_robot()
        q0, self.X, _, m2 = m2_case(robot.params, case)
        self.ts = float(m2['step_time_s'])
        self.t_end = float(m2['ik_check_s'])
        self.tau = float(robot.params['move']['filter_tau_s'])
        log = self.get_logger()
        log.info('Case %d: desired flange position X = %s mm' % (case, np.round(self.X * 1000, 3).tolist()))
        log.info('Initial guess q0 = %s deg' % np.round(np.degrees(q0), 3).tolist())
        self.q = inverse_kinematics_func(q0, self.X)
        log.info('IK joint angles q = %s deg' % np.round(np.degrees(self.q), 3).tolist())
        log.info('Check FK(q) = %s mm (error %.2e mm)' % (
            np.round(fk_position(self.q) * 1000, 3).tolist(),
            np.linalg.norm(fk_position(self.q) - self.X) * 1000))
        self.pub = self.create_publisher(JointState, ANGLES_TOPIC, 10)
        self.cmd = [self.create_publisher(Float64, t, 10) for t in CMD_TOPICS]
        self.create_subscription(JointState, '/joint_states', self.on_joints, 10)
        self.q_start = None
        self.t0 = None
        self.last_pub = -1.0
        self.finished = False
        self.create_timer(0.01, self.tick)            # 100 Hz

    def on_joints(self, msg):
        if self.q_start is None:
            q = joint_vector(msg)
            if q is not None:
                self.q_start = q

    def tick(self):
        now = self.get_clock().now().nanoseconds * 1e-9
        if self.q_start is None or now <= 0.0:
            return                                    # wait for /joint_states and /clock
        if self.t0 is None:
            self.t0 = now
            self.get_logger().info('Moving the robot in Gazebo (from %s deg) ...'
                                   % np.round(np.degrees(self.q_start), 2).tolist())
        t = now - self.t0
        q, _, _ = step_motion(self.q_start, self.q, t, self.ts, self.tau)
        for pub, v in zip(self.cmd, q):
            pub.publish(Float64(data=float(v)))
        if t - self.last_pub >= 0.5:                  # joint angles for the FK node, twice a second
            msg = JointState()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.name = JOINT_NAMES
            msg.position = [float(v) for v in self.q]
            self.pub.publish(msg)
            self.last_pub = t
        if t > self.t_end and not self.finished:
            self.finished = True
            self.get_logger().info('Move finished (t = %.1f s). The FK node prints the comparison. '
                                   'IK node done.' % t)


def main():
    case = case_from_argv(sys.argv)
    rclpy.init()
    node = M2IKNode(case)
    try:
        while rclpy.ok() and not node.finished:
            rclpy.spin_once(node, timeout_sec=0.1)
        for _ in range(20):                            # keep publishing a little longer
            rclpy.spin_once(node, timeout_sec=0.05)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.try_shutdown()


if __name__ == '__main__':
    main()
