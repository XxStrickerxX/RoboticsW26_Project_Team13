"""Slider window (requirement R4): one slider per joint, moves Gazebo live.

Publishes : /irb120/jointN/cmd_pos   (std_msgs/Float64, rad)
            /irb120/joint_reference  ([q, qd=0, qdd=0], Float64MultiArray)
Shows     : the flange position from FK under the sliders.

    ros2 run my_irb120_robot slider_gui
(needs Tkinter: sudo apt install python3-tk  if it is missing)
"""
import threading
import tkinter as tk

import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, Float64MultiArray

from .common import CMD_TOPICS, load_robot


class SliderNode(Node):
    def __init__(self):
        super().__init__('irb120_slider_gui')
        self.robot = load_robot()
        self.cmd = [self.create_publisher(Float64, t, 10) for t in CMD_TOPICS]
        self.ref = self.create_publisher(Float64MultiArray, '/irb120/joint_reference', 10)
        self.q = np.zeros(6)
        self.create_timer(0.05, self.publish)       # 20 Hz

    def publish(self):
        for pub, v in zip(self.cmd, self.q):
            pub.publish(Float64(data=float(v)))
        msg = Float64MultiArray()
        msg.data = [float(v) for v in np.concatenate([self.q, np.zeros(12)])]
        self.ref.publish(msg)


def main():
    rclpy.init()
    node = SliderNode()
    threading.Thread(target=rclpy.spin, args=(node,), daemon=True).start()

    root = tk.Tk()
    root.title('IRB 120 joint sliders')
    label = tk.Label(root, text='', font=('Arial', 12))

    def changed(_value=None):
        node.q = np.radians([s.get() for s in sliders])
        p = node.robot.fk(node.q)[:3, 3]
        label.config(text='Flange (FK): x = %.4f  y = %.4f  z = %.4f m' % tuple(p))

    sliders = []
    for i in range(6):
        lo, hi = np.degrees(node.robot.q_min[i]), np.degrees(node.robot.q_max[i])
        s = tk.Scale(root, from_=lo, to=hi, resolution=0.5, orient=tk.HORIZONTAL,
                     length=500, label=f'Joint {i + 1} [deg]', command=changed)
        s.set(30.0 if i == 4 else 0.0)
        s.pack(padx=10)
        sliders.append(s)
    label.pack(pady=10)
    changed()
    try:
        root.mainloop()
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.try_shutdown()


if __name__ == '__main__':
    main()
