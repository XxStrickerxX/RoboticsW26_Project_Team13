"""End-effector sensor node (requirement R5).

Uses what Gazebo reports (the sensed joint angles) and the
Jacobian to get the flange motion:
    p = FK(q),  v = Jv qd,  w = Jw qd,  a = Jv qdd + Jv_dot qd
qd and qdd are the time derivatives of the sensed angles (low-pass filtered).

As an independent check it also reads the flange pose from TF
(robot_state_publisher, built from the URDF: world -> EE_frame).

Subscribes : /joint_states
Publishes  : /irb120/ee_pose    (PoseStamped, from FK)
             /irb120/ee_pose_tf (PoseStamped, from TF / URDF)
             /irb120/ee_twist   (TwistStamped: linear v, angular w)
             /irb120/ee_accel   (AccelStamped: linear a)

    ros2 run my_irb120_robot ee_sensor_node
"""
import numpy as np
import rclpy
from geometry_msgs.msg import AccelStamped, PoseStamped, TwistStamped
from rclpy.node import Node
from rclpy.time import Time
from sensor_msgs.msg import JointState
from tf2_ros import Buffer, TransformListener

from .common import BASE_FRAME, EE_FRAME, joint_vector, load_robot, matrix_to_pose


class EESensor(Node):
    def __init__(self):
        super().__init__('irb120_ee_sensor')
        self.declare_parameter('accel_filter', 0.3)   # 0..1, 1 = no filtering
        self.robot = load_robot()
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.pub_pose = self.create_publisher(PoseStamped, '/irb120/ee_pose', 10)
        self.pub_tf = self.create_publisher(PoseStamped, '/irb120/ee_pose_tf', 10)
        self.pub_twist = self.create_publisher(TwistStamped, '/irb120/ee_twist', 10)
        self.pub_acc = self.create_publisher(AccelStamped, '/irb120/ee_accel', 10)
        self.create_subscription(JointState, '/joint_states', self.on_joints, 10)
        self.prev_t = None
        self.prev_q = None
        self.prev_qd = None
        self.qdd = np.zeros(6)
        self.count = 0
        self.get_logger().info('EE sensor ready: /joint_states -> /irb120/ee_pose, ee_twist, ee_accel')

    def on_joints(self, msg):
        q = joint_vector(msg, 'position')
        if q is None:
            return
        t = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        k = float(self.get_parameter('accel_filter').value)
        if self.prev_t is None:
            qd = np.zeros(6)
        else:
            dt = t - self.prev_t
            if dt <= 0:
                return
            # joint rates from the sensed angles (low-pass filtered); the velocity
            # Gazebo reports jumps with every new position command
            qd = (1 - k) * self.prev_qd + k * (q - self.prev_q) / dt
            self.qdd = (1 - k) * self.qdd + k * (qd - self.prev_qd) / dt
        self.prev_t, self.prev_q, self.prev_qd = t, q, qd

        J = self.robot.jacobian(q)
        Jd = self.robot.jacobian_dot(q, qd)
        T = self.robot.fk(q)
        v = J[:3] @ qd
        w = J[3:] @ qd
        a = J[:3] @ self.qdd + Jd[:3] @ qd

        hdr_stamp = msg.header.stamp
        pose = PoseStamped()
        pose.header.stamp, pose.header.frame_id = hdr_stamp, BASE_FRAME
        matrix_to_pose(T, pose.pose)
        self.pub_pose.publish(pose)

        tw = TwistStamped()
        tw.header = pose.header
        tw.twist.linear.x, tw.twist.linear.y, tw.twist.linear.z = (float(x) for x in v)
        tw.twist.angular.x, tw.twist.angular.y, tw.twist.angular.z = (float(x) for x in w)
        self.pub_twist.publish(tw)

        ac = AccelStamped()
        ac.header = pose.header
        ac.accel.linear.x, ac.accel.linear.y, ac.accel.linear.z = (float(x) for x in a)
        self.pub_acc.publish(ac)

        diff = None
        try:
            tr = self.tf_buffer.lookup_transform(BASE_FRAME, EE_FRAME, Time())
            pt = PoseStamped()
            pt.header.stamp, pt.header.frame_id = tr.header.stamp, BASE_FRAME
            pt.pose.position.x = tr.transform.translation.x
            pt.pose.position.y = tr.transform.translation.y
            pt.pose.position.z = tr.transform.translation.z
            pt.pose.orientation = tr.transform.rotation
            self.pub_tf.publish(pt)
            diff = np.linalg.norm(np.array([pt.pose.position.x, pt.pose.position.y,
                                            pt.pose.position.z]) - T[:3, 3])
        except Exception:
            pass

        self.count += 1
        if self.count % 100 == 0:
            txt = 'p=%s m  v=%s m/s  a=%s m/s^2' % (np.round(T[:3, 3], 4).tolist(),
                                                     np.round(v, 4).tolist(),
                                                     np.round(a, 3).tolist())
            if diff is not None:
                txt += '  |FK - TF| = %.1e m' % diff
            self.get_logger().info(txt)


def main():
    rclpy.init()
    node = EESensor()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.try_shutdown()


if __name__ == '__main__':
    main()
