"""FK node (requirement R2): joint angles -> flange pose.

Subscribes : /joint_states            (sensor_msgs/JointState, from Gazebo)
Publishes  : /irb120/fk_pose          (geometry_msgs/PoseStamped, frame 'world')

    ros2 run my_irb120_robot fk_node
"""
import rclpy
from geometry_msgs.msg import PoseStamped
from rclpy.node import Node
from sensor_msgs.msg import JointState

from .common import BASE_FRAME, joint_vector, load_robot, matrix_to_pose


class FKNode(Node):
    def __init__(self):
        super().__init__('irb120_fk_node')
        self.robot = load_robot()
        self.pub = self.create_publisher(PoseStamped, '/irb120/fk_pose', 10)
        self.create_subscription(JointState, '/joint_states', self.on_joints, 10)
        self.count = 0
        self.get_logger().info('FK node ready: /joint_states -> /irb120/fk_pose')

    def on_joints(self, msg):
        q = joint_vector(msg)
        if q is None:
            return
        T = self.robot.fk(q)
        out = PoseStamped()
        out.header.stamp = msg.header.stamp
        out.header.frame_id = BASE_FRAME
        matrix_to_pose(T, out.pose)
        self.pub.publish(out)
        self.count += 1
        if self.count % 100 == 0:          # print about once per second
            self.get_logger().info(
                'flange (FK) x=%.4f y=%.4f z=%.4f m' % tuple(T[:3, 3]))


def main():
    rclpy.init()
    node = FKNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.try_shutdown()


if __name__ == '__main__':
    main()
