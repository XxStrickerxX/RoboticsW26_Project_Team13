"""Small helpers shared by the IRB 120 ROS 2 nodes."""
import math
import os

import numpy as np

from .irb120_kin import IRB120

JOINT_NAMES = [f'Joint{i}' for i in range(1, 7)]
CMD_TOPICS = [f'/irb120/joint{i}/cmd_pos' for i in range(1, 7)]
BASE_FRAME = 'world'
EE_FRAME = 'EE_frame'


def params_file():
    """Path of config/irb120_params.json inside the installed package."""
    try:
        from ament_index_python.packages import get_package_share_directory
        return os.path.join(get_package_share_directory('my_irb120_robot'),
                            'config', 'irb120_params.json')
    except Exception:          # running from source
        here = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(here, '..', 'config', 'irb120_params.json')


def load_robot():
    return IRB120(params_file())


def joint_vector(msg, field='position'):
    """Return the 6 joint values of a JointState in Joint1..Joint6 order
    (None if a joint or the field is missing)."""
    values = getattr(msg, field)
    if len(values) != len(msg.name):
        return None
    lookup = dict(zip(msg.name, values))
    if not all(n in lookup for n in JOINT_NAMES):
        return None
    return np.array([lookup[n] for n in JOINT_NAMES], dtype=float)


def rot_to_quat(R):
    """3x3 rotation matrix -> quaternion (x, y, z, w)."""
    tr = R[0, 0] + R[1, 1] + R[2, 2]
    if tr > 0:
        s = math.sqrt(tr + 1.0) * 2
        w = 0.25 * s
        x = (R[2, 1] - R[1, 2]) / s
        y = (R[0, 2] - R[2, 0]) / s
        z = (R[1, 0] - R[0, 1]) / s
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = math.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2]) * 2
        w = (R[2, 1] - R[1, 2]) / s
        x = 0.25 * s
        y = (R[0, 1] + R[1, 0]) / s
        z = (R[0, 2] + R[2, 0]) / s
    elif R[1, 1] > R[2, 2]:
        s = math.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2]) * 2
        w = (R[0, 2] - R[2, 0]) / s
        x = (R[0, 1] + R[1, 0]) / s
        y = 0.25 * s
        z = (R[1, 2] + R[2, 1]) / s
    else:
        s = math.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1]) * 2
        w = (R[1, 0] - R[0, 1]) / s
        x = (R[0, 2] + R[2, 0]) / s
        y = (R[1, 2] + R[2, 1]) / s
        z = 0.25 * s
    return x, y, z, w


def quat_to_rot(x, y, z, w):
    n = math.sqrt(x * x + y * y + z * z + w * w)
    x, y, z, w = x / n, y / n, z / n, w / n
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def pose_to_matrix(pose):
    """geometry_msgs/Pose -> 4x4 matrix."""
    T = np.eye(4)
    o = pose.orientation
    T[:3, :3] = quat_to_rot(o.x, o.y, o.z, o.w)
    T[:3, 3] = [pose.position.x, pose.position.y, pose.position.z]
    return T


def matrix_to_pose(T, pose):
    """Fill a geometry_msgs/Pose from a 4x4 matrix."""
    pose.position.x, pose.position.y, pose.position.z = (float(v) for v in T[:3, 3])
    x, y, z, w = rot_to_quat(T[:3, :3])
    pose.orientation.x, pose.orientation.y = float(x), float(y)
    pose.orientation.z, pose.orientation.w = float(z), float(w)
    return pose
