"""Start Gazebo Harmonic with the IRB 120 and the ROS 2 bridge.

    ros2 launch my_irb120_robot gazebo.launch.py

Starts:
  * Gazebo (ogre renderer - needed on this laptop) with worlds/irb120_world.sdf
  * the robot from urdf/irb120.urdf (spawned as model 'irb120')
  * ros_gz_bridge:
      /irb120/jointN/cmd_pos  (std_msgs/Float64, ROS -> Gazebo), N = 1..6
      /joint_states           (sensor_msgs/JointState, Gazebo -> ROS)
      /clock                  (Gazebo -> ROS)
  * robot_state_publisher  (TF world -> ... -> EE_frame from /joint_states)
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

WORLD_NAME = 'irb120_world'
MODEL_NAME = 'irb120'


def generate_launch_description():
    pkg = get_package_share_directory('my_irb120_robot')
    world = os.path.join(pkg, 'worlds', 'irb120_world.sdf')
    with open(os.path.join(pkg, 'urdf', 'irb120.urdf')) as f:
        urdf = f.read()
    # absolute mesh paths, so Gazebo and RViz find the STL files
    urdf = urdf.replace('package://my_irb120_robot/', 'file://' + pkg + '/')

    gz = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(
            get_package_share_directory('ros_gz_sim'), 'launch', 'gz_sim.launch.py')),
        launch_arguments={'gz_args': f'-r -v4 --render-engine ogre {world}'}.items())

    spawn = Node(
        package='ros_gz_sim', executable='create', output='screen',
        arguments=['-world', WORLD_NAME, '-name', MODEL_NAME, '-string', urdf])

    gz_joint_state = f'/world/{WORLD_NAME}/model/{MODEL_NAME}/joint_state'
    bridge_args = ['/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock',
                   f'{gz_joint_state}@sensor_msgs/msg/JointState[gz.msgs.Model']
    bridge_args += [f'/irb120/joint{i}/cmd_pos@std_msgs/msg/Float64]gz.msgs.Double'
                    for i in range(1, 7)]
    bridge = Node(
        package='ros_gz_bridge', executable='parameter_bridge', output='screen',
        arguments=bridge_args,
        remappings=[(gz_joint_state, '/joint_states')])

    rsp = Node(
        package='robot_state_publisher', executable='robot_state_publisher', output='screen',
        parameters=[{'robot_description': urdf}])

    return LaunchDescription([
        SetEnvironmentVariable('GZ_SIM_RESOURCE_PATH', os.path.dirname(pkg)),
        gz, spawn, bridge, rsp,
    ])
