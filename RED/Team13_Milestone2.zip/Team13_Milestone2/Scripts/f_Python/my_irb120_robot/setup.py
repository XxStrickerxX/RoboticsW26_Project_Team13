from glob import glob

from setuptools import setup

package_name = 'my_irb120_robot'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.py')),
        ('share/' + package_name + '/urdf', glob('urdf/*.urdf')),
        ('share/' + package_name + '/worlds', glob('worlds/*.sdf')),
        ('share/' + package_name + '/config', glob('config/*.json')),
        ('share/' + package_name + '/meshes/visual', glob('meshes/visual/*.stl')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Team 13',
    maintainer_email='team13@example.com',
    description='ABB IRB 120 Milestone 01: Gazebo model, FK/IK/Jacobian nodes and tests.',
    license='MIT',
    entry_points={
        'console_scripts': [
            'fk_node = my_irb120_robot.fk_node:main',
            'ik_node = my_irb120_robot.ik_node:main',
            'joint_commander = my_irb120_robot.joint_commander:main',
            'slider_gui = my_irb120_robot.slider_gui:main',
            'ee_sensor_node = my_irb120_robot.ee_sensor_node:main',
            'kinematics_test_node = my_irb120_robot.kinematics_test_node:main',
            'm2_ik_node = my_irb120_robot.m2_ik_node:main',
            'm2_fk_node = my_irb120_robot.m2_fk_node:main',
            'm2_velocity_node = my_irb120_robot.m2_velocity_node:main',
        ],
    },
)
