"""Convert the 13 SolidWorks STEP parts into the STL meshes the URDF uses.

Run on the laptop (needs cadquery, see README step "Make the meshes"):
    ~/irb120_venv/bin/python ~/irb120_m1/tools/step_to_stl.py

Input : ~/CAD_Model/CAD_Model/*.STEP       (millimetres, part frames)
Output: ~/irb120_m1/ros2_ws/src/my_irb120_robot/meshes/visual/*.stl
The STL keeps the part frame and the millimetre unit; the URDF scales by
0.001 and places every mesh with the transform computed from the XML.
"""
import os
import sys

import cadquery as cq

CAD = os.path.expanduser('~/CAD_Model/CAD_Model')
OUT = os.path.expanduser('~/irb120_m1/ros2_ws/src/my_irb120_robot/meshes/visual')

MAP = {
    'IRB120_BASE_Default_sldprt.STEP': 'base',
    'IRB120_J1_Default_sldprt.STEP': 'j1',
    'IRB120_Link2_Default_sldprt.STEP': 'link2',
    'IRB120_Link3_Default_sldprt.STEP': 'link3',
    'IRB120_Wrist1_Default_sldprt.STEP': 'wrist1',
    'IRB120_Wrist2_Default_sldprt.STEP': 'wrist2',
    'IRB120_Wrist3_Default_sldprt.STEP': 'wrist3',
    '2F casing-Gripper_Default_sldprt.STEP': 'gripper_casing',
    '2F distal-Gripper_Default_sldprt.STEP': 'gripper_distal',
    '2F membrure-Gripper_Default_sldprt.STEP': 'gripper_membrure',
    '2F-85 barre-Gripper_Default_sldprt.STEP': 'gripper_barre',
    '2F-85 pad-Gripper_Default_sldprt.STEP': 'gripper_pad',
    '2F-85 proximal-Gripper_Default_sldprt.STEP': 'gripper_proximal',
}

os.makedirs(OUT, exist_ok=True)
missing = [f for f in MAP if not os.path.isfile(os.path.join(CAD, f))]
if missing:
    sys.exit('Missing STEP files in %s:\n  %s' % (CAD, '\n  '.join(missing)))

for step, name in MAP.items():
    shape = cq.importers.importStep(os.path.join(CAD, step))
    out = os.path.join(OUT, name + '.stl')
    # tolerance in mm: 0.2 mm chord error, 0.3 rad angle -> small, smooth files
    cq.exporters.export(shape, out, tolerance=0.2, angularTolerance=0.3)
    bb = shape.val().BoundingBox()
    print('%-45s -> %-22s size %.0f x %.0f x %.0f mm, %.1f MB'
          % (step, name + '.stl', bb.xlen, bb.ylen, bb.zlen, os.path.getsize(out) / 1e6))
print('Done: 13 STL files in', OUT)
