"""RED Milestone 2 tests in Python (no ROS needed), the same as run_m2_tests.m.
1) Inverse position kinematics (Newton-Raphson) validated with the forward kinematics.
2) Inverse velocity kinematics validated with the forward velocity kinematics.
Test cases: config/irb120_params.json, section "m2" (same file as MATLAB).

    python3 run_m2_tests.py
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.join(HERE, 'my_irb120_robot')
sys.path.insert(0, PKG)
from my_irb120_robot.m2_kinematics import (fk_position, forward_velocity_kinematics,  # noqa: E402
                                           inverse_kinematics_func,
                                           inverse_velocity_kinematics)

with open(os.path.join(PKG, 'config', 'irb120_params.json')) as f:
    cases = json.load(f)['m2']

q0 = np.radians(cases['q0_deg'])
print('Initial guess q0 (deg):', np.round(np.degrees(q0), 3))

for c in range(3):
    print('\n================ Case %d ================' % (c + 1))
    Xd = np.array(cases['X_mm'][c]) / 1000
    print('Desired flange position (mm):   x=%9.3f  y=%9.3f  z=%9.3f' % tuple(Xd * 1000))

    # 1) inverse position kinematics, checked with the forward kinematics
    q = inverse_kinematics_func(q0, Xd)
    print('IK joint angles (deg):          ' + ' '.join('q%d=%8.3f' % (i + 1, v) for i, v in enumerate(np.degrees(q))))
    X_check = fk_position(q)
    print('FK of the IK angles (mm):       x=%9.3f  y=%9.3f  z=%9.3f' % tuple(X_check * 1000))
    print('Position error (mm):            %.2e' % (np.linalg.norm(X_check - Xd) * 1000))

    # 2) inverse velocity kinematics, checked with the forward velocity kinematics
    V_d = np.concatenate([np.array(cases['v_mm_s'][c]) / 1000, np.radians(cases['w_deg_s'][c])])
    q_dot = inverse_velocity_kinematics(q, V_d)
    print('Desired v (mm/s):               vx=%8.3f vy=%8.3f vz=%8.3f' % tuple(V_d[:3] * 1000))
    print('Desired w (deg/s):              wx=%8.3f wy=%8.3f wz=%8.3f' % tuple(np.degrees(V_d[3:])))
    print('IVK joint velocities (deg/s):   ' + ' '.join('%8.3f' % v for v in np.degrees(q_dot)))
    V_F = forward_velocity_kinematics(q, q_dot)
    print('FVK v (mm/s):                   vx=%8.3f vy=%8.3f vz=%8.3f' % tuple(V_F[:3] * 1000))
    print('FVK w (deg/s):                  wx=%8.3f wy=%8.3f wz=%8.3f' % tuple(np.degrees(V_F[3:])))
    print('Velocity error: v %.2e mm/s, w %.2e deg/s'
          % (np.linalg.norm(V_F[:3] - V_d[:3]) * 1000, np.degrees(np.linalg.norm(V_F[3:] - V_d[3:]))))

    # independent check of the linear part: numerical derivative of the FK
    dt = 1e-6
    v_num = (fk_position(q + q_dot * dt) - fk_position(q - q_dot * dt)) / (2 * dt)
    print('Numerical derivative check (mm/s): %.2e' % (np.linalg.norm(v_num - V_F[:3]) * 1000))
